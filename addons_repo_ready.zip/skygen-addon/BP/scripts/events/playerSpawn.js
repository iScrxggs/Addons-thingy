import { world } from "@minecraft/server";
import { PlayerData } from "../systems/PlayerData";
import { ADDON_UPDATE, ADDON_VERSION } from "../constants";

// let onlinePlayers = false;

/** I use this instead of "world.afterEvents.playerJoin" since this ACTUALLY triggers after the player joins */
world.afterEvents.playerSpawn.subscribe((data) => {
    const { initialSpawn, player } = data;
    if (!initialSpawn) return;

    // Reminder
    player.sendMessage(
        "§d* [MSC] Use the '§e/mschelp§d' command if you are confused!",
    );

    // Dev Log In
    if (player.name === "Realcancov" || player.name === "Mythicode") {
        // Lil credit in logs lol
        console.log(
            `§d* [MSC] §r§eDev Login: §a${player.name} §e[V${ADDON_VERSION.join(".")}]§r`,
        );
        world.sendMessage(`§d* [MSC] §r§eDev Login: §a${player.name}§r`);
        player.sendMessage(
            `§d* MSC is running §r§eV${ADDON_VERSION.join(".")} | ${ADDON_UPDATE}`,
        );
        player.addTag("mscRealmDev");
    }

    /** On initially joining, set player.uid if the player does not have it right now */
    PlayerData.onJoin(player);

    // onlinePlayers = world.getAllPlayers();
});

// world.afterEvents.playerLeave.subscribe((data) => {
// onlinePlayers = world.getAllPlayers();
// });

/**
 * Grabs the world get all players only when it updates
 * @returns {world.getAllPlayers()}
 */
// export function getAllPlayers() {
//     if (!onlinePlayers) {
//         onlinePlayers = world.getAllPlayers();
//     }
//     return onlinePlayers;
// }
