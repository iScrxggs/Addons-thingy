import { ItemStack, world } from "@minecraft/server";
import { devLog } from "../systems/DeveloperMode";

world.afterEvents.entitySpawn.subscribe((data) => {
    const { entity } = data;

    /** If entity is a grounded itemStack */
    if (entity.typeId === "minecraft:item") {
        /** Converts custom placeholder blocks for falling blocks to vanilla counterparts */
        try {
            const typeId = entity?.getComponent("item").itemStack.typeId;
            if (
                typeId.startsWith("msc:") &&
                typeId.endsWith("_placeholder") &&
                !typeId.includes("blockgen")
            ) {
                const newItemId = typeId
                    .substring(4)
                    .substring(0, typeId.length - 16);
                const itemStack = new ItemStack(newItemId);
                const dim = entity.dimension;
                const location = entity.location;

                dim.spawnItem(itemStack, location);
                entity.remove();
                return;
            }

            if (
                typeId === "msc:auto_miner" ||
                typeId === "msc:experience_tank"
            ) {
                const item = entity.getComponent("item").itemStack;
                if (item.getLore().length < 1) {
                    entity.remove();
                    devLog(
                        `§cRemoved §b${typeId} §aground item because it had no lore`,
                    );
                }
                return;
            }

            if (typeId === "msc:blockgen_placeholder") {
                entity.remove();
                devLog(
                    `§cRemoved §b${typeId} §aground item to prevent player pickup`,
                );
                return;
            }
        } catch (e) {}
    }
});
