import { system, world } from "@minecraft/server";
import { Generator } from "../systems/gens/GenData";
import { vector3ToString } from "../utils/Locations";
import { devLog } from "../systems/DeveloperMode";
import { AutoMiner } from "../systems/autoMiner/AutoMiner";
import { ItemStorer } from "../systems/itemStorer/ItemStorer";
import { isOpInGMC } from "../utils/Player";
import { ExperienceTank } from "../systems/experienceTank/ExperienceTank";
import { formatString } from "../utils/Formats";
import { SkygenProgress } from "../systems/SkygenProgress";

world.beforeEvents.playerBreakBlock.subscribe((data) => {
    const { player, block, dimension } = data;
    const location = block.location;
    const xyz = vector3ToString(location);
    const dimId = dimension.id;

    if (
        block.typeId === "msc:blockgen_placeholder" &&
        Generator.data[dimId][xyz]
    ) {
        devLog(
            `${player.name}[${player.uid}] tried to break §cBlockgen Placeholder §e@${xyz}`,
        );
        data.cancel = true;
        return;
    }

    if (ItemStorer.data[dimId][xyz]) {
        system.run(() => {
            try {
                ItemStorer.remove(dimension, location, player);
            } catch (error) {
                console.log(error);
            }
        });

        const isOwner = ItemStorer.isOwner(dimId, xyz, player);
        if (!isOwner && !isOpInGMC(player)) data.cancel = true;
        return;
    }

    if (ExperienceTank.data[dimId][xyz]) {
        if (!isOpInGMC(player)) data.cancel = true;

        system.run(() => {
            try {
                ExperienceTank.remove(dimension, location, player);
            } catch (error) {
                console.log(error);
            }
        });
        return;
    }

    if (AutoMiner.data[dimId][xyz]) {
        if (!isOpInGMC(player)) data.cancel = true;

        system.run(() => {
            try {
                AutoMiner.remove(dimension, location, player);
            } catch (error) {
                console.log(error);
            }
        });
        return;
    }

    if (Generator.data[dimId][xyz]) {
        const genData = Generator.data[dimId][xyz];
        const reward = SkygenProgress.recordGeneratorBreak(player, genData.type);

        devLog(
            `${player.name}[${player.uid}] broke §b${formatString(genData.type)} Generator §e@${xyz}`,
        );

        if (reward.jackpotReward > 0) {
            system.run(() => {
                player.sendMessage(
                    `§6* [MSC] Jackpot! §e+${reward.jackpotReward} bonus tokens §7(${reward.totalReward} total, ${reward.jackpotChancePercent.toFixed(2)}% chance)`,
                );
            });
        }
    }
});
