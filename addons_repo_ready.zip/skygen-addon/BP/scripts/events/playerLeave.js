import { world } from "@minecraft/server";
import { PlayerData } from "../systems/PlayerData";
import { ADDON_VERSION, playersOnline } from "../constants";

/** I use this instead of "world.afterEvents.playerJoin" since this ACTUALLY triggers after the player joins */
