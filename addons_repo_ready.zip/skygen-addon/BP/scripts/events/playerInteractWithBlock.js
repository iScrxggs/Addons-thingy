import { system, world } from "@minecraft/server";
import { Generator } from "../systems/gens/GenData";
import { vector3ToString } from "../utils/Locations";
import { genIsInteractable } from "../utils/Blocks";
import { AutoMiner } from "../systems/autoMiner/AutoMiner";
import { MinerMenu } from "../systems/autoMiner/MinerMenu";
import { isOpInGMC } from "../utils/Player";
import { ItemStorer } from "../systems/itemStorer/ItemStorer";
import { ExperienceTank } from "../systems/experienceTank/ExperienceTank";
import { GenMenu } from "../systems/gens/GenMenu";
import { SellWand } from "../systems/SellWand";

world.beforeEvents.playerInteractWithBlock.subscribe((data) => {
    const { itemStack, player, block, isFirstEvent } = data;
    const dimension = block.dimension;

    const location = block.location;
    const xyz = vector3ToString(location);
    const dimId = dimension.id;

    // Prevents redstone from being weird on 2nd interact
    if (Generator.data[dimId][xyz] && block.typeId.includes("redstone_ore")) {
        const typeId = block.typeId;
        system.run(() => {
            block.setType("minecraft:grass");
            block.setType(typeId);
        });
    }

    if (
        !isUsingGenEgg(itemStack) &&
        !player.isSneaking &&
        Generator.data[dimId][xyz]
    ) {
        data.cancel = true;
    }

    // Prevent holding down use and switching onto nearby containers or gen blocks.
    if (genInteractCancelled(block, dimId, xyz) && !isFirstEvent) {
        data.cancel = true;
        return;
    }

    if (!isFirstEvent) return;

    if (AutoMiner.data[dimId][xyz] && !player.isSneaking) {
        system.run(() => {
            if (isUsingAdminWrench(itemStack) && isOpInGMC(player)) {
                new MinerMenu(dimension, location, player, true);
            } else {
                new MinerMenu(dimension, location, player);
            }
        });
        data.cancel = true;
        return;
    }

    if (Generator.data[dimId][xyz]) {
        const type = Generator.data[dimId][xyz].type;

        if (itemStack?.typeId === "msc:admin_wrench" && isOpInGMC(player)) {
            system.run(() => {
                new GenMenu(player, location, type, dimension, true);
            });
            data.cancel = true;
            return;
        }

        if (!itemStack && player.isSneaking) {
            system.run(() => {
                Generator.remove(location, dimension, player, type);
            });
            data.cancel = true;
            return;
        }

        if (!player.isSneaking && !isUsingGenEgg(itemStack)) {
            system.run(() => {
                new GenMenu(player, location, type, dimension);
            });
            data.cancel = true;
            return;
        }
    }

    if (!itemStack) return;

    if (ItemStorer.data[dimId][xyz] && SellWand.isSellWand(itemStack)) {
        system.run(() => {
            const result = SellWand.sellFromItemStorer(
                dimension,
                location,
                player,
            );
            if (!result.success) {
                player.sendMessage(`\u00A7c* [MSC] ${result.message}`);
                player.playSound("note.bass");
                return;
            }

            player.sendMessage(SellWand.formatSellMessage(result));
            player.sendMessage(
                `\u00A77Multiplier: \u00A7b${result.multiplier.toFixed(2)}x \u00A77| Rebirth Bonus: \u00A7d${result.rebirthBonus.toFixed(2)}x`,
            );
            for (const blockedLine of SellWand.formatBlockedMessages(result)) {
                player.sendMessage(blockedLine);
            }
            player.playSound("note.chime");
        });
        data.cancel = true;
        return;
    }

    if (SellWand.isSellWand(itemStack) && SellWand.supportsBlock(block)) {
        system.run(() => {
            const result = SellWand.sellFromContainerBlock(block, player);
            if (!result.success) {
                player.sendMessage(`\u00A7c* [MSC] ${result.message}`);
                player.playSound("note.bass");
                return;
            }

            player.sendMessage(SellWand.formatContainerSellMessage(result));
            player.sendMessage(
                `\u00A77Multiplier: \u00A7b${result.multiplier.toFixed(2)}x \u00A77| Rebirth Bonus: \u00A7d${result.rebirthBonus.toFixed(2)}x`,
            );
            for (const blockedLine of SellWand.formatBlockedMessages(result)) {
                player.sendMessage(blockedLine);
            }
            player.playSound("note.chime");
        });
        data.cancel = true;
        return;
    }

    if (ItemStorer.data[dimId][xyz]) {
        system.run(() => {
            ItemStorer.assign(dimension, location, player, itemStack);
        });
        data.cancel = true;
        return;
    }

    if (isUsingGlassBottleOnExpTank(dimId, xyz, itemStack)) {
        system.run(() => {
            ExperienceTank.makeExpBottles(
                dimension,
                location,
                player,
                itemStack,
            );
        });
    }
});

function isUsingGenEgg(itemStack) {
    if (!itemStack) return false;
    if (!itemStack.typeId.startsWith("msc:")) return false;
    if (!itemStack.typeId.endsWith("_gen")) return false;
    return true;
}

function genInteractCancelled(block, dimensionId, locationString) {
    if (!genIsInteractable(block)) return false;
    if (!Generator.data[dimensionId][locationString]) return false;
    return true;
}

function isUsingAdminWrench(itemStack) {
    if (!itemStack) return false;
    if (itemStack.typeId !== "msc:admin_wrench") return false;
    return true;
}

function isUsingGlassBottleOnExpTank(dimensionId, locationString, itemStack) {
    if (!itemStack) return false;
    if (itemStack.typeId !== "minecraft:glass_bottle") return false;
    if (!ExperienceTank.data[dimensionId][locationString]) return false;
    return true;
}
