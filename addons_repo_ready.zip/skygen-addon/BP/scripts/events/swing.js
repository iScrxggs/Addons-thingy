import { system, world } from "@minecraft/server";
import { Generator } from "../systems/gens/GenData";
import { vector3ToString } from "../utils/Locations";
import { genIsInteractable } from "../utils/Blocks";
import { AutoMiner } from "../systems/autoMiner/AutoMiner";
import { MinerMenu } from "../systems/autoMiner/MinerMenu";
import { isOpInGMC } from "../utils/Player";
import { ItemStorer } from "../systems/itemStorer/ItemStorer";
import { ExperienceTank } from "../systems/experienceTank/ExperienceTank";
import { GenMenu } from "../systems/gens/GenMenu";

/**
 * Returns true/false for if the itemstack is a gen egg
 * @param {ItemStack} itemStack
 * @returns {Boolean}
 */
function isUsingGenEgg(itemStack) {
    if (!itemStack) return false;
    if (!itemStack.typeId.startsWith("msc:")) return false;
    if (!itemStack.typeId.endsWith("_gen")) return false;
    return true;
}

/**
 * Returns true/false for if the gen interaction should be canceled
 * @param {Block} block
 * @param {Dimension.id} dimensionId
 * @param {String} locationString
 * @returns {Boolean}
 */
function genInteractCancelled(block, dimensionId, locationString) {
    if (!genIsInteractable(block)) return false;
    if (!Generator.data[dimensionId][locationString]) return false;
    return true;
}

/**
 * Returns true/false for if the itemstack is the admin wrench tool or not
 * @param {ItemStack} itemStack
 * @returns {Boolean}
 */
function isUsingAdminWrench(itemStack) {
    if (!itemStack) return false;
    if (itemStack.typeId !== "msc:admin_wrench") return false;
    return true;
}

/**
 * Returns true/false for if the itemstack is a glass bottle or not
 * @param {Dimension.id} dimensionId
 * @param {String} locationString
 * @param {ItemStack} itemStack
 * @returns {Boolean}
 */
function isUsingGlassBottleOnExpTank(dimensionId, locationString, itemStack) {
    if (!itemStack) return false;
    if (itemStack.typeId !== "minecraft:glass_bottle") return false;
    if (!ExperienceTank.data[dimensionId][locationString]) return false;
    return true;
}
