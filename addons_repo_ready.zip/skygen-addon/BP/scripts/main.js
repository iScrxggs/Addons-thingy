import {
    ADDON_NAME,
    ADDON_UPDATE,
    ADDON_VERSION,
    DIMENSION_NUM,
} from "./constants";
import { system, world } from "@minecraft/server";

import "./systemEvents/_index";
import "./events/_index";
import { Generator } from "./systems/gens/GenData";
import { vector3ToString } from "./utils/Locations";
import { Particle } from "./WeirdPaperStuff/particleLineThingy";
import { AutoMiner } from "./systems/autoMiner/AutoMiner";
import { ItemStorer } from "./systems/itemStorer/ItemStorer";
import { targetIsOnline } from "./utils/Player";
import { formatItemtypeId, formatNumber } from "./utils/Formats";
import { ExperienceTank } from "./systems/experienceTank/ExperienceTank";
import { centerLocation } from "./utils/Blocks";
import "./systems/RebirthSync";
import "./systems/SkygenCatalog";

const message = `\u00A7l\u00A7d[${ADDON_NAME}] Loaded \u00A7av${ADDON_VERSION.join(".")} \u00A7b${ADDON_UPDATE}\u00A7r`;
console.log(message);

/** Adds the gen block outline */
const greenRGB = {
    red: 0,
    green: 1,
    blue: 0,
    alpha: 0.2,
};
const redRGB = {
    red: 1,
    green: 0,
    blue: 0,
    alpha: 0.2,
};
system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const raycast = player.getBlockFromViewDirection();
        if (!raycast) continue;

        const block = raycast.block;
        const dimension = block.dimension;
        const location = block.location;

        const dimId = dimension.id;
        const xyz = vector3ToString(location);

        // Generator Outlines
        const genData = Generator.data[dimId];
        if (genData[xyz]) {
            generatorOutline(dimension, location);
            continue;
        }

        // Auto Miner Outlines
        const minerData = AutoMiner.data[dimId];
        if (minerData[xyz]) {
            autoMinerOutline(dimension, location, minerData[xyz].owner);
            continue;
        }

        // Item Storer Outlines
        const itemStorerData = ItemStorer.data[dimId];
        if (itemStorerData[xyz]) {
            itemStorerOutline(dimension, location, itemStorerData[xyz].owner);
            continue;
        }

        // Item Storer Outlines
        const expTank = ExperienceTank.data[dimId];
        if (expTank[xyz]) {
            experienceTankOutline(dimension, location, expTank[xyz].owner);
            continue;
        }
    }
});
function generatorOutline(dimension, location) {
    Particle.boxEdges(
        "sse:line",
        location,
        { x: 1.0, y: 1.0, z: 1.0 },
        dimension,
    );
}
function autoMinerOutline(dimension, location, ownerId) {
    const offset = {
        x: location.x + 0.12,
        y: location.y + 0.0125,
        z: location.z + 0.12,
    };

    const sizes = { x: 0.76, y: 0.76, z: 0.76 };

    // Green
    if (targetIsOnline(ownerId)) {
        Particle.boxEdges(
            "sse:line",
            offset,
            sizes,
            dimension,
            undefined,
            undefined,
            greenRGB,
        );
        return;
    }

    // Red
    Particle.boxEdges(
        "sse:line",
        offset,
        sizes,
        dimension,
        undefined,
        undefined,
        redRGB,
    );
}
function experienceTankOutline(dimension, location, ownerId) {
    const xyz = vector3ToString(location);
    const dimId = dimension.id;

    const data = ExperienceTank.data[dimId][xyz];

    const offset = {
        x: location.x + 0.05,
        y: location.y,
        z: location.z + 0.05,
    };

    const sizes = { x: 0.9, y: 0.9, z: 0.9 };

    const ent = [
        ...dimension.getEntities({
            maxDistance: 0.5,
            location: centerLocation(location),
            type: "msc:floating_text",
        }),
    ][0];

    // If ent doesn't exist, spawn it
    if (!ent) {
        const newEnt = dimension.spawnEntity("msc:floating_text", {
            x: location.x + 0.5,
            y: location.y,
            z: location.z + 0.5,
        });

        const storedExp = +data.storedExp;
        newEnt.nameTag = ` §l§6EXP:§r \n§e${formatNumber(storedExp)}§r`;
        system.runTimeout(() => {
            if (!newEnt.isValid) return;
            newEnt.remove();
        }, 100);
    }

    // Green
    if (targetIsOnline(ownerId)) {
        Particle.boxEdges(
            "sse:line",
            offset,
            sizes,
            dimension,
            undefined,
            undefined,
            greenRGB,
        );
        return;
    }

    // Red
    Particle.boxEdges(
        "sse:line",
        offset,
        sizes,
        dimension,
        undefined,
        undefined,
        redRGB,
    );
}
function itemStorerOutline(dimension, location, ownerId) {
    const xyz = vector3ToString(location);
    const dimId = dimension.id;

    const data = ItemStorer.data[dimId][xyz];

    const offset = {
        x: location.x + 0.18,
        y: location.y,
        z: location.z + 0.18,
    };

    const sizes = { x: 0.65, y: 0.65, z: 0.65 };

    const ent = [
        ...dimension.getEntities({
            maxDistance: 0.5,
            location: centerLocation(location),
            type: "msc:floating_text",
        }),
    ][0];

    // If ent doesn't exist, spawn it
    if (!ent && data.item) {
        const newEnt = dimension.spawnEntity("msc:floating_text", {
            x: location.x + 0.5,
            y: location.y + 0.3,
            z: location.z + 0.5,
        });

        const itemId = formatItemtypeId(data.item);
        newEnt.nameTag = ` §l§6${itemId}§r \n§ex${data.amount}§r`;
        system.runTimeout(() => {
            if (!newEnt.isValid) return;
            newEnt.remove();
        }, 100);
    }

    // Green
    if (targetIsOnline(ownerId)) {
        Particle.boxEdges(
            "sse:line",
            offset,
            sizes,
            dimension,
            undefined,
            undefined,
            greenRGB,
        );
        return;
    }

    // Red
    Particle.boxEdges(
        "sse:line",
        offset,
        sizes,
        dimension,
        undefined,
        undefined,
        redRGB,
    );
}

system.run(() => {
    for (const dimension of Object.keys(DIMENSION_NUM)) {
        const dim = world.getDimension(dimension);
        for (const entity of [
            ...dim.getEntities({ type: "msc:floating_text" }),
        ]) {
            entity.remove();
        }
    }
});
