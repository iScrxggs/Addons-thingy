import { world } from "@minecraft/server";

/**
 * Returns where or not the player is OPERATOR as well as in CREATIVE MODE.
 * @param {Player} player
 * @returns {Boolean}
 */
export function isOpInGMC(player) {
    if (player.playerPermissionLevel !== 2) return false;
    if (player.getGameMode() !== "Creative") return false;
    return true;
}

/**
 * Returns whether the target is online or not from their UID
 * @param {Player.uid} targetUID
 * @returns {Boolean}
 */
export function targetIsOnline(targetUID) {
    for (const player of world.getAllPlayers()) {
        if (player.uid === targetUID) return true;
    }
    return false;
}
