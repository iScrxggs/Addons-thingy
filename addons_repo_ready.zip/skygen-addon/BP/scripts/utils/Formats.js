/**
 * Used to shorten a itemstack typeId into the block it creates in with gen eggs
 * Formats 'msc:deepslate_gen' to 'minecraft:deepslate'.
 */
export function itemTypeIdToBlock(itemStack) {
    return "minecraft:" + itemStack.typeId.substring(4).replace("_gen", "");
}

export function formatItemtypeId(itemTypeId) {
    return formatString(itemTypeId.split(":")[1]);
}

/** Formats 'minecraft:white_wool' into 'White Wool' */
export function formatBlockTypeId(string) {
    return formatString(string.split(":")[1]);
}

/** Formats 'text_like_this' into 'Text like this' */
export function formatString(string, regex = /[ _]+/) {
    return string
        .split(regex)
        .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
        .join(" ");
}

/**
 * Splits a string into specified lengths; for example if the string is 100 characters long and I want to split into 25 it will return a list of 4 lines of 25 from the string.
 * @param {String} string
 * @param {Number} size
 * @returns {Array}
 */
export function splitByLength(string, size) {
    const result = [];

    for (let i = 0; i < string.length; i += size) {
        result.push(string.slice(i, i + size));
    }

    return result;
}

/**
 * Formats a number from "1000" format to "1,000" string
 * @param {Number} num
 * @returns {String}
 */
export function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/** Returns the input number into thousands, millions, billions etc. with a 2DP */
export function displayUnitNumber(num) {
    const units = ["", "K", "M", "B", "T", "Qa", "Qi", "Sx"];
    let unitIndex = 0;

    while (num >= 1000 && unitIndex < units.length - 1) {
        num /= 1000;
        unitIndex++;
    }

    return num.toFixed(2).replace(/\.00$/, "") + units[unitIndex];
}
