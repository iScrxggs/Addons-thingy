import { world } from "@minecraft/server";

/**
 * This grabs the block a specified number of steps, defaulting to 1 INFRONT of the block you interacted on.
 *
 * It determines the 'front' from the blockFace location you interact on, so interacting on the North Face will
 * grab the block -1 on the Z axis from the intial interact location. Very useful for gen placement.
 */
export function grabBlockInfront(location, blockFace, steps = 1) {
    const newLocation = {
        x: location.x,
        y: location.y,
        z: location.z,
    };

    if (blockFace === "North") newLocation.z -= steps;
    if (blockFace === "East") newLocation.x += steps;
    if (blockFace === "South") newLocation.z += steps;
    if (blockFace === "West") newLocation.x -= steps;
    if (blockFace === "Up") newLocation.y += steps;
    if (blockFace === "Down") newLocation.y -= steps;

    return newLocation;
}

/**
 * Returns the location but centered on the block
 * @param {Vector3} location
 * @returns {Vector3}
 */
export function centerLocation(location) {
    return { x: location.x + 0.5, y: location.y, z: location.z + 0.5 };
}

/**
 * Returns true/false based on if an autominer can break this
 * @param {Block.typeId} blockTypeId
 * @returns {Boolean}
 */
export function blockCanBeAutomined(blockTypeId) {
    /**
     * If barrier, border, bedrock, command blocks, end portal frames etc fail
     */
    if (
        blockTypeId === "minecraft:border_block" ||
        blockTypeId === "minecraft:barrier" ||
        blockTypeId === "minecraft:bedrock" ||
        blockTypeId === "minecraft:command_block" ||
        blockTypeId === "minecraft:chain_command_block" ||
        blockTypeId === "minecraft:repeating_command_block" ||
        blockTypeId === "minecraft:end_portal_frame" ||
        blockTypeId === "minecraft:deny" ||
        blockTypeId === "minecraft:allow" ||
        blockTypeId === "msc:auto_miner" ||
        blockTypeId === "minecraft:air" ||
        blockTypeId === "minecraft:flowing_lava" ||
        blockTypeId === "minecraft:flowing_water" ||
        blockTypeId === "minecraft:lava" ||
        blockTypeId === "minecraft:water" ||
        blockTypeId === "msc:blockgen_placeholder" ||
        blockTypeId === "msc:experience_tank" ||
        blockTypeId === "msc:item_storer"
    )
        return false;

    // If none of these, return true
    return true;
}

/**
 * Returns true/false based on block
 * @param {Block} block
 * @returns {Boolean}
 */
export function genIsInteractable(block) {
    const container = block.getComponent("inventory");
    if (container) return true;

    const id = block.typeId;
    if (id.endsWith("_log")) return true;
    if (id.endsWith("_stem")) return true;

    if (id === "minecraft:dirt") return true;
    if (id === "minecraft:mycelium") return true;
    if (id === "minecraft:grass") return true;
    if (id === "minecraft:copper_block") return true;
    if (id === "minecraft:redstone_ore") return true;
    if (id === "minecraft:deepslate_redstone_ore") return true;
    return false;
}

/**
 * Takes BLOCKTYPE_NUM types ex: 'basalt' and returns the typeId for what we store ex: 'minecraft:basalt', 'msc:gravel_placeholder'
 * @param {String} blockType
 * @returns {String}
 */
export function typeToTypeId(blockType) {
    if (
        blockType.includes("concrete_powder") ||
        blockType === "sand" ||
        blockType === "red_sand" ||
        blockType === "gravel"
    ) {
        return `msc:${blockType}_placeholder`;
    }
    return `minecraft:${blockType}`;
}

/**
 * Takes Block.typeId types ex: 'minecraft:basalt' and returns the type for what we store ex: '"minecraft:basalt" -> "basalt"', '"msc:gravel_placeholder" -> "gravel"'
 * @param {String} blockTypeId
 * @returns {String}
 */
export function typeIdToType(blockTypeId) {
    let result = blockTypeId.split(":")[1];
    if (
        blockTypeId.includes("concrete_powder") ||
        blockTypeId === "sand" ||
        blockTypeId === "red_sand" ||
        blockTypeId === "gravel"
    ) {
        return result.replace("_placeholder", "");
    }
    return result;
}

/**
 * This is so that if you interact with something interactable and NOT sneaking it will cancel the gen placement
 *
 * This allows us to prevent things like placing a gen when trying to open a door without sneaking, or placing
 * a gen when opening a crafting table etc- basically make it act like a normal block
 */
export function interactBlockIsValid(block, player) {
    const hasInv = block.getComponent("inventory");
    if (hasInv && !player.isSneaking) return false;

    if (block.typeId === "minecraft:grindstone" && !player.isSneaking)
        return false;
    if (block.typeId === "minecraft:ender_chest" && !player.isSneaking)
        return false;
    if (block.typeId === "minecraft:loom" && !player.isSneaking) return false;
    if (block.typeId === "minecraft:stonecutter_block" && !player.isSneaking)
        return false;
    if (block.typeId === "minecraft:noteblock" && !player.isSneaking)
        return false;
    if (block.typeId === "minecraft:crafter" && !player.isSneaking)
        return false;
    if (block.typeId === "minecraft:decorated_pot" && !player.isSneaking)
        return false;
    if (block.typeId === "minecraft:lever" && !player.isSneaking) return false;

    if (
        block.typeId.startsWith("minecraft:daylight_detector") &&
        !player.isSneaking
    )
        return false;

    if (block.typeId.includes("door") && !player.isSneaking) return false;
    if (block.typeId.includes("gate") && !player.isSneaking) return false;
    if (block.typeId.includes("table") && !player.isSneaking) return false;
    if (block.typeId.includes("anvil") && !player.isSneaking) return false;
    if (block.typeId.includes("frame") && !player.isSneaking) return false;

    if (block.typeId.endsWith("_repeater") && !player.isSneaking) return false;
    if (block.typeId.endsWith("_comparator") && !player.isSneaking)
        return false;
    if (block.typeId.endsWith("_shelf") && !player.isSneaking) return false;
    if (block.typeId.endsWith("_button") && !player.isSneaking) return false;

    return true;
}

/** If block is replaceable by using a gen egg on them */
export function blockIsReplaceable(usedOnBlockPermutation) {
    const type = usedOnBlockPermutation.type.id;

    const list = [
        "minecraft:sculk_vein",
        "minecraft:snow_layer",
        "minecraft:crimson_roots",
        "minecraft:warped_roots",
        "minecraft:seagrass",
        "minecraft:short_dry_grass",
        "minecraft:short_grass",
        "minecraft:tall_dry_grass",
        "minecraft:tall_grass",
        "minecraft:dry_grass",
        "minecraft:leaf_litter",
        "minecraft:bush",
        "minecraft:deadbush",
        "minecraft:glow_lichen",
        "minecraft:fern",
        "minecraft:large_fern",
        "minecraft:nether_sprouts",
        "minecraft:vine",
    ];

    // world.sendMessage(type);

    if (list.includes(type)) return true;
    return false;
}

/** If the target block IS solid and not a liquid or air, return true; else false */
export function blockIsSolid(block) {
    if (block.isSolid) return true;
    return false;
}

/** If target block is loaded or not */
export function blockIsLoaded(dimension, location) {
    if (dimension.getBlock(location)) return true;
    return false;
}
