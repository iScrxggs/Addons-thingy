export function vector3ToString(location) {
    const { x, y, z } = location;
    return `${x},${y},${z}`;
}

export function stringToVector3(string) {
    const args = string.split(",");
    return { x: +args[0], y: +args[1], z: +args[2] };
}
