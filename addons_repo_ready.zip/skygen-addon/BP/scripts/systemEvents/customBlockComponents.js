import { BlockPermutation, ItemStack, system, world } from "@minecraft/server";
import { AutoMiner } from "../systems/autoMiner/AutoMiner";
import { EXPERIENCE_TANK_PREFIX, MINER_LEVEL_PREFIX } from "../constants";
import { devLog } from "../systems/DeveloperMode";
import { vector3ToString } from "../utils/Locations";
import { ItemStorer } from "../systems/itemStorer/ItemStorer";
import { ExperienceTank } from "../systems/experienceTank/ExperienceTank";

system.beforeEvents.startup.subscribe((data) => {
    const { blockComponentRegistry } = data;

    // Auto Miner Components
    blockComponentRegistry.registerCustomComponent("msc_miner:place", {
        beforeOnPlayerPlace(event) {
            const { block, dimension, player } = event;

            devLog(
                `${player.name}[${player.uid}] placed §bAuto Miner [Lv${player.lastAutoMinerLv}] §e@${vector3ToString(block.location)}`,
            );
            system.run(() => {
                AutoMiner.add(
                    dimension,
                    block.location,
                    player,
                    player.lastAutoMinerLv,
                );
            });
        },
    });

    // Experience Tank Components
    blockComponentRegistry.registerCustomComponent("msc:experience_tank", {
        beforeOnPlayerPlace(event) {
            const { block, dimension, player } = event;

            devLog(
                `${player.name}[${player.uid}] placed §bExperience Tank [EXP:${player.lastExpTankEXP}] §e@${vector3ToString(block.location)}`,
            );
            system.run(() => {
                ExperienceTank.add(
                    dimension,
                    block.location,
                    player,
                    player.lastExpTankEXP,
                );
            });
        },
    });

    // Storage Addon Components
    blockComponentRegistry.registerCustomComponent("msc:item_storer", {
        beforeOnPlayerPlace(event) {
            const { block, dimension, player } = event;
            const location = block.location;

            system.run(() => {
                ItemStorer.add(dimension, location, player);
            });
        },
        onTick(event) {
            const { block } = event;
            const rotation = block.permutation.getState(
                "minecraft:cardinal_direction",
            );
            const pipes = block.permutation.getState("msc:pipes");
            const blockUnder = block.below();

            // If block under has an inventory and pipes are not enabled
            if (blockUnder?.getComponent("inventory") && !pipes) {
                const permutation = BlockPermutation.resolve(block.typeId, {
                    "msc:pipes": true,
                    "minecraft:cardinal_direction": rotation,
                });
                system.run(() => {
                    block.setPermutation(permutation);
                });
            }

            if (!blockUnder.getComponent("inventory") && pipes) {
                const permutation = BlockPermutation.resolve(block.typeId, {
                    "msc:pipes": false,
                    "minecraft:cardinal_direction": rotation,
                });
                system.run(() => {
                    block.setPermutation(permutation);
                });
            }
        },
    });
});

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const inv = player.getComponent("inventory").container;

        for (let i = 0; i < inv.size; i++) {
            if (!inv.getItem(i)) continue;

            // Auto Miner Lore
            if (inv.getItem(i).typeId === "msc:auto_miner") {
                let lore = inv.getItem(i).getLore();
                if (lore.length < 1) {
                    // Set new item
                    const newItem = new ItemStack(
                        "msc:auto_miner",
                        inv.getItem(i).amount,
                    );
                    newItem.setLore([MINER_LEVEL_PREFIX + 1]);
                    inv.setItem(i, newItem);
                    lore = [MINER_LEVEL_PREFIX];
                }

                player.lastAutoMinerLv = +lore[0].replaceAll(
                    MINER_LEVEL_PREFIX,
                    "",
                );
                continue;
            }

            // Experience Tank
            if (inv.getItem(i).typeId === "msc:experience_tank") {
                let lore = inv.getItem(i).getLore();
                if (lore.length < 1) {
                    // Set new item
                    const newItem = new ItemStack(
                        "msc:experience_tank",
                        inv.getItem(i).amount,
                    );
                    newItem.setLore([EXPERIENCE_TANK_PREFIX + 0]);
                    inv.setItem(i, newItem);
                    lore = [EXPERIENCE_TANK_PREFIX];
                }

                player.lastExpTankEXP = +lore[0].replaceAll(
                    EXPERIENCE_TANK_PREFIX,
                    "",
                );
                continue;
            }
        }
    }
});

//TODO: Make this better at some point
// Experience Tank Lore Stored EXP
system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        const inv = player.getComponent("inventory").container;
        const heldSlot = player.selectedSlotIndex;

        // If found item is NOT an autominer
        if (
            !inv.getItem(heldSlot) ||
            inv.getItem(heldSlot).typeId !== "msc:experience_tank"
        ) {
            continue;
        }
    }
});
