import { system } from "@minecraft/server";
import { ItemStorer } from "../systems/itemStorer/ItemStorer";
import { ExperienceTank } from "../systems/experienceTank/ExperienceTank";
import { AutoMiner } from "../systems/autoMiner/AutoMiner";

system.beforeEvents.shutdown.subscribe(() => {
    system.run(() => {
        ItemStorer.save();
        ExperienceTank.save();
        AutoMiner.save();
    });
});
