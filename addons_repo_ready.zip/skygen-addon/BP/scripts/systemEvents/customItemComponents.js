import { ItemStack, system, world } from "@minecraft/server";
import { BLOCKTYPE_NUM } from "../constants";
import { Generator } from "../systems/gens/GenData";
import { blockIsReplaceable, grabBlockInfront } from "../utils/Blocks";
import { vector3ToString } from "../utils/Locations";

system.beforeEvents.startup.subscribe((data) => {
    const { itemComponentRegistry } = data;

    // Gen Eggs
    for (const type of Object.keys(BLOCKTYPE_NUM)) {
        itemComponentRegistry.registerCustomComponent(`msc_gen:${type}`, {
            onUseOn(event) {
                const {
                    block,
                    source: player,
                    blockFace,
                    usedOnBlockPermutation,
                } = event;

                const dimension = block.dimension;
                let placedLocation = grabBlockInfront(
                    block.location,
                    blockFace,
                );

                if (blockIsReplaceable(usedOnBlockPermutation)) {
                    placedLocation = block.location;
                }

                const dimId = dimension.id;
                const xyz = vector3ToString(placedLocation);

                // system.runTimeout(() => {
                if (
                    dimension.getBlock(placedLocation).typeId !==
                    "msc:blockgen_placeholder"
                ) {
                    return;
                }
                // }, 1);

                if (Generator.data[dimId][xyz]) {
                    const typeId = `msc:${type}_gen`;
                    const item = new ItemStack(typeId);
                    dimension.spawnItem(item, placedLocation);
                    return;
                }

                // player.genPlacementCooldown = 10;
                Generator.add(player, placedLocation, type, block.dimension);
            },
        });
    }
});
