import {
    CommandPermissionLevel,
    CustomCommandParamType,
    CustomCommandStatus,
    system,
    world,
} from "@minecraft/server";
import { mscHelpMenu } from "../systems/commandMenus/mscHelp";
import { SkygenProfileMenu } from "../systems/commandMenus/skygenProfile";
import { SkygenAdminMenu } from "../systems/commandMenus/SkygenAdminMenu";
import { devLog } from "../systems/DeveloperMode";
import { SkygenExchange } from "../systems/SkygenExchange";
import { SkygenProgress } from "../systems/SkygenProgress";
import { SellWand } from "../systems/SellWand";

const devModeCommand = {
    name: "msc:dev",
    description: "Toggles console logs for the pack for developers to view",
    permissionLevel: CommandPermissionLevel.GameDirectors,
};
function toggleDevMode() {
    if (world.devMode) {
        world.devMode = false;
        console.log("§l§d[MSC] §r§cDisabled §bDev Mode§r");
        return { status: CustomCommandStatus.Success };
    }

    world.devMode = true;
    console.log("§l§d[MSC] §r§aEnabled §bDev Mode§r");
    return { status: CustomCommandStatus.Success };
}

const realmDevModeCommand = {
    name: "msc:realmdev",
    description:
        "Toggles console logs for the pack for developers to view (for realms)",
    permissionLevel: CommandPermissionLevel.GameDirectors,
};
function toggleRealmDevMode(origin) {
    const player = origin.sourceEntity;
    if (world.realmDevMode) {
        world.realmDevMode = false;
        system.run(() => {
            devLog("§l§d[MSC] §r§cDisabled §bRealm Dev Mode§r");
            player.removeTag("mscRealmDev");
        });
        return { status: CustomCommandStatus.Success };
    }

    world.realmDevMode = true;
    system.run(() => {
        player.addTag("mscRealmDev");
        devLog("§l§d[MSC] §r§aEnabled §bRealm Dev Mode§r");
    });
    return { status: CustomCommandStatus.Success };
}

const modeTypes = {
    c: "Creative",
    s: "Survival",
    a: "Adventure",
    sp: "Spectator",
};
function modeName(type) {
    return `msc:gm${type}`;
}
function modeDesc(type) {
    return `Sets a player's game mode to ${modeTypes[type]}.`;
}

function runGamemodeCommand(origin, targets, mode, message) {
    const sendCmdFeedback = world.gameRules.sendCommandFeedback;
    const player = origin.sourceEntity;

    if (Array.isArray(targets)) {
        if (!targets[0]) {
            return {
                status: CustomCommandStatus.Failure,
                message: "No targets matched selector",
            };
        }

        for (const entry of targets) {
            gmCommands(entry, mode);
            if (sendCmdFeedback) entry.sendMessage(message);
        }
        return { status: CustomCommandStatus.Success };
    }

    if (gmCommands(player, mode)) {
        if (sendCmdFeedback) player.sendMessage(message);
        return { status: CustomCommandStatus.Success };
    }
    return { status: CustomCommandStatus.Failure };
}

function gmc(origin, targets) {
    return runGamemodeCommand(
        origin,
        targets,
        "Creative",
        "Your game mode has been updated to Creative",
    );
}
function gms(origin, targets) {
    return runGamemodeCommand(
        origin,
        targets,
        "Survival",
        "Your game mode has been updated to Survival",
    );
}
function gma(origin, targets) {
    return runGamemodeCommand(
        origin,
        targets,
        "Adventure",
        "Your game mode has been updated to Adventure",
    );
}
function gmsp(origin, targets) {
    return runGamemodeCommand(
        origin,
        targets,
        "Spectator",
        "Your game mode has been updated to Spectator",
    );
}

function gmCommands(player, gamemode) {
    if (!player || player.typeId !== "minecraft:player") return false;
    system.run(() => {
        player.setGameMode(gamemode);

        if (world.gameRules.sendCommandFeedback) {
            player.sendMessage(`Set own game mode to ${gamemode}`);
        }
    });
    return true;
}

const helpCommand = {
    name: "msc:mschelp",
    description:
        "Opens a form where you can look into the different features of the pack",
    permissionLevel: CommandPermissionLevel.Any,
};
function helpCommandFunction(origin) {
    system.run(() => {
        const player = origin.sourceEntity;
        if (!player || player.typeId !== "minecraft:player") return;
        new mscHelpMenu(player);
    });
}

const skygenProfileCommand = {
    name: "msc:skygen",
    description: "Opens your SkyGen progress and exchange menu",
    permissionLevel: CommandPermissionLevel.Any,
};
function skygenProfileCommandFunction(origin) {
    system.run(() => {
        const player = origin.sourceEntity;
        if (!player || player.typeId !== "minecraft:player") return;
        new SkygenProfileMenu(player);
    });
}

const tokenBalanceCommand = {
    name: "msc:tokens",
    description: "Shows your token, money, and exchange status",
    permissionLevel: CommandPermissionLevel.Any,
};
function tokenBalanceCommandFunction(origin) {
    system.run(() => {
        const player = origin.sourceEntity;
        if (!player || player.typeId !== "minecraft:player") return;

        const progress = SkygenProgress.get(player.uid);
        const state = SkygenExchange.getExchangeState(player);
        player.sendMessage(
            `\u00A76* [MSC] Tokens: \u00A7e${progress.tokens.toLocaleString("en-US")} \u00A77| \u00A72Money: \u00A7a$${state.money.toLocaleString("en-US")} \u00A77| \u00A7cCashout room: \u00A7f$${state.remainingCashout.toLocaleString("en-US")}`,
        );
    });
}

const exchangeCommand = {
    name: "msc:exchange",
    description: "Opens the token exchange menu",
    permissionLevel: CommandPermissionLevel.Any,
};
function exchangeCommandFunction(origin) {
    system.run(() => {
        const player = origin.sourceEntity;
        if (!player || player.typeId !== "minecraft:player") return;
        new SkygenProfileMenu(player);
    });
}

const skygenAdminCommand = {
    name: "msc:skygenadmin",
    description: "Opens the SkyGen admin config menu",
    permissionLevel: CommandPermissionLevel.GameDirectors,
};
function skygenAdminCommandFunction(origin) {
    system.run(() => {
        const player = origin.sourceEntity;
        if (!player || player.typeId !== "minecraft:player") return;
        new SkygenAdminMenu(player);
    });
}

const sellWandCommand = {
    name: "msc:sellwand",
    description: "Gives you the MSC Sell Wand",
    permissionLevel: CommandPermissionLevel.Any,
};
function sellWandCommandFunction(origin) {
    system.run(() => {
        const player = origin.sourceEntity;
        if (!player || player.typeId !== "minecraft:player") return;

        const given = SellWand.giveSellWand(player);
        if (!given) {
            player.sendMessage("\u00A7c* [MSC] Could not give Sell Wand right now.");
            return;
        }

        player.sendMessage(
            "\u00A7a* [MSC] You received a \u00A76Sell Wand\u00A7a. Use it on your Item Storer, chest, or double chest to cash out stored items.",
        );
    });
}

system.beforeEvents.startup.subscribe((init) => {
    const commandRegistry = init.customCommandRegistry;

    commandRegistry.registerCommand(devModeCommand, toggleDevMode);
    commandRegistry.registerCommand(realmDevModeCommand, toggleRealmDevMode);
    commandRegistry.registerCommand(helpCommand, helpCommandFunction);
    commandRegistry.registerCommand(
        skygenProfileCommand,
        skygenProfileCommandFunction,
    );
    commandRegistry.registerCommand(
        tokenBalanceCommand,
        tokenBalanceCommandFunction,
    );
    commandRegistry.registerCommand(exchangeCommand, exchangeCommandFunction);
    commandRegistry.registerCommand(
        skygenAdminCommand,
        skygenAdminCommandFunction,
    );
    commandRegistry.registerCommand(sellWandCommand, sellWandCommandFunction);

    for (const type of Object.keys(modeTypes)) {
        const commandDetails = {
            name: modeName(type),
            description: modeDesc(type),
            permissionLevel: CommandPermissionLevel.GameDirectors,
            optionalParameters: [
                {
                    name: "player",
                    type: CustomCommandParamType.PlayerSelector,
                },
            ],
        };

        let commandFunction = false;
        if (type === "c") commandFunction = gmc;
        if (type === "s") commandFunction = gms;
        if (type === "a") commandFunction = gma;
        if (type === "sp") commandFunction = gmsp;

        commandRegistry.registerCommand(commandDetails, commandFunction);
    }
});
