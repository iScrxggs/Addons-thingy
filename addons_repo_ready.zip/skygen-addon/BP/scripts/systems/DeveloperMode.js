import { World, world } from "@minecraft/server";

/** Realm Tester Broadcast */
function broadcastRealmTest(message) {
    for (const player of world.getAllPlayers()) {
        if (!player.hasTag("mscRealmDev")) continue;
        player.sendMessage("§a" + message);
    }
}

/** Sends a console log message IF world is in devMode */
export function devLog(message) {
    if (world.realmDevMode) {
        broadcastRealmTest(message);
    }
    if (world.devMode) {
        console.log(`§l§d[MSC] §r§a${message}§r`);
    }
}

// You can toggle devMode by doing 'world.devMode = true'
Object.defineProperty(World.prototype, "devMode", {
    get() {
        /** If the uid exists, return the value */
        if (this.getDynamicProperty("devMode"))
            return this.getDynamicProperty("devMode");

        return false;
    },
    set(boolean) {
        this.setDynamicProperty("devMode", boolean);
    },
});

// You can toggle devMode by doing 'world.devMode = true'
Object.defineProperty(World.prototype, "realmDevMode", {
    get() {
        /** If the uid exists, return the value */
        if (this.getDynamicProperty("realmDevMode"))
            return this.getDynamicProperty("realmDevMode");

        return false;
    },
    set(boolean) {
        this.setDynamicProperty("realmDevMode", boolean);
    },
});
