import { Dimension, ItemStack, Player, system, world } from "@minecraft/server";
import { stringToVector3, vector3ToString } from "../../utils/Locations";
import { splitByLength } from "../../utils/Formats";
import { devLog } from "../DeveloperMode";
import { DIMENSION_NUM, EXPERIENCE_TANK_PREFIX } from "../../constants";
import { isOpInGMC, targetIsOnline } from "../../utils/Player";
import { EXPERIENCE_TANK_SOUNDS } from "../../sounds";
import { centerLocation } from "../../utils/Blocks";

export class ExperienceTank {
    /**
     *  data = {
     *      "minecraft:overworld": {
     *          "x,y,z": { owner: player.uid, storedExp: 0 }
     *      },
     *      "minecraft:the_nether": {},
     *      "minecraft:the_end": {}
     *  }
     */
    static data = {
        "minecraft:overworld": {},
        "minecraft:nether": {},
        "minecraft:the_end": {},
    };

    // ------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------

    /** Initialising the dynamic properties */
    static init() {
        // Load Data Parts
        this.loadParts();
    }

    /** Loads each dynamic property into a list, joins it then parses it into this.data */
    static loadParts() {
        // If the gen parts do not exist prior, make them exist
        if (!world.getDynamicProperty("msc:ExpTankDataParts")) {
            world.setDynamicProperty("msc:ExpTankDataParts", 0);
        }

        // Amount of parts already stored
        const partsAmt = world.getDynamicProperty("msc:ExpTankDataParts");
        const parts = [];

        // For part, push to the string list
        for (let i = 0; i < partsAmt; i++) {
            const property = world.getDynamicProperty(`msc:ExpTankData${i}`);
            parts.push(property);
        }

        // After all parts are pushed, join then parse it to this.data
        const property = parts.join("");
        if (property === "") return;

        // Sets this.data
        this.data = JSON.parse(parts.join(""), null, "\t");
        devLog(`§6Loaded §bExperience Tank§6 data [§b${parts.length} parts§6]`);
    }

    /** Saves the data into multiple dynamic property parts to have infinite storage over theoretically infinite dynamic properties */
    static save(log = true) {
        const charactersPerPart = 10000;

        // New amount of parts
        const parts = splitByLength(
            JSON.stringify(this.data),
            charactersPerPart,
        );

        // Save part indexes as ordered in the parts lsit
        for (let i = 0; i < parts.length; i++) {
            world.setDynamicProperty(`msc:ExpTankData${i}`, parts[i]);
        }

        world.setDynamicProperty("msc:ExpTankDataParts", parts.length);
        if (log) {
            system.runTimeout(() => {
                devLog(
                    `§6Saved §bExperience Tank§6 data [§b${parts.length} parts§6]`,
                );
            }, 1);
        }
    }

    // ------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------

    /**
     * Returns true/false is the player is the owner of the specififed
     * @param {Dimension.id} dimensionId
     * @param {String} locationString
     * @param {Player} player
     * @returns {Boolean}
     */
    static isOwner(dimensionId, locationString, player) {
        const ownerUID = this.data[dimensionId][locationString].owner;
        if (ownerUID === player.uid) return true;
        return false;
    }

    // ------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------

    /**
     * Adds an experience tank to the database
     * @param {Dimension} dimension
     * @param {Vector3} location
     * @param {Player} player,
     * @param {Number} exp
     */
    static add(dimension, location, player, exp = 0) {
        const xyz = vector3ToString(location);
        const dim = dimension.id;

        /** Add data entry */
        this.data[dim][xyz] = {
            owner: player.uid,
            storedExp: exp,
        };

        /** Sounds */
        const soundOnPlace = EXPERIENCE_TANK_SOUNDS.onPlace;
        dimension.playSound(
            soundOnPlace.string,
            location,
            soundOnPlace.optional,
        );

        /** Saves data */
        this.save();
    }

    /**
     * Removes a exp tank from the database
     * @param {Dimension} dimension
     * @param {Vector3} location
     * @param {Player} player
     */
    static remove(dimension, location, player) {
        const xyz = vector3ToString(location);
        const dim = dimension.id;
        const data = this.data[dim][xyz];
        const soundOnBreak = EXPERIENCE_TANK_SOUNDS.onBreak;
        const soundOnFailBreak = EXPERIENCE_TANK_SOUNDS.failBreak;

        // Prevents false errors
        if (!this.data[dim][xyz]) return;

        // If in creative & operator
        if (isOpInGMC(player)) {
            // Remove Data
            this.removeAllEntries(dim, xyz);

            // Log deleted experience tank
            devLog(
                `${player.name}[${player.uid}] §cdeleted §bExperience Tank [Exp:${data.storedExp}] §e@${xyz}`,
            );

            // Playsound
            dimension.playSound(
                soundOnBreak.string,
                centerLocation(location),
                soundOnBreak.optional,
            );
            return;
        }

        // If is owner and not an OP in creative
        if (this.isOwner(dim, xyz, player)) {
            // Remove Data
            this.removeAllEntries(dim, xyz);

            // Log picked up experience tank
            devLog(
                `${player.name}[${player.uid}] picked up §bExperience Tank [Exp:${data.storedExp}] §e@${xyz}`,
            );

            // Playsound
            dimension.playSound(
                soundOnBreak.string,
                centerLocation(location),
                soundOnBreak.optional,
            );

            // * Item Stack
            const inv = player.getComponent("inventory").container;
            const newLocation = centerLocation(location);
            const newItem = new ItemStack("msc:experience_tank");
            newItem.setLore([EXPERIENCE_TANK_PREFIX + data.storedExp]);

            // If space in player inventory, add item and return
            if (inv.emptySlotsCount > 0) {
                inv.addItem(newItem);
                dimension.setBlockType(location, "minecraft:air");
                return;
            }

            // If no space, spawn it on ground and return
            dimension.spawnItem(newItem, newLocation);
            dimension.setBlockType(location, "minecraft:air");
            return;
        }

        // If not owner or admin in creative
        player.sendMessage(
            "§c* [MSC] This experience tank does not belong to you!",
        );
        player.playSound(soundOnFailBreak.string, soundOnFailBreak.optional);
        return;
    }

    /**
     * Removes all data entries and all floating text entities if present
     * @param {Dimension.id} dimensionId
     * @param {String} locationString
     */
    static removeAllEntries(dimensionId, locationString) {
        delete this.data[dimensionId][locationString];
        this.save();

        // Remove floating text, if it exists
        const location = centerLocation(stringToVector3(locationString));
        const dimension = world.getDimension(dimensionId);

        const textQuery = {
            type: "msc:floating_text",
            location: location,
            maxDistance: 1,
        };
        const floatingText = [...dimension.getEntities(textQuery)][0];
        if (floatingText) floatingText.remove();
    }

    // ------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------

    /**
     * If experience orbs are nearby, remove them and store the exp
     * @param {Dimension} dimension
     * @param {Vector3} location
     */
    static storeExp(dimension, location) {
        const xyz = vector3ToString(location);
        const dim = dimension.id;

        // Entity query for xp orbs within 2 blocks from this location
        const query = {
            type: "xp_orb",
            location: centerLocation(location),
            maxDistance: 3,
        };

        // If no exp orbs nearby, return
        const expOrbs = [...dimension.getEntities(query)];
        if (!expOrbs[0]) return;

        // Adds 1-3 experience per orb then removes the entity
        for (const expOrb of expOrbs) {
            const addedAmt = Math.floor(Math.random() * 3) + 1;
            this.data[dim][xyz].storedExp += addedAmt;
            expOrb.remove();
        }
    }

    /**
     * If container is above block, repair all items by 1 durability for 1 stored exp
     * @param {Dimension} dimension
     * @param {Vector3} location
     */
    static tryMend(dimension, location) {
        const xyz = vector3ToString(location);
        const dim = dimension.id;

        // If no exp, return
        if (this.data[dim][xyz].storedExp === 0) return;

        // If block above does NOT have a container, return
        const block = dimension.getBlock(location).above();
        const inv = block.getComponent("inventory")?.container;
        if (!inv) return;

        // If it does, check the slots to look for damaged equipment
        for (let i = 0; i < inv.size; i++) {
            const item = inv.getItem(i);

            // If no item or stored exp left, return
            const expLeft = this.data[dim][xyz].storedExp;
            if (!item || expLeft === 0) return;

            // If no durability component OR the damage is 0, continue
            const durability = item.getComponent("durability");
            if (!durability || durability.damage === 0) continue;

            // If damage is over max durability (ex: 32766) then act as its at the max it can be
            const damage = durability.damage;
            const maxDurability = durability.maxDurability;
            let newDamage = durability.damage - 1;
            if (damage > maxDurability) newDamage = maxDurability - 1;

            // Use stored EXP
            this.data[dim][xyz].storedExp -= 1;

            // Replaced old item with repaired item
            const newItem = item.clone();
            newItem.getComponent("durability").damage = newDamage;
            inv.setItem(i, newItem);
        }
    }

    /**
     * Crafts experience bottles from glass bottles when interacting on an Experience Tank with them
     * @param {Dimension} dimension
     * @param {Vector3} location
     * @param {Player} player
     * @param {ItemStack} itemStack
     */
    static makeExpBottles(dimension, location, player, itemStack) {
        const xyz = vector3ToString(location);
        const dim = dimension.id;
        const storedExp = this.data[dim][xyz].storedExp;
        const soundOnFailCraft = EXPERIENCE_TANK_SOUNDS.failCraft;
        const soundOnCraft = EXPERIENCE_TANK_SOUNDS.onCraft;

        // If not enough experience for 1 bottle, return
        if (storedExp < 15) {
            player.playSound(
                soundOnFailCraft.string,
                soundOnFailCraft.optional,
            );
            player.sendMessage("§c* [MSC] Not enough stored experience!");
            return;
        }

        // Craft as much as possible
        const inv = player.getComponent("inventory").container;
        const potential = Math.floor(storedExp / 15);
        const heldSlot = player.selectedSlotIndex;
        const newGlassBottles = new ItemStack(itemStack.typeId);
        const newExpBottles = new ItemStack("minecraft:experience_bottle");

        // Playsound
        dimension.playSound(
            soundOnCraft.string,
            centerLocation(location),
            soundOnCraft.optional,
        );

        // If potential is less than the amount of glass bottles used on it, use all the potential ones and return
        if (potential < itemStack.amount) {
            // Dev Log
            devLog(
                `${player.name}[${player.uid}] withdrew §b${potential * 15}EXP §afrom §bExperience Tank §e@${xyz}`,
            );

            // Glass Bottles
            const newAmt = itemStack.amount - potential;
            newGlassBottles.amount = newAmt;
            inv.setItem(heldSlot, newGlassBottles);

            // Use stored EXP
            this.data[dim][xyz].storedExp -= potential * 15;

            // If no inventory space
            newExpBottles.amount = potential;
            if (inv.emptySlotsCount === 0) {
                dimension.spawnItem(newExpBottles, player.location);
                return;
            }

            // If inventory space
            inv.addItem(newExpBottles);
            return;
        }

        // Dev Log
        devLog(
            `${player.name}[${player.uid}] withdrew §b${itemStack.amount * 15}EXP §afrom §bExperience Tank §e@${xyz}`,
        );

        // If potential is higher, replace itemstack
        newExpBottles.amount = itemStack.amount;
        inv.setItem(heldSlot, newExpBottles);

        // Use stored EXP
        this.data[dim][xyz].storedExp -= itemStack.amount * 15;
    }
}

// Intialises Experience Tank data
system.run(() => {
    ExperienceTank.init();
});

// Every 5 ticks (0.25s), attempt to store experience
const dimensions = Object.keys(DIMENSION_NUM);
system.runInterval(() => {
    for (const dimension of dimensions) {
        // For storing experience if they are loaded & if the owner is online
        for (const xyz of Object.keys(ExperienceTank.data[dimension])) {
            // If owner of the machine is not online; skip
            const ownerUID = ExperienceTank.data[dimension][xyz].owner;
            if (!targetIsOnline(ownerUID)) continue;

            // Attempt to store experience
            const dim = world.getDimension(dimension);
            if (!dim.getBlock(stringToVector3(xyz))) continue;

            ExperienceTank.storeExp(dim, stringToVector3(xyz));
        }
    }
}, 5);

// Every 1s, repair 1 durability
system.runInterval(() => {
    for (const dimension of dimensions) {
        for (const xyz of Object.keys(ExperienceTank.data[dimension])) {
            const dim = world.getDimension(dimension);
            const location = stringToVector3(xyz);

            // Attempt to mend items above
            if (!dim.getBlock(location)) continue;

            // If loaded but is not present anymore
            if (dim.getBlock(location).typeId !== "msc:experience_tank") {
                devLog(
                    `§cRemoved §aunpresent §bExperience Tank §aentry from data`,
                );
                ExperienceTank.removeAllEntries(dimension, xyz);
                continue;
            }

            const ownerUID = ExperienceTank.data[dimension][xyz].owner;
            if (!targetIsOnline(ownerUID)) continue;

            ExperienceTank.tryMend(dim, location);
        }
    }
}, 20);

// Autosave every 10s, this is just incase of a crash there is a backup to fall on
system.runInterval(() => {
    system.run(() => {
        // false = does NOT log everytime autosave happens
        ExperienceTank.save(false);
    });
}, 200);
