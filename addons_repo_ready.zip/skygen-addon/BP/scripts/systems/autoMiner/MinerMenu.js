import { ActionFormData, ModalFormData, UIManager } from "@minecraft/server-ui";
import { AutoMiner } from "./AutoMiner";
import { vector3ToString } from "../../utils/Locations";
import { PlayerData } from "../PlayerData";
import { devLog } from "../DeveloperMode";
import { ItemStack, world } from "@minecraft/server";
import { formatNumber } from "../../utils/Formats";
import { MINER_LEVEL_PREFIX } from "../../constants";
import { AUTOMINER_SOUNDS } from "../../sounds";
import { centerLocation } from "../../utils/Blocks";

export class MinerMenu {
    constructor(dimension, location, player, adminView = false) {
        this.dimension = dimension;
        this.location = location;
        this.player = player;

        this.dimensionId = dimension.id;
        this.locationString = vector3ToString(location);
        this.player.menuLocation = vector3ToString(location);

        if (!adminView) {
            this.main();
            return;
        }
        this.adminMain();
    }

    // ----------------------- PLAYER VIEW

    // Player Main Menu
    main() {
        const minerData = AutoMiner.data[this.dimensionId][this.locationString];
        const owner = PlayerData.data[minerData.owner].name;
        const cost = +AutoMiner._calculateLvCost(minerData.level);
        const speedNow = AutoMiner._calculateSpeed(minerData.level);
        const nextSpeed = AutoMiner._calculateSpeed(minerData.level + 1);

        const list = [
            `\n§aPlaced by §b${owner}\n§aLevel: §e${minerData.level}/${AutoMiner.config.maxLevel}` +
                `\n§aMine Speed: §e${speedNow} ticks\n` +
                `\n§aNext Level Up:` +
                `\n§e* ${speedNow}t -> ${nextSpeed}t` +
                `\n* $${formatNumber(cost)}\n `,
            ``,
        ];

        const form = new ActionFormData()
            .title("Auto Miner Menu")
            .body(list.join("\n"))
            .button("Close Menu")
            .button("Level Up", "textures/blocks/barrier");

        form.show(this.player).then((formData) => {
            if (formData.canceled) {
                this.player.menuLocation = "";
                return;
            }

            // Close Menu
            if (formData.selection === 0) {
                this.player.menuLocation = "";
                return;
            }

            // Level Up
            // this.tryLevelUp();
            this.player.menuLocation = "";
            this.player.playSound("note.bass");
            this.player.sendMessage("§c* [MSC] Not implemented yet!");
        });
    }

    // Attempts to level up miner
    tryLevelUp() {
        const minerData = AutoMiner.data[this.dimensionId][this.locationString];
        const soundOnUpgrade = AUTOMINER_SOUNDS.onUpgrade;
        const soundOnFailUpgrade = AUTOMINER_SOUNDS.onFailUpgrade;

        // TODO: Link this with player money later on!
        const cap = AutoMiner.config.maxLevel;

        // FAIL IF CAPPED
        if (minerData.level >= cap) {
            // Playsound & Message
            this.player.playSound(
                soundOnFailUpgrade.string,
                soundOnFailUpgrade.optional,
            );
            this.player.sendMessage(
                "§c* [MSC] You are already maxxed out in the auto miner level!",
            );

            // Dev Log
            devLog(
                `${this.player.name}[${this.player.uid}] §cfailed §aexceeding §bAuto Miner §alevel cap §e@${this.locationString}`,
            );
            return;
        }

        // FAIL IF NOT ENOUGH MONEY
        const moneyReq = AutoMiner._calculateLvCost(minerData.level);
        const money = AutoMiner._calculateLvCost(minerData.level);
        if (money < moneyReq) {
            // Playsound & Message
            this.player.playSound(
                soundOnFailUpgrade.string,
                soundOnFailUpgrade.optional,
            );
            this.player.sendMessage("§c* [MSC] Not enough money to upgrade!");

            // Dev Log
            devLog(
                `${this.player.name}[${this.player.uid}] §cdoesn't §ahave enough $ for §bAuto Miner §alevel up §e@${this.locationString} §a[Lv${minerData.level}->${minerData.level + 1}]`,
            );
            return;
        }

        // Dev Log
        devLog(
            `${this.player.name}[${this.player.uid}] upgraded §bAuto Miner §e@${this.locationString} §a[Lv${minerData.level - 1} => ${minerData.level}]`,
        );

        // Playsound
        this.dimension.playSound(
            soundOnUpgrade.string,
            centerLocation(this.location),
            soundOnUpgrade.optional,
        );

        // Upgrade
        AutoMiner.data[this.dimensionId][this.locationString].level += 1;
        AutoMiner.save();
    }

    // ----------------------- ADMIN VIEW

    // Admin Menu
    adminMain() {
        const minerData = AutoMiner.data[this.dimensionId][this.locationString];
        const owner = PlayerData.data[minerData.owner].name;
        const cost = +AutoMiner._calculateLvCost(minerData.level);
        const speedNow = AutoMiner._calculateSpeed(minerData.level);
        const nextSpeed = AutoMiner._calculateSpeed(minerData.level + 1);

        const list = [
            `\n§aPlaced by §b${owner}\n§aLevel: §e${minerData.level}/${AutoMiner.config.maxLevel}\n` +
                `§aMine Speed: §e${speedNow} ticks\n\n§aNext Level Up:\n§e* ${speedNow}t -> ${nextSpeed}t\n* $${formatNumber(cost)}\n `,
            ``,
        ];

        const form = new ActionFormData()
            .title("Auto Miner Menu")
            .body(list.join("\n"))
            .button("Close Menu")
            .button("Change Config", "textures/ui/icon_setting")
            .button("Pickup", "textures/ui/msc/auto_miner");

        form.show(this.player).then((formData) => {
            if (formData.canceled) {
                this.player.menuLocation = "";
                return;
            }

            // Close Menu
            if (formData.selection === 0) {
                this.player.menuLocation = "";
                return;
            }

            // Change Config
            if (formData.selection === 1) {
                this.changeConfig();
                return;
            }

            // Pickup Miner
            if (formData.selection === 2) {
                // Removes miner (counts as deleted)
                AutoMiner.remove(this.dimension, this.location, this.player);
                this.dimension.setBlockType(this.location, "minecraft:air");

                // * Item Stack
                const inv = this.player.getComponent("inventory").container;
                const newLocation = centerLocation(this.location);
                const newItem = new ItemStack("msc:auto_miner");
                newItem.setLore([MINER_LEVEL_PREFIX + minerData.level]);

                // If space in player inventory, add item and return
                if (inv.emptySlotsCount > 0) {
                    inv.addItem(newItem);
                    return;
                }

                // If no space, spawn it on ground and return
                this.dimension.spawnItem(newItem, newLocation);

                // Force Close Other Menus
                // TODO: Update this later? UIManager.closeAllForms(user) doesn't seem to exist rn
                // const menuLocation = this.locationString;
                // for (const user of world.getAllPlayers()) {
                //     if (user.menuLocation === menuLocation) {
                //         UIManager.closeAllForms(user);
                //         this.player.menuLocation = "";
                //     }
                // }
                return;
            }
        });
    }

    // Config Page
    changeConfig() {
        const config = AutoMiner.config;

        const form = new ModalFormData()
            .title("Auto Miner Config")
            .textField(
                "\n§6Base amount of money to level up.§e§o\n" +
                    "Ex: '1,000,000' or '1234'",
                "§bBase Cost",
                {
                    defaultValue: formatNumber(config.baseCost),
                },
            )
            .textField(
                "\n§6Multiplier for exponential cost.§e§o\n" +
                    "Ex: '1.2' means x1.2 of previous price",
                "§bExponential Cost",
                {
                    defaultValue: config.costIncrement + "",
                },
            )
            .textField(
                "\n§6How many ticks it takes to mine at Lv1.§e§o\n" +
                    "Ex: '35' is 1.75 seconds.§b\n" +
                    "1 Second = 20 Ticks\n" +
                    "1 Minute = 1200 Ticks",
                "§bBase Speed",
                {
                    defaultValue: config.baseSpeed + "",
                },
            )
            .textField(
                "\n§6How many levels you can have at max.§e§o" +
                    "\nMax Levels over 1 require Base Speed to be above 0\n" +
                    "\n§r§bMax levels affect how fast each level of the miner is and the max level will always end up with 0 ticks",
                "§bMax Level",
                {
                    defaultValue: config.maxLevel + "",
                },
            );

        form.show(this.player).then((formData) => {
            if (formData.canceled) return;

            const [rawBaseCost, rawCostIncrement, rawBaseSpeed, rawMaxLevel] =
                formData.formValues;

            const name = this.player.name;
            const uid = this.player.uid;

            let changes = {};
            for (const entry of Object.keys(config)) {
                changes[entry] = config[entry];
            }

            const onConfigChange = AUTOMINER_SOUNDS.onConfigChange;
            const onFailConfigChange = AUTOMINER_SOUNDS.failConfigChange;

            // If rawBaseCost was output, update it
            if (rawBaseCost.length > 0) {
                let newValue = +rawBaseCost.trim().replaceAll(",", "");

                // * Is not a number, FAIL
                if (!this.validNumberCheck(newValue)) {
                    // Playsound & Message
                    this.player.sendMessage(
                        "§c* [MSC] Base Cost input is invalid.",
                    );
                    this.player.playSound(
                        onFailConfigChange.string,
                        onFailConfigChange.optional,
                    );

                    // Dev Log
                    devLog(
                        `§cInput: '${newValue}' is not valid for the base cost input.`,
                    );
                    return;
                }

                // * Is valid & new
                if (config.baseCost !== newValue) {
                    // Dev Log
                    devLog(
                        `${name}[${uid}] updated §bAuto Miner §abase cost [§e${config.baseCost} §a-> §e${newValue}§a]`,
                    );

                    // Set New Value
                    changes.baseCost = newValue;
                }
            }

            // If rawCostIncrement was output, update it
            if (rawCostIncrement.length > 0) {
                let newValue = +rawCostIncrement.trim();

                // * Is not a number, FAIL
                if (isNaN(newValue) || newValue < 0) {
                    // Playsound & Message
                    this.player.sendMessage(
                        "§c* [MSC] Cost Multiplier input is invalid.",
                    );
                    this.player.playSound(
                        onFailConfigChange.string,
                        onFailConfigChange.optional,
                    );

                    // Dev Log
                    devLog(
                        `§cInput: '${newValue}' is not valid for the cost multiplier input, saving previous inputs...`,
                    );
                    return;
                }

                // * Is valid & new
                if (config.costIncrement !== newValue) {
                    // Dev Log
                    devLog(
                        `${name}[${uid}] updated §bAuto Miner §acost multiplier [§e${config.costIncrement} §a-> §e${newValue}§a]`,
                    );

                    // Set New Value
                    changes.costIncrement = newValue;
                }
            }

            // If rawBaseSpeed was output, update it
            if (rawBaseSpeed.length > 0) {
                let newValue = +rawBaseSpeed.trim();

                // * Is not a number, FAIL
                if (!this.validNumberCheck(newValue)) {
                    // Playsound & Message
                    this.player.sendMessage(
                        "§c* [MSC] Base Speed input is invalid.",
                    );
                    this.player.playSound(
                        onFailConfigChange.string,
                        onFailConfigChange.optional,
                    );

                    // Dev Log
                    devLog(
                        `§cInput: '${newValue}' is not valid for the base speed input, saving previous inputs...`,
                    );
                    return;
                }

                if (config.baseSpeed !== newValue) {
                    // Dev Log
                    devLog(
                        `${name}[${uid}] updated §bAuto Miner §abase speed [§e${config.baseSpeed} §a-> §e${newValue}§a]`,
                    );

                    // Set new value
                    changes.baseSpeed = newValue;
                }
            }

            // If rawMaxLevel was output, update it
            if (rawMaxLevel.length > 0) {
                let newValue = +rawMaxLevel.trim();

                // * Is not a number, FAIL
                if (!this.validNumberCheck(newValue)) {
                    // Playsound & Message
                    this.player.sendMessage(
                        "§c* [MSC] Max Level input is invalid.",
                    );
                    this.player.playSound(
                        onFailConfigChange.string,
                        onFailConfigChange.optional,
                    );

                    // Dev Log
                    devLog(
                        `§cInput: '${newValue}' is not valid for the max level input, saving previous inputs...`,
                    );
                    return;
                }

                if (config.maxLevel !== newValue) {
                    // Dev Log
                    devLog(
                        `${name}[${uid}] updated §bAuto Miner §amax level [§e${config.maxLevel} §a-> §e${newValue}§a]`,
                    );

                    // Set new value
                    changes.maxLevel = newValue;
                }
            }

            // Playsound
            this.player.playSound(
                onConfigChange.string,
                onConfigChange.optional,
            );

            // Save Miner Config Data
            AutoMiner.config = changes;
            AutoMiner.saveConfig();
        });
    }

    /**
     * Checks if the input number is a string, decimal or negative then returns false, otherwise returns true
     * @param {Number} number
     * @returns {Boolean}
     */
    validNumberCheck(number) {
        // If NaN or decimal return false
        if (!Number.isInteger(number)) return false;

        // If less than 0 (so negative), return false
        if (number < 0) return false;

        // If neither return true
        return true;
    }
}
