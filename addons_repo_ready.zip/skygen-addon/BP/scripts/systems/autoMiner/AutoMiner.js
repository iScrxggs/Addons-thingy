import { Dimension, ItemStack, Player, system, world } from "@minecraft/server";
import { stringToVector3, vector3ToString } from "../../utils/Locations";
import { splitByLength } from "../../utils/Formats";
import { devLog } from "../DeveloperMode";
import { DIMENSION_NUM, MINER_LEVEL_PREFIX } from "../../constants";
import { blockCanBeAutomined, centerLocation } from "../../utils/Blocks";
import { isOpInGMC, targetIsOnline } from "../../utils/Player";
import { AUTOMINER_SOUNDS } from "../../sounds";

const dimensions = Object.keys(DIMENSION_NUM);

const defaultConfig = {
    baseCost: 1_000_000,
    costIncrement: 1.2,
    baseSpeed: 100,
    maxLevel: 1,
};

export class AutoMiner {
    /**
     *  data = {
     *      "minecraft:overworld": {
     *          "xyz": { owner: player.uid, level: 1 }
     *      },
     *      "minecraft:the_nether": {},
     *      "minecraft:the_end": {}
     *  }
     */
    static data = {
        "minecraft:overworld": {},
        "minecraft:nether": {},
        "minecraft:the_end": {},
    };

    /**
     * Config
     * - baseCost      | base gen upgrade cost
     * - costIncrement | how much more expensive per gen upgrade as a multiplier (ex: 1.2 = +20% to previous cost)
     * - baseSpeed     | base auto miner speed (ticks)
     * - maxLevels     | max levels to upgrade for (will always end with 0 ticks)
     */
    static config = {};

    /** Time until next mine */
    static mining = {
        "minecraft:overworld": {},
        "minecraft:nether": {},
        "minecraft:the_end": {},
    };

    // ------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------

    /** Initialising the dynamic properties */
    static init() {
        // Load Config
        if (!world.getDynamicProperty("msc:MinerConfig")) {
            world.setDynamicProperty(
                "msc:MinerConfig",
                JSON.stringify(defaultConfig),
            );
        }
        this.config = JSON.parse(world.getDynamicProperty("msc:MinerConfig"));

        // Load Data Parts
        this.load();

        system.runTimeout(() => {
            for (const dimension of Object.keys(DIMENSION_NUM)) {
                for (const xyz of Object.keys(this.data[dimension])) {
                    const level = this.data[dimension][xyz].level;
                    this.mining[dimension][xyz] = this._calculateSpeed(level);
                }
            }
        }, 2);
    }

    /** Loads each dynamic property into a list, joins it then parses it into this.data */
    static load() {
        // If the gen parts do not exist prior, make them exist
        if (!world.getDynamicProperty("msc:MinerDataParts")) {
            world.setDynamicProperty("msc:MinerDataParts", 0);
        }

        // Amount of parts already stored
        const partsAmt = world.getDynamicProperty("msc:MinerDataParts");
        const parts = [];

        // For part, push to the string list
        for (let i = 0; i < partsAmt; i++) {
            const property = world.getDynamicProperty(`msc:MinerData${i}`);
            parts.push(property);
        }

        // After all parts are pushed, join then parse it to this.data
        const property = parts.join("");
        if (property === "") return;

        // Sets this.data
        this.data = JSON.parse(parts.join(""), null, "\t");
        devLog(`§6Loaded §bAuto Miner§6 data [§b${parts.length} parts§6]`);
    }

    /** Saves the data into multiple dynamic property parts to have infinite storage over theoretically infinite dynamic properties */
    static save() {
        const charactersPerPart = 10000;

        this.saveConfig();

        // New amount of parts
        const parts = splitByLength(
            JSON.stringify(this.data),
            charactersPerPart,
        );

        // Save part indexes as ordered in the parts lsit
        for (let i = 0; i < parts.length; i++) {
            world.setDynamicProperty(`msc:MinerData${i}`, parts[i]);
        }

        world.setDynamicProperty("msc:MinerDataParts", parts.length);

        system.runTimeout(() => {
            devLog(`§6Saved §bAuto Miner§6 data [§b${parts.length} parts§6]`);
        }, 1);
    }

    /** Saves Config Details */
    static saveConfig() {
        devLog(`Saved §bAuto Miner §aConfig!`);

        if (this.data["minecraft:the_nether"]) {
            this.data["minecraft:nether"] = this.data["minecraft:the_nether"];
            delete this.data["minecraft:the_nether"];
        }

        world.setDynamicProperty(
            "msc:MinerConfig",
            JSON.stringify(this.config),
        );

        for (const dimension of Object.keys(DIMENSION_NUM)) {
            for (const xyz of Object.keys(this.data[dimension])) {
                const level = this.data[dimension][xyz].level;
                this.mining[dimension][xyz] = this._calculateSpeed(level);
            }
        }
    }

    // ------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------

    /**
     * Returns true/false is the player is the owner of the specififed miner
     * @param {Dimension.id} dimensionId
     * @param {String} locationString
     * @param {Player} player
     * @returns {Boolean}
     */
    static isOwner(dimensionId, locationString, player) {
        const ownerUID = this.data[dimensionId][locationString].owner;
        if (ownerUID === player.uid) return true;
        return false;
    }

    // ------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------

    /**
     * Adds a miner to the database
     * @param {Dimension} dimension
     * @param {Vector3} location
     * @param {Player} player
     * @param {Number} level
     */
    static add(dimension, location, player, level = 1) {
        const xyz = vector3ToString(location);
        const dim = dimension.id;

        // Add Entry
        this.data[dim][xyz] = {
            owner: player.uid,
            level: level,
        };

        // Resets mining speed to its level
        this.resetMining(dim, xyz, level);

        // Playsound
        const soundOnPlace = AUTOMINER_SOUNDS.onPlace;
        dimension.playSound(
            soundOnPlace.string,
            centerLocation(location),
            soundOnPlace.optional,
        );

        // Save Data
        this.save();
    }

    /**
     * Removes a miner from the database
     * @param {Dimension} dimension
     * @param {Vector3} location
     * @param {Player} player
     */
    static remove(dimension, location, player) {
        const xyz = vector3ToString(location);
        const dim = dimension.id;
        const data = this.data[dim][xyz];
        const soundOnBreak = AUTOMINER_SOUNDS.onBreak;
        const soundOnFailBreak = AUTOMINER_SOUNDS.failBreak;

        // Prevents false errors
        if (!this.data[dim][xyz]) return;

        // If in creative mode & is an operator
        if (isOpInGMC(player)) {
            // Remove Data
            this.removeAllEntries(dim, xyz);

            // Log Deleted Auto Miner
            devLog(
                `${player.name}[${player.uid}] §cdeleted §bAuto Miner [Lv${data.level}] §e@${vector3ToString(location)}`,
            );

            // Playsound
            dimension.playSound(
                soundOnBreak.string,
                centerLocation(location),
                soundOnBreak.optional,
            );
            return;
        }

        // If not increative & op AND is owner
        if (this.isOwner(dim, xyz, player)) {
            // * Log picked up Auto Miner
            devLog(
                `${player.name}[${player.uid}] picked up §bAuto Miner [Lv${data.level}] §e@${vector3ToString(location)}`,
            );

            // * Playsound
            dimension.playSound(
                soundOnBreak.string,
                centerLocation(location),
                soundOnBreak.optional,
            );

            // * Item Stack
            // try {

            const inv = player.getComponent("inventory").container;
            const newLocation = centerLocation(location);
            const newItem = new ItemStack("msc:auto_miner");
            newItem.setLore([MINER_LEVEL_PREFIX + data.level]);

            // * Remove Data
            this.removeAllEntries(dim, xyz);

            // If space in player inventory, add item and return
            if (inv.emptySlotsCount > 0) {
                inv.addItem(newItem);
                dimension.setBlockType(location, "minecraft:air");
                devLog(`${player.name}[${player.uid}] was given §bAuto Miner`);
                return;
            }

            // If no space, spawn it on ground and return
            dimension.spawnItem(newItem, newLocation);
            dimension.setBlockType(location, "minecraft:air");
            devLog(
                `${player.name}[${player.uid}] didn't have enough inventory space for §bAuto Miner`,
            );
            return;
            // } catch (e) {
            // }
        }

        // If not owner or admin in creative
        player.sendMessage("§c* [MSC] This gen does not belong to you!");
        player.playSound(soundOnFailBreak.string, soundOnFailBreak.optional);
        devLog(`${player.name}[${player.uid}] failed picking up §bAuto Miner`);
        return;
    }

    /**
     * Removes entries associated with the same dimension and location then saves
     * @param {Dimension.id} dimensionId
     * @param {String} locationString
     */
    static removeAllEntries(dimensionId, locationString) {
        delete this.data[dimensionId][locationString];
        delete this.mining[dimensionId][locationString];
        this.save();
    }

    // ------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------

    /**
     * Calculates the amount of mining speed an autominer should have based on its level
     * @param {Number} level
     * @returns {Number}
     */
    static _calculateSpeed(level) {
        /**
         * [Formula]
         * baseSpeed / (maxLv-1) = perLvReduction
         * perLvReduction * (currentLv-1) = currentLvReduction
         * baseSpeed - currentLvReduction = current speed
         */

        const baseSpeed = this.config.baseSpeed;
        const maxLevels = this.config.maxLevel;

        // If max level is capped at 1, return base speed
        if (maxLevels === 1) return baseSpeed;
        if (level > maxLevels) level = maxLevels;

        // If not, calculate the rate of ticks removed per level
        const perLevel = baseSpeed / (maxLevels - 1);
        const currentTickReduction = perLevel * (level - 1);

        // Floor the result
        return Math.floor(baseSpeed - currentTickReduction);
    }

    /**
     * Calculates the rounded number for the next level up cost
     * @param {Number} level
     * @returns {Number}
     */
    static _calculateLvCost(level) {
        const exponential = this.config.costIncrement ** (level - 1);
        return Math.round(this.config.baseCost * exponential);
    }

    /**
     * What happens when the miner mines a block
     * @param {Dimension} dimension
     * @param {Vector3} location
     */
    static onMine(dimension, location) {
        const xyz = vector3ToString(location);
        const dim = dimension.id;
        const level = this.data[dimension.id][vector3ToString(location)].level;
        const { x, y, z } = location;

        // If cannot be automined, return
        const targetBlock = dimension.getBlock(location).below();
        if (!blockCanBeAutomined(targetBlock.typeId)) return;

        // If it can be automined, mine
        dimension.runCommand(`setblock ${x} ${y - 1} ${z} air destroy`);
        this.resetMining(dim, xyz, level);
    }

    /**
     * Resets the mining time for this entry
     * @param {Dimension.id} dimensionId
     * @param {Vector3} locationString
     * @param {Number} level
     */
    static resetMining(dimensionId, locationString, level) {
        const mineSpeed = this._calculateSpeed(level);
        this.mining[dimensionId][locationString] = mineSpeed;
    }
}

// Initialises AutoMiner data
system.run(() => {
    AutoMiner.init();
});

// Runs every tick (0.05s) to attempt to mine
system.runInterval(() => {
    for (const dimension of dimensions) {
        const dim = world.getDimension(dimension);

        // For checking if auto miner was deleted somehow
        for (const xyz of Object.keys(AutoMiner.data[dimension])) {
            const location = stringToVector3(xyz);
            if (!dim.getBlock(location)) continue;

            // If autominer & loaded; skip
            if (dim.getBlock(location).typeId === "msc:auto_miner") continue;

            // Else
            devLog(`§cRemoved §aunpresent §bAuto Miner §aentry from data`);
            AutoMiner.removeAllEntries(dimension, xyz);
        }

        // For mining blocks if they are loaded & if the owner is online
        for (const xyz of Object.keys(AutoMiner.mining[dimension])) {
            // If owner of the miner is not online; skip
            const ownerUID = AutoMiner.data[dimension][xyz].owner;
            if (!targetIsOnline(ownerUID)) continue;

            // Reduce ticks until mine
            if (AutoMiner.mining[dimension][xyz] > 0) {
                AutoMiner.mining[dimension][xyz] -= 1;
                continue;
            }

            // Mine if loaded
            if (!dim.getBlock(stringToVector3(xyz))) continue;

            AutoMiner.onMine(dim, stringToVector3(xyz));
        }
    }
});
