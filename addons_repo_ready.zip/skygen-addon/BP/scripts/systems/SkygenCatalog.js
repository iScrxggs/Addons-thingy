import { system, world } from "@minecraft/server";
import { BLOCKTYPE_NUM } from "../constants";
import { formatString } from "../utils/Formats";
import {
    SKYGEN_SELL_CATALOG_KEY,
    SKYGEN_SELL_CATALOG_VERSION,
    getRequiredRebirthForPrice,
    getSkygenConfig,
} from "./SkygenConfig";

const EXPLICIT_SELL_ENTRIES = [
    ["minecraft:oak_log", "Oak Log", "Generator Drops", 5],
    ["minecraft:cobblestone", "Cobblestone", "Generator Drops", 8],
    ["minecraft:raw_iron", "Raw Iron", "Ores", 15],
    ["minecraft:coal", "Coal", "Ores", 12],
    ["minecraft:raw_gold", "Raw Gold", "Ores", 35],
    ["minecraft:lapis_lazuli", "Lapis Lazuli", "Ores", 45],
    ["minecraft:diamond", "Diamond", "Rare Items", 120],
    ["minecraft:netherite_scrap", "Netherite Scrap", "Rare Items", 250],
    ["minecraft:quartz_block", "Quartz Block", "Generator Drops", 450],
    ["minecraft:copper_block", "Copper Block", "Generator Drops", 600],
    ["minecraft:end_stone", "Endstone", "Generator Drops", 750],
    ["minecraft:granite", "Granite", "Generator Drops", 1000],
    ["minecraft:diorite", "Diorite", "Generator Drops", 1125],
    ["minecraft:bamboo_block", "Bamboo Block", "Generator Drops", 1250],
    ["minecraft:slime", "Slime", "Mob Drops", 1400],
    ["minecraft:packed_ice", "Packed Ice", "Generator Drops", 1600],
    ["minecraft:magma", "Magma", "Generator Drops", 1800],
    ["minecraft:quartz", "Quartz", "Ores", 2000],
    ["minecraft:amethyst_block", "Amethyst Block", "Rare Items", 2250],
    ["minecraft:calcite", "Calcite", "Generator Drops", 2500],
    ["minecraft:podzol", "Podzol", "Generator Drops", 2800],
    ["minecraft:redstone", "Redstone", "Ores", 3200],
    ["minecraft:honey_block", "Honey Block", "Rare Items", 4400],
    ["minecraft:prismarine_bricks", "Prismarine Bricks", "Rare Items", 5200],
    ["minecraft:moss_block", "Moss Block", "Rare Items", 6000],
    ["minecraft:sponge", "Sponge", "Rare Items", 6600],
    ["minecraft:emerald_block", "Emerald Block", "Rare Items", 7200],
    ["minecraft:lodestone", "Lodestone", "Rare Items", 8000],
    ["minecraft:nether_brick", "Nether Brick", "Rare Items", 8400],
];

const SPECIAL_DROP_GENERATORS = {
    stone: "minecraft:cobblestone",
    iron_ore: "minecraft:raw_iron",
    deepslate_iron_ore: "minecraft:raw_iron",
    gold_ore: "minecraft:raw_gold",
    deepslate_gold_ore: "minecraft:raw_gold",
    coal_ore: "minecraft:coal",
    deepslate_coal_ore: "minecraft:coal",
    diamond_ore: "minecraft:diamond",
    deepslate_diamond_ore: "minecraft:diamond",
    emerald_ore: "minecraft:emerald",
    deepslate_emerald_ore: "minecraft:emerald",
    lapis_ore: "minecraft:lapis_lazuli",
    deepslate_lapis_ore: "minecraft:lapis_lazuli",
    redstone_ore: "minecraft:redstone",
    deepslate_redstone_ore: "minecraft:redstone",
    copper_ore: "minecraft:raw_copper",
    deepslate_copper_ore: "minecraft:raw_copper",
    quartz_ore: "minecraft:quartz",
    ancient_debris: "minecraft:netherite_scrap",
    grass_block: "minecraft:dirt",
    mycelium: "minecraft:dirt",
    dirt_with_roots: "minecraft:dirt",
    deepslate: "minecraft:cobbled_deepslate",
    nether_gold_ore: "minecraft:gold_nugget",
};

const EXTRA_PRICE_OVERRIDES = {
    "minecraft:raw_copper": 400,
    "minecraft:gold_nugget": 400,
    "minecraft:dirt": 400,
    "minecraft:cobbled_deepslate": 800,
    "minecraft:oak_leaves": 400,
    "minecraft:acacia_log": 400,
    "minecraft:birch_log": 400,
    "minecraft:cherry_log": 400,
    "minecraft:crimson_stem": 400,
    "minecraft:dark_oak_log": 400,
    "minecraft:jungle_log": 400,
    "minecraft:mangrove_log": 400,
    "minecraft:pale_oak_log": 400,
    "minecraft:spruce_log": 400,
    "minecraft:warped_stem": 400,
    "minecraft:sand": 800,
    "minecraft:red_sand": 800,
    "minecraft:gravel": 800,
    "minecraft:tuff": 800,
    "minecraft:basalt": 800,
    "minecraft:blackstone": 800,
    "minecraft:andesite": 1000,
    "minecraft:clay": 1000,
    "minecraft:packed_mud": 1400,
    "minecraft:mud": 1200,
    "minecraft:mud_bricks": 1800,
    "minecraft:coal_block": 2400,
    "minecraft:lapis_block": 3000,
    "minecraft:iron_block": 3200,
    "minecraft:redstone_block": 3400,
    "minecraft:gold_block": 3600,
    "minecraft:bone_block": 3600,
    "minecraft:web": 3600,
    "minecraft:sea_lantern": 6200,
    "minecraft:prismarine": 4800,
    "minecraft:dark_prismarine": 5600,
    "minecraft:diamond_block": 6800,
    "minecraft:emerald": 6400,
    "minecraft:beacon": 7800,
    "minecraft:netherite_block": 8000,
    "minecraft:mob_spawner": 8200,
};

function addOrMergeEntry(map, entry) {
    const existing = map.get(entry.itemId);
    if (!existing) {
        map.set(entry.itemId, {
            ...entry,
            requiredGenerators: [...entry.requiredGenerators],
        });
        return;
    }

    existing.alwaysAllowed = existing.alwaysAllowed || entry.alwaysAllowed;
    if (entry.alwaysAllowed) {
        existing.price = entry.price;
    }
    existing.requiredRebirth = Math.max(
        existing.requiredRebirth,
        entry.requiredRebirth,
    );
    existing.requiredGenerators = [
        ...new Set([...existing.requiredGenerators, ...entry.requiredGenerators]),
    ];
}

function typeToItemId(type) {
    return `minecraft:${type}`;
}

function priceFromKeyword(itemId, type) {
    if (EXTRA_PRICE_OVERRIDES[itemId] !== undefined) {
        return EXTRA_PRICE_OVERRIDES[itemId];
    }

    if (itemId.includes("shulker_box")) return 6800;
    if (itemId.includes("resin")) return 6000;
    if (itemId.includes("netherite") || itemId.includes("ancient_debris")) return 7600;
    if (itemId.includes("lodestone") || itemId.includes("beacon")) return 7600;
    if (itemId.includes("obsidian")) return itemId.includes("crying") ? 6200 : 5200;
    if (itemId.includes("prismarine")) return itemId.includes("dark") ? 5600 : 5200;
    if (itemId.includes("purpur")) return 5400;
    if (itemId.includes("honey")) return 4800;
    if (itemId.includes("ore") || itemId.includes("raw_")) return 2400;
    if (itemId.includes("quartz")) return 2000;
    if (itemId.includes("redstone")) return 3200;
    if (itemId.includes("diamond")) return 6800;
    if (itemId.includes("emerald")) return 6400;
    if (itemId.includes("concrete_powder")) return 1200;
    if (itemId.includes("concrete")) return 1600;
    if (itemId.includes("terracotta")) return 2000;
    if (itemId.includes("wool")) return 1400;
    if (itemId.includes("log") || itemId.includes("stem") || itemId.includes("leaves")) {
        return 400;
    }
    if (
        itemId.includes("stone") ||
        itemId.includes("dirt") ||
        itemId.includes("sand") ||
        itemId.includes("gravel") ||
        itemId.includes("deepslate") ||
        itemId.includes("tuff") ||
        itemId.includes("basalt") ||
        itemId.includes("blackstone") ||
        itemId.includes("andesite") ||
        itemId.includes("granite") ||
        itemId.includes("diorite") ||
        itemId.includes("mud")
    ) {
        return 800;
    }
    if (type.includes("_ore")) return 2400;
    return 2800;
}

function categorizeItem(itemId, type) {
    if (
        type.includes("_ore") ||
        itemId.includes("raw_") ||
        itemId === "minecraft:coal" ||
        itemId === "minecraft:diamond" ||
        itemId === "minecraft:emerald" ||
        itemId === "minecraft:lapis_lazuli" ||
        itemId === "minecraft:redstone" ||
        itemId === "minecraft:quartz"
    ) {
        return "Ores";
    }
    if (
        itemId.includes("slime") ||
        itemId.includes("honey") ||
        itemId.includes("web")
    ) {
        return "Mob Drops";
    }
    if (
        itemId.includes("netherite") ||
        itemId.includes("beacon") ||
        itemId.includes("lodestone") ||
        itemId.includes("prismarine") ||
        itemId.includes("obsidian") ||
        itemId.includes("sponge") ||
        itemId.includes("shulker")
    ) {
        return "Rare Items";
    }
    return "Generator Drops";
}

export function buildSkygenSellCatalog(config = getSkygenConfig()) {
    const entries = new Map();
    const ownershipExempt = new Set(config.ownershipExemptItemIds);

    for (const [itemId, name, category, price] of EXPLICIT_SELL_ENTRIES) {
        addOrMergeEntry(entries, {
            itemId,
            name,
            category,
            price,
            alwaysAllowed: ownershipExempt.has(itemId),
            requiredGenerators: [],
            requiredRebirth: getRequiredRebirthForPrice(price, config),
        });
    }

    for (const type of Object.keys(BLOCKTYPE_NUM)) {
        const itemId = SPECIAL_DROP_GENERATORS[type] ?? typeToItemId(type);
        const price = priceFromKeyword(itemId, type);

        addOrMergeEntry(entries, {
            itemId,
            name: formatString(itemId.split(":")[1]),
            category: categorizeItem(itemId, type),
            price,
            alwaysAllowed: ownershipExempt.has(itemId),
            requiredGenerators: [type],
            requiredRebirth: getRequiredRebirthForPrice(price, config),
        });

        const selfItemId = typeToItemId(type);
        if (selfItemId !== itemId) {
            const selfPrice = priceFromKeyword(selfItemId, type);
            addOrMergeEntry(entries, {
                itemId: selfItemId,
                name: formatString(type),
                category: categorizeItem(selfItemId, type),
                price: selfPrice,
                alwaysAllowed: ownershipExempt.has(selfItemId),
                requiredGenerators: [type],
                requiredRebirth: getRequiredRebirthForPrice(selfPrice, config),
            });
        }
    }

    return {
        version: SKYGEN_SELL_CATALOG_VERSION,
        entries: [...entries.values()].sort(
            (a, b) => a.price - b.price || a.name.localeCompare(b.name),
        ),
    };
}

export function loadSkygenSellCatalog() {
    const raw = world.getDynamicProperty(SKYGEN_SELL_CATALOG_KEY);
    if (!raw || typeof raw !== "string") {
        return buildSkygenSellCatalog();
    }

    try {
        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed?.entries)) {
            return buildSkygenSellCatalog();
        }
        return parsed;
    } catch {
        return buildSkygenSellCatalog();
    }
}

export function syncWorldSellCatalog(config = getSkygenConfig()) {
    const catalog = buildSkygenSellCatalog(config);
    world.setDynamicProperty(SKYGEN_SELL_CATALOG_KEY, JSON.stringify(catalog));
    return catalog;
}

system.run(() => {
    syncWorldSellCatalog();
});
