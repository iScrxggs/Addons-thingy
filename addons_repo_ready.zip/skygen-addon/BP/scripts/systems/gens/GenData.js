// ! Keeping for if I need it to find values at some point somewhere
// /**
//  * Grabs the dimension typeId from the index
//  * @param {Number} index
//  * @returns {Dimension.id}
//  */
// static _indexToDimension(index) {
//     return Object.keys(DIMENSION_NUM).find(
//         (key) => DIMENSION_NUM[key] === index,
//     );
// }

import { Dimension, ItemStack, Player, system, world } from "@minecraft/server";
import { BLOCKTYPE_NUM, DIMENSION_NUM } from "../../constants";
import { stringToVector3, vector3ToString } from "../../utils/Locations";
import { centerLocation, typeToTypeId } from "../../utils/Blocks";
import { formatString, splitByLength } from "../../utils/Formats";
import { devLog } from "../DeveloperMode";
import { GENERATOR_SOUNDS } from "../../sounds";
import { isOpInGMC } from "../../utils/Player";
import { SkygenOwnership } from "../SkygenOwnership";

const dimensionIds = Object.keys(DIMENSION_NUM);

// Storer of all instances in separate data structures
export class Generator {
    /**
     * ? How quickly blocks will respawn in ticks by type num when broken
     *  respawnTimes = {
     *      "acacia_log": 40
     *  }
     */
    static respawnTimes = {};

    /**
     * Location for placeholder blocks & their type
     */
    static placeholderBlocks = {
        "minecraft:overworld": {},
        "minecraft:nether": {},
        "minecraft:the_end": {},
    };

    /**
     * ? We sort this by dimension first to prevent the xyz from other dimensions matching and causing problems
     *  data = {
     *      "minecraft:overworld": {
     *          "xyz": { owner: player.uid, type: "acacia_log" }
     *      },
     *      "minecraft:nether": {},
     *      "minecraft:the_end": {}
     *  }
     */
    static data = {
        "minecraft:overworld": {},
        "minecraft:nether": {},
        "minecraft:the_end": {},
    };

    /**
     * ? This is where we keep currently respawning generators until their respawn ticks have passed
     *  respawning = {
     *      "minecraft:overworld": {
     *          "xyz": 5
     *      },
     *      "minecraft:nether": {},
     *      "minecraft:the_end": {}
     *  }
     */
    static respawning = {
        "minecraft:overworld": {},
        "minecraft:nether": {},
        "minecraft:the_end": {},
    };

    /**
     * ? When the generators need to respawn but are not loaded, they are stored here and constantly checked for if the chunk is loaded
     *  respawnOnLoad = {
     *      "minecraft:overworld": {
     *          "xyz" = true
     *      },
     *      "minecraft:nether": {},
     *      "minecraft:the_end": {}
     *  }
     */
    static respawnOnLoad = {
        "minecraft:overworld": {},
        "minecraft:nether": {},
        "minecraft:the_end": {},
    };

    /** Default Respawn Time */
    static defaultRespawnTime = 0;

    // ------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------

    /** Initialising the dynamic properties */
    static init() {
        // If the gen does not have a default respawn time, set it to 0 ticks; if it does, apply it
        if (!world.getDynamicProperty("msc:DefaultGenRespawn")) {
            world.setDynamicProperty("msc:DefaultGenRespawn", 0);
        }
        this.defaultRespawnTime = world.getDynamicProperty(
            "msc:DefaultGenRespawn",
        );

        // Loads each individual part of the stored string data and parses it into this.data
        this.loadParts();

        // Loads respawn times as well as forces all gens to be on a respawn timer
        this.loadRespawnTimes();
        this.forceRespawns();
    }

    /** Loads each dynamic property into a list, joins it then parses it into this.data */
    static loadParts() {
        // If the gen parts do not exist prior, make them exist
        if (!world.getDynamicProperty("msc:GenDataParts")) {
            world.setDynamicProperty("msc:GenDataParts", 0);
        }

        // Amount of parts already stored
        const partsAmt = world.getDynamicProperty("msc:GenDataParts");
        const parts = [];

        // For part, push to the string list
        for (let i = 0; i < partsAmt; i++) {
            const property = world.getDynamicProperty(`msc:GenData${i}`);
            parts.push(property);
        }

        // After all parts are pushed, join then parse it to this.data
        const property = parts.join("");
        if (property === "") return;

        // Sets this.data
        this.data = JSON.parse(parts.join(""), null, "\t");

        // Add dimensions if not previously there
        for (const entry of dimensionIds) {
            if (!this.data[entry]) this.data[entry] = {};
        }

        // Dev Log
        devLog(`§6Loaded §bGenerator§6 data [§b${parts.length} parts§6]`);
    }

    /** Saves the data into multiple dynamic property parts to have infinite storage over theoretically infinite dynamic properties */
    static save() {
        const charactersPerPart = 10000;

        // New amount of parts
        const parts = splitByLength(
            JSON.stringify(this.data),
            charactersPerPart,
        );

        // Save part indexes as ordered in the parts lsit
        for (let i = 0; i < parts.length; i++) {
            world.setDynamicProperty(`msc:GenData${i}`, parts[i]);
        }

        // Dev Log
        system.runTimeout(() => {
            devLog(`§6Saved §bGenerator§6 data [§b${parts.length} parts§6]`);
        }, 1);

        // Save
        world.setDynamicProperty("msc:GenDataParts", parts.length);
    }

    // ------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------

    /**
     * Grabs the type from the index
     * @param {Number} index
     * @returns {String} `Object.keys(BLOCKTYPE_NUM)[KEY]`
     */
    static _indexToType(index) {
        return Object.keys(BLOCKTYPE_NUM).find(
            (key) => BLOCKTYPE_NUM[key] === index,
        );
    }

    /**
     * Returns true/false is the player is the owner of the specififed
     * @param {Dimension.id} dimensionId
     * @param {String} locationString
     * @param {Player} player
     * @returns {Boolean}
     */
    static isOwner(dimensionId, locationString, player) {
        const ownerUID = this.data[dimensionId][locationString].owner;
        if (ownerUID === player.uid) return true;
        return false;
    }

    // ------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------

    /** Loads all saved respawn times into 'this.respawnTimes' */
    static loadRespawnTimes() {
        // If the gen parts do not exist prior, make them exist
        if (!world.getDynamicProperty("msc:GenRespawnTimeParts")) {
            world.setDynamicProperty("msc:GenRespawnTimeParts", 0);
        }

        // Amount of parts already stored
        const partsAmt = world.getDynamicProperty("msc:GenRespawnTimeParts");
        const parts = [];

        // For part, push to the string list
        for (let i = 0; i < partsAmt; i++) {
            const property = world.getDynamicProperty(`msc:GenRespawnTime${i}`);
            parts.push(property);
        }

        // After all parts are pushed, join then parse it to this.data
        const property = parts.join("");
        if (property === "") return;

        // Sets this.respawnTimes
        this.respawnTimes = JSON.parse(parts.join(""), null, "\t");

        // Dev Log
        devLog(
            `§6Loaded §bGenerator§6 respawn times [§b${parts.length} parts§6]`,
        );
    }

    /** Saves all respawn times into a dynamic property */
    static saveRespawnTimes() {
        const charactersPerPart = 10000;

        // New amount of parts
        const parts = splitByLength(
            JSON.stringify(this.respawnTimes),
            charactersPerPart,
        );

        // Save part indexes as ordered in the parts lsit
        for (let i = 0; i < parts.length; i++) {
            world.setDynamicProperty(`msc:GenRespawnTime${i}`, parts[i]);
        }

        // Dev Log
        system.runTimeout(() => {
            devLog(
                `§6Saved §bGenerator§6 respawn times [§b${parts.length} parts§6]`,
            );
        }, 1);

        // Save
        world.setDynamicProperty("msc:GenRespawnTimeParts", parts.length);
    }

    /** Forces all gens of all dimensions to be placed on their respawn timer */
    static forceRespawns() {
        for (const dimension of dimensionIds) {
            for (const xyz of Object.keys(this.data[dimension])) {
                const type = this.data[dimension][xyz].type;
                const location = stringToVector3(xyz);
                const dim = world.getDimension(dimension);

                // If no block loaded for this; skip
                if (!dim.getBlock(location)) {
                    this.respawning[dimension][xyz] = 10;
                    continue;
                }
                dim.setBlockType(location, "msc:blockgen_placeholder");

                // If respawn is less than 10 ticks, set to 10 for this time
                if (this.respawnTimes[type] < 10) {
                    this.respawning[dimension][xyz] = 10;
                    continue;
                }

                // Otherwise set to normal
                this.respawning[dimension][xyz] = this.respawnTimes[type];
            }
        }
    }

    // ------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------

    /**
     * Creates a generator
     * @param {Player} player
     * @param {Vector3} location
     * @param {Type} type
     * @param {Dimension} dimension
     */
    static add(player, location, type, dimension) {
        const xyz = vector3ToString(location);
        const dim = dimension.id;

        // Playsound
        const soundOnPlace = GENERATOR_SOUNDS.onPlace;
        dimension.playSound(
            soundOnPlace.string,
            centerLocation(location),
            soundOnPlace.optional,
        );

        // Add Data Entry
        this.data[dim][xyz] = {
            owner: player.uid,
            type: type,
        };

        // Initialise respawn times for this
        if (!this.respawnTimes[type]) {
            this.respawnTimes[type] = this.defaultRespawnTime;
            this.saveRespawnTimes();
        }

        // If respawn times are below 10 ticks, set it to 10 ticks initially just so there is no placement lag
        if (this.respawnTimes[type] < 10) {
            this.respawning[dim][xyz] = 10;
        } else {
            this.respawning[dim][xyz] = this.respawnTimes[type];
        }

        // Dev Log
        devLog(
            `${player.name}[${player.uid}] placed §b${formatString(type)} Generator §e@${xyz}`,
        );

        // Saves Data
        this.save();
        SkygenOwnership.syncOwnedGeneratorCounts(player.uid);
    }

    /**
     * Deletes the data & respawning entry of a gen within a specified dimension and location
     * @param {Vector3} location
     * @param {Dimension} dimension
     */
    static remove(location, dimension, player, type) {
        const xyz = vector3ToString(location);
        const dim = dimension.id;

        const soundOnPickup = GENERATOR_SOUNDS.onPickup;
        const soundOnFailPickup = GENERATOR_SOUNDS.onFailPickup;

        // If op & in creative
        if (isOpInGMC(player)) {
            // Remove Data
            this.removeAllEntries(dim, xyz);

            // Playsound
            dimension.playSound(
                soundOnPickup.string,
                centerLocation(location),
                soundOnPickup.optional,
            );

            // Log deleted
            devLog(
                `${player.name}[${player.uid}] §cdeleted §b${formatString(type)} Generator §e@${xyz}`,
            );

            // Cooldown
            // system.run(() => {
            // player.startItemCooldown("gen_stuff", 10);
            // });

            // Setblock
            dimension.setBlockType(location, "minecraft:air");
            SkygenOwnership.syncOwnedGeneratorCounts(player.uid);
            return;
        }

        // If owner and not an operator in creative
        if (this.isOwner(dim, xyz, player)) {
            // Remove Data
            this.removeAllEntries(dim, xyz);

            // Log picked up
            devLog(
                `${player.name}[${player.uid}] picked up §b${formatString(type)} Generator §e@${xyz}`,
            );

            // Playsound
            dimension.playSound(
                soundOnPickup.string,
                centerLocation(location),
                soundOnPickup.optional,
            );

            // Cooldown
            // system.run(() => {
            // player.startItemCooldown("gen_stuff", 10);
            // });

            // Setblock
            dimension.setBlockType(location, "minecraft:air");

            // * Item Stack
            const inv = player.getComponent("inventory").container;
            const newLocation = centerLocation(location);
            const newItem = new ItemStack(`msc:${type}_gen`);

            // If space in player inventory, add item and return
            if (inv.emptySlotsCount > 0) {
                inv.addItem(newItem);
                SkygenOwnership.syncOwnedGeneratorCounts(player.uid);
                return;
            }

            // If no space, spawn it on ground and return
            dimension.spawnItem(newItem, newLocation);
            SkygenOwnership.syncOwnedGeneratorCounts(player.uid);
            return;
        }

        // If not owner or admin in creative
        player.sendMessage("§c* [MSC] This generator does not belong to you!");
        player.playSound(soundOnFailPickup.string, soundOnFailPickup.optional);
        return;
    }

    /**
     * Removes all data, respawning data then saves
     * @param {Dimension.id} dimensionId
     * @param {String} locationString
     */
    static removeAllEntries(dimensionId, locationString) {
        delete this.data[dimensionId][locationString];
        delete this.respawning[dimensionId][locationString];
        this.save();
    }

    // ------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------

    /**
     * When the gen is broken, put it on a respawn timer
     * @param {Dimension} dimension
     * @param {Vector3} location
     */
    static onBreak(dimension, location) {
        const xyz = vector3ToString(location);
        const dim = dimension.id;

        // Data
        const blockData = this.data[dim][xyz];
        const type = blockData.type;

        // If respawn type is instant, instantly place back
        if (this.respawnTimes[type] === 0) {
            dimension.setBlockType(location, typeToTypeId(type));
            return;
        }

        // Placeholder between respawns
        dimension.setBlockType(location, "msc:blockgen_placeholder");
        this.respawning[dim][xyz] = this.respawnTimes[type];
    }

    /**
     * Respawns the specified block when its respawn timer is complete
     * @param {Dimension.id} dimensionId
     * @param {String} locationString
     */
    static respawnBlock(dimensionId, locationString) {
        try {
            // Data
            const blockData = this.data[dimensionId][locationString];
            const location = stringToVector3(locationString);
            const typeId = typeToTypeId(blockData.type);

            // Set block back
            const dim = world.getDimension(dimensionId);
            dim.setBlockType(location, typeId);
        } catch (e) {}
    }
}

// Initialises GenData
system.run(() => {
    Generator.init();
});

// Constant checks every tick
system.runInterval(() => {
    for (const dimension of dimensionIds) {
        // Ticking to check if block is broken
        dataChecks(dimension);

        // Ticking to attempt block respawning
        canRespawnChecks(dimension);

        // Ticking to respawn on loading chunk
        respawnOnLoadChecks(dimension);
    }
});
function dataChecks(dimension) {
    for (const xyz of Object.keys(Generator.data[dimension])) {
        // Skip respawning and onloading blocks
        if (Generator.respawning[dimension]?.[xyz]) continue;
        if (Generator.respawnOnLoad[dimension]?.[xyz]) continue;

        // Check if the block is loaded OR if its loaded and not air/liquid, if not; skip
        const dim = world.getDimension(dimension);
        const location = stringToVector3(xyz);
        if (!dim.getBlock(location)) continue;

        // If loaded, skip if not air or liquid
        const block = dim.getBlock(location);
        if (!block.isAir && !block.isLiquid) continue;

        // Treat the block as if it was broken by a player
        Generator.onBreak(dim, location);
    }
}
function canRespawnChecks(dimension) {
    for (const xyz of Object.keys(Generator.respawning[dimension])) {
        // If 1 or more ticks left until respawn, remove until 0
        if (Generator.respawning[dimension][xyz] > 1) {
            Generator.respawning[dimension][xyz] -= 1;
            continue;
        }

        // When 0, attempt to find block to load- if the block cannot be found it is unloaded
        const dim = world.getDimension(dimension);
        if (!dim.getBlock(stringToVector3(xyz))) {
            devLog(`Added §e@${xyz} §ato respawn on load in §b${dimension}`);
            Generator.respawnOnLoad[dimension][xyz] = true;
            delete Generator.respawning[dimension][xyz];
            continue;
        }

        // Respawn Block
        Generator.respawnBlock(dimension, xyz);
        delete Generator.respawning[dimension][xyz];
    }
}
function respawnOnLoadChecks(dimension) {
    for (const xyz of Object.keys(Generator.respawnOnLoad[dimension])) {
        const location = stringToVector3(xyz);
        const dim = world.getDimension(dimension);

        // Skip if unloaded still
        if (!dim.getBlock(location)) continue;

        // Respawn if loaded
        Generator.respawnBlock(dimension, xyz);
        delete Generator.respawnOnLoad[dimension][xyz];
    }
}
