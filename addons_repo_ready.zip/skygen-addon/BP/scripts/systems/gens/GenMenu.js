import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { Generator } from "./GenData";
import { vector3ToString } from "../../utils/Locations";
import { formatString } from "../../utils/Formats";
import { devLog } from "../DeveloperMode";
import { PlayerData } from "../PlayerData";
import { GENERATOR_SOUNDS } from "../../sounds";
import { DIMENSION_NUM } from "../../constants";
import { isOpInGMC } from "../../utils/Player";
import { SkygenProfileMenu } from "../commandMenus/skygenProfile";

const dimensions = Object.keys(DIMENSION_NUM);

export class GenMenu {
    constructor(player, location, type, dimension, adminMenu = false) {
        this.player = player;
        this.location = location;
        this.type = type;
        this.dimension = dimension;
        this.dimensionId = dimension.id;
        this.locationString = vector3ToString(location);

        if (adminMenu) {
            this.adminMain();
            return;
        }

        this.main();
    }

    main() {
        const genData = Generator.data[this.dimensionId][this.locationString];
        const respawnTimes = Generator.respawnTimes[this.type];
        const owner = genData.owner;

        const playerIsOwner = Generator.isOwner(
            this.dimensionId,
            this.locationString,
            this.player,
        );

        let respawnTime = "Instant";
        if (respawnTimes > 0) {
            respawnTime = `${Math.floor((respawnTimes / 20) * 100) / 100}s`;
        }

        let eggTexture = `textures/BlockGenEggs/${this.type}`;
        if (!playerIsOwner && !isOpInGMC(this.player)) {
            eggTexture = "textures/ui/lock_color";
        }

        const form = new ActionFormData()
            .title("Generator Menu")
            .body(
                `\n§eSneak + interact§a with an §eempty hand§a to pick up generators instantly!\n\n` +
                    `§aPlaced by §b${PlayerData.data[owner]?.name ? owner}` +
                    `\n§aType: §b${formatString(this.type)}` +
                    `\n§aRespawn: §e${respawnTime}\n `,
            )
            .button("Pickup", eggTexture)
            .button("My SkyGen Profile", "textures/ui/icon_setting")
            .button("Close Menu");

        form.show(this.player).then((formData) => {
            if (formData.canceled || formData.selection === 2) return;

            if (formData.selection === 0) {
                Generator.remove(
                    this.location,
                    this.dimension,
                    this.player,
                    this.type,
                );
                return;
            }

            if (formData.selection === 1) {
                new SkygenProfileMenu(this.player);
            }
        });
    }

    adminMain() {
        const genData =
            Generator.data[this.dimension.id][vector3ToString(this.location)];
        const owner = genData.owner;

        let respawnTime = "Instant";
        if (Generator.respawnTimes[this.type] > 0) {
            respawnTime = `${Math.floor((Generator.respawnTimes[this.type] / 20) * 100) / 100}s`;
        }

        const form = new ActionFormData()
            .title("Generator Menu")
            .body(
                `\n§aPlaced by §b${PlayerData.data[owner]?.name ? owner}` +
                    `\n§aType: §b${formatString(this.type)}` +
                    `\n§aRespawn: §e${respawnTime}\n `,
            )
            .button("Close Menu")
            .button("Universal Edit", "textures/ui/icon_setting")
            .button("Delete", "textures/blocks/barrier");

        form.show(this.player).then((formData) => {
            if (formData.canceled) return;
            if (formData.selection === 0) return;

            if (formData.selection === 1) {
                this.editTime();
                return;
            }

            Generator.remove(
                this.location,
                this.dimension,
                this.player,
                this.type,
            );
        });
    }

    editTime() {
        const typeRespawnTime = Generator.respawnTimes[this.type];
        const form = new ModalFormData()
            .title("Edit Respawn Times")
            .textField(
                "\nEnter a number with t/s/m/h at the end.\nExample: 4s = 4 seconds.\n",
                "<number>[t/s/m/h]",
                {
                    defaultValue: `${typeRespawnTime}t`,
                },
            )
            .submitButton("Save Changes");

        form.show(this.player).then((formData) => {
            if (formData.canceled) return;

            const [timeInput] = formData.formValues;
            const newTimeInput = String(timeInput).replaceAll(" ", "").toLowerCase();
            const soundOnFail = GENERATOR_SOUNDS.onInvalidInput;
            const soundOnComplete = GENERATOR_SOUNDS.onValidInput;
            const validTime = this.timeIsValid(newTimeInput);

            if (validTime === false) {
                devLog(
                    `§cFailed to register "§e${newTimeInput}§c" as a valid time for §b${this.type}§a gens.`,
                );
                this.player.sendMessage("§c* [MSC] Invalid Input!");
                this.player.playSound(soundOnFail.string, soundOnFail.optional);
                return;
            }

            this.player.sendMessage(
                `§a* [MSC] Updated respawn times for ${formatString(this.type)} Generators.`,
            );
            this.player.playSound(
                soundOnComplete.string,
                soundOnComplete.optional,
            );

            devLog(
                `Set §b${formatString(this.type)} Generator §arespawn time to §e${validTime} ticks`,
            );

            for (const dimension of dimensions) {
                for (const xyz of Object.keys(Generator.respawning[dimension])) {
                    if (Generator.data[dimension][xyz].type !== this.type) {
                        continue;
                    }
                    Generator.respawning[dimension][xyz] = validTime;
                }
            }
            Generator.respawnTimes[this.type] = validTime;
            Generator.saveRespawnTimes();
        });
    }

    timeIsValid(timeInput) {
        if (timeInput.includes("-")) return false;
        if (timeInput.includes(".")) return false;

        if (
            !timeInput.endsWith("t") &&
            !timeInput.endsWith("s") &&
            !timeInput.endsWith("m") &&
            !timeInput.endsWith("h")
        ) {
            return false;
        }

        if (timeInput.endsWith("t")) {
            return +timeInput.substring(0, timeInput.length - 1);
        }
        if (timeInput.endsWith("s")) {
            return +timeInput.substring(0, timeInput.length - 1) * 20;
        }
        if (timeInput.endsWith("m")) {
            return +timeInput.substring(0, timeInput.length - 1) * 1200;
        }
        if (timeInput.endsWith("h")) {
            return +timeInput.substring(0, timeInput.length - 1) * 72000;
        }
    }
}
