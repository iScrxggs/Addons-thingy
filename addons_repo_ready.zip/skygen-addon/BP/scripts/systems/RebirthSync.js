import { system, world } from "@minecraft/server";
import { devLog } from "./DeveloperMode";
import { AutoMiner } from "./autoMiner/AutoMiner";
import { ExperienceTank } from "./experienceTank/ExperienceTank";
import { Generator } from "./gens/GenData";
import { ItemStorer } from "./itemStorer/ItemStorer";
import { SkygenOwnership } from "./SkygenOwnership";

const REBIRTH_SYNC_TAG = "msc_rebirth_sync_pending";
const DIMENSIONS = ["minecraft:overworld", "minecraft:nether", "minecraft:the_end"];

function resetOwnedEntries(dataMap, ownerUid) {
    let removed = 0;

    for (const dimensionId of DIMENSIONS) {
        const dimData = dataMap[dimensionId];
        if (!dimData) continue;

        for (const locationString of Object.keys(dimData)) {
            if (dimData[locationString]?.owner !== ownerUid) continue;
            delete dimData[locationString];
            removed++;
        }
    }

    return removed;
}

function applyGeneratorRebirthReset(player) {
    const ownerUid = player.uid;
    const removedGeneratorLocations = {
        "minecraft:overworld": [],
        "minecraft:nether": [],
        "minecraft:the_end": [],
    };

    let gensRemoved = 0;
    for (const dimensionId of DIMENSIONS) {
        const dimData = Generator.data[dimensionId];
        if (!dimData) continue;
        for (const locationString of Object.keys(dimData)) {
            if (dimData[locationString]?.owner !== ownerUid) continue;
            delete dimData[locationString];
            removedGeneratorLocations[dimensionId].push(locationString);
            gensRemoved++;
        }
    }

    let gensRespawningRemoved = 0;
    let gensRespawnOnLoadRemoved = 0;
    let placeholdersRemoved = 0;
    for (const dimensionId of DIMENSIONS) {
        for (const locationString of removedGeneratorLocations[dimensionId]) {
            if (locationString in Generator.respawning[dimensionId]) {
                delete Generator.respawning[dimensionId][locationString];
                gensRespawningRemoved++;
            }
            if (locationString in Generator.respawnOnLoad[dimensionId]) {
                delete Generator.respawnOnLoad[dimensionId][locationString];
                gensRespawnOnLoadRemoved++;
            }
            if (locationString in Generator.placeholderBlocks[dimensionId]) {
                delete Generator.placeholderBlocks[dimensionId][locationString];
                placeholdersRemoved++;
            }
        }
    }
    if (
        gensRemoved > 0 ||
        gensRespawningRemoved > 0 ||
        gensRespawnOnLoadRemoved > 0 ||
        placeholdersRemoved > 0
    ) {
        Generator.save();
    }

    const minersRemoved = resetOwnedEntries(AutoMiner.data, ownerUid);
    const minerTimersRemoved = resetOwnedEntries(AutoMiner.mining, ownerUid);
    if (minersRemoved > 0 || minerTimersRemoved > 0) {
        AutoMiner.save();
    }

    const storersRemoved = resetOwnedEntries(ItemStorer.data, ownerUid);
    if (storersRemoved > 0) {
        ItemStorer.save();
    }

    const tanksRemoved = resetOwnedEntries(ExperienceTank.data, ownerUid);
    if (tanksRemoved > 0) {
        ExperienceTank.save();
    }

    SkygenOwnership.clearOwnedGeneratorCounts(ownerUid);

    devLog(
        `${player.name}[${player.uid}] synced rebirth reset across MSC machines (gens:${gensRemoved}, miners:${minersRemoved}, storers:${storersRemoved}, tanks:${tanksRemoved})`,
    );
}

system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        if (!player.hasTag(REBIRTH_SYNC_TAG)) continue;
        player.removeTag(REBIRTH_SYNC_TAG);
        applyGeneratorRebirthReset(player);
    }
}, 20);
