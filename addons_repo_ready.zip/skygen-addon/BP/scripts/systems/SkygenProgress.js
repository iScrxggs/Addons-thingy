import { world } from "@minecraft/server";
import { PlayerData } from "./PlayerData";
import {
    displayUnitNumber,
    formatNumber,
    formatString,
} from "../utils/Formats";
import {
    getJackpotChancePercent,
    getJackpotUpgradeCost,
    getMaxJackpotUpgradeLevel,
    getOverclockCost,
    getOverclockMultiplier,
    getSkygenConfig,
    rollJackpotReward,
} from "./SkygenConfig";

const SKYGEN_PROGRESS_PREFIX = "msc:SkygenProgress:";

function createDefaultProgress() {
    return {
        blocksMined: 0,
        tokens: 0,
        jackpots: 0,
        bonusTokens: 0,
        tokensSold: 0,
        moneyEarnedFromTokens: 0,
        activeCashoutMoney: 0,
        ctokensPurchased: 0,
        moneySpentOnCTokens: 0,
        overclockLevel: 0,
        jackpotChanceLevel: 0,
        perType: {},
    };
}

function normalizePerType(perType) {
    const result = {};
    if (!perType || typeof perType !== "object") return result;

    for (const [type, count] of Object.entries(perType)) {
        const nextCount = Math.max(0, Math.floor(Number(count) || 0));
        if (nextCount <= 0) continue;
        result[String(type)] = nextCount;
    }

    return result;
}

function normalizeProgress(data) {
    const defaults = createDefaultProgress();
    return {
        blocksMined: Math.max(
            0,
            Math.floor(Number(data?.blocksMined) || defaults.blocksMined),
        ),
        tokens: Math.max(0, Math.floor(Number(data?.tokens) || defaults.tokens)),
        jackpots: Math.max(0, Math.floor(Number(data?.jackpots) || defaults.jackpots)),
        bonusTokens: Math.max(
            0,
            Math.floor(Number(data?.bonusTokens) || defaults.bonusTokens),
        ),
        tokensSold: Math.max(
            0,
            Math.floor(Number(data?.tokensSold) || defaults.tokensSold),
        ),
        moneyEarnedFromTokens: Math.max(
            0,
            Math.floor(
                Number(data?.moneyEarnedFromTokens) ||
                    defaults.moneyEarnedFromTokens,
            ),
        ),
        activeCashoutMoney: Math.max(
            0,
            Math.floor(Number(data?.activeCashoutMoney) || defaults.activeCashoutMoney),
        ),
        ctokensPurchased: Math.max(
            0,
            Math.floor(Number(data?.ctokensPurchased) || defaults.ctokensPurchased),
        ),
        moneySpentOnCTokens: Math.max(
            0,
            Math.floor(
                Number(data?.moneySpentOnCTokens) || defaults.moneySpentOnCTokens,
            ),
        ),
        overclockLevel: Math.max(
            0,
            Math.floor(Number(data?.overclockLevel) || defaults.overclockLevel),
        ),
        jackpotChanceLevel: Math.max(
            0,
            Math.floor(
                Number(data?.jackpotChanceLevel) || defaults.jackpotChanceLevel,
            ),
        ),
        perType: normalizePerType(data?.perType),
    };
}

function progressKey(uid) {
    return `${SKYGEN_PROGRESS_PREFIX}${uid}`;
}

export class SkygenProgress {
    static get(uid) {
        const raw = world.getDynamicProperty(progressKey(uid));
        if (!raw) return createDefaultProgress();

        try {
            return normalizeProgress(JSON.parse(raw));
        } catch {
            return createDefaultProgress();
        }
    }

    static save(uid, data) {
        world.setDynamicProperty(
            progressKey(uid),
            JSON.stringify(normalizeProgress(data)),
        );
    }

    static recordGeneratorBreak(player, type) {
        const config = getSkygenConfig();
        const data = this.get(player.uid);
        const overclockMultiplier = getOverclockMultiplier(
            data.overclockLevel,
            config,
        );
        const baseReward = Math.max(
            1,
            Math.floor(config.baseTokensPerBreak * overclockMultiplier),
        );
        const jackpotChancePercent = getJackpotChancePercent(
            data.jackpotChanceLevel,
            config,
        );

        let jackpotReward = 0;
        data.blocksMined += 1;
        data.tokens += baseReward;
        data.perType[type] = (data.perType[type] ?? 0) + 1;

        if (Math.random() < jackpotChancePercent / 100) {
            jackpotReward = rollJackpotReward(config);
            data.tokens += jackpotReward;
            data.jackpots += 1;
            data.bonusTokens += jackpotReward;
        }

        this.save(player.uid, data);

        return {
            data,
            baseReward,
            jackpotReward,
            totalReward: baseReward + jackpotReward,
            jackpotChancePercent,
            overclockMultiplier,
        };
    }

    static purchaseOverclock(player) {
        const config = getSkygenConfig();
        const data = this.get(player.uid);
        const maxLevel = Math.max(0, config.overclockMultipliers.length - 1);
        if (data.overclockLevel >= maxLevel) {
            return {
                success: false,
                message: "Your overclock is already maxed.",
            };
        }

        const cost = getOverclockCost(data.overclockLevel, config);
        if (data.tokens < cost) {
            return {
                success: false,
                message: `You need ${formatNumber(cost - data.tokens)} more tokens for the next overclock.`,
            };
        }

        data.tokens -= cost;
        data.overclockLevel += 1;
        this.save(player.uid, data);
        return {
            success: true,
            cost,
            overclockLevel: data.overclockLevel,
            multiplier: getOverclockMultiplier(data.overclockLevel, config),
            data,
        };
    }

    static purchaseJackpotUpgrade(player) {
        const config = getSkygenConfig();
        const data = this.get(player.uid);
        const maxLevel = getMaxJackpotUpgradeLevel(config);
        if (data.jackpotChanceLevel >= maxLevel) {
            return {
                success: false,
                message: "Your jackpot chance upgrade is already maxed.",
            };
        }

        const cost = getJackpotUpgradeCost(data.jackpotChanceLevel, config);
        if (data.tokens < cost) {
            return {
                success: false,
                message: `You need ${formatNumber(cost - data.tokens)} more tokens for the next jackpot upgrade.`,
            };
        }

        data.tokens -= cost;
        data.jackpotChanceLevel += 1;
        this.save(player.uid, data);
        return {
            success: true,
            cost,
            jackpotChanceLevel: data.jackpotChanceLevel,
            jackpotChancePercent: getJackpotChancePercent(
                data.jackpotChanceLevel,
                config,
            ),
            data,
        };
    }

    static topBy(field, limit = 10) {
        const entries = [];
        const normalizedField = field === "blocks" ? "blocksMined" : field;

        for (const [uid, playerInfo] of Object.entries(PlayerData.data)) {
            const progress = this.get(uid);
            const value = Math.max(
                0,
                Math.floor(Number(progress?.[normalizedField] || 0)),
            );
            if (value <= 0) continue;

            entries.push({
                uid,
                name: playerInfo?.name ?? `Player ${uid}`,
                value,
            });
        }

        return entries
            .sort((a, b) => b.value - a.value || a.name.localeCompare(b.name))
            .slice(0, limit);
    }

    static favoriteType(data) {
        const entries = Object.entries(data.perType ?? {});
        if (entries.length === 0) return "None yet";

        const [type, count] = entries.sort((a, b) => b[1] - a[1])[0];
        return `${formatString(type)} (${formatNumber(count)})`;
    }

    static formatStatBody(player) {
        const config = getSkygenConfig();
        const data = this.get(player.uid);
        return [
            `\u00A76Tokens: \u00A7e${formatNumber(data.tokens)}`,
            `\u00A7bGenerator Blocks Mined: \u00A7f${formatNumber(data.blocksMined)}`,
            `\u00A7dJackpots Hit: \u00A7f${formatNumber(data.jackpots)}`,
            `\u00A7aBonus Tokens Won: \u00A7f${formatNumber(data.bonusTokens)}`,
            `\u00A76Tokens Cashed Out: \u00A7e${formatNumber(data.tokensSold)}`,
            `\u00A72Money From Tokens: \u00A7a$${formatNumber(data.moneyEarnedFromTokens)}`,
            `\u00A77Favorite Generator: \u00A7f${this.favoriteType(data)}`,
            `\u00A7bOverclock: \u00A7f${getOverclockMultiplier(data.overclockLevel, config).toFixed(2)}x`,
            `\u00A76Jackpot Chance: \u00A7e${getJackpotChancePercent(data.jackpotChanceLevel, config).toFixed(2)}%`,
            "",
            `\u00A78Quick read: \u00A7e${displayUnitNumber(data.tokens)}\u00A78 tokens, \u00A7b${displayUnitNumber(data.blocksMined)}\u00A78 mined`,
        ].join("\n");
    }
}
