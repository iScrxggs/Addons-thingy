import { system, world } from "@minecraft/server";
import { formatNumber } from "../utils/Formats";
import { SkygenProgress } from "./SkygenProgress";
import { getSkygenConfig } from "./SkygenConfig";

const MONEY_OBJECTIVE_ID = "Money";
const LEGACY_MONEY_OBJECTIVE_ID = "money";
const CTOKEN_OBJECTIVE_ID = "CTokens";

function ensureMoneyObjective() {
    const scoreboard = world.scoreboard;
    const existingObjective = scoreboard.getObjective(MONEY_OBJECTIVE_ID);
    if (existingObjective) return existingObjective;

    const objective = scoreboard.addObjective(MONEY_OBJECTIVE_ID, "Money");
    const legacyObjective = scoreboard.getObjective(LEGACY_MONEY_OBJECTIVE_ID);
    if (legacyObjective) {
        for (const player of world.getAllPlayers()) {
            const identity = player.scoreboardIdentity;
            if (!identity) continue;
            try {
                const legacyScore = legacyObjective.getScore(identity);
                if (typeof legacyScore === "number") {
                    objective.setScore(identity, legacyScore);
                }
            } catch {}
        }
    }

    return objective;
}

function ensureObjective(objectiveId, displayName) {
    if (objectiveId === MONEY_OBJECTIVE_ID) return ensureMoneyObjective();

    const scoreboard = world.scoreboard;
    const existingObjective = scoreboard.getObjective(objectiveId);
    if (existingObjective) return existingObjective;

    return scoreboard.addObjective(objectiveId, displayName);
}

function getObjectiveBalance(player, objectiveId, displayName) {
    if (!player?.scoreboardIdentity) return 0;

    const objective = ensureObjective(objectiveId, displayName);
    try {
        const score = objective.getScore(player.scoreboardIdentity);
        return typeof score === "number" ? score : 0;
    } catch {
        objective.setScore(player.scoreboardIdentity, 0);
        return 0;
    }
}

function setObjectiveBalance(player, objectiveId, amount, displayName) {
    if (!player?.scoreboardIdentity) return;

    ensureObjective(objectiveId, displayName).setScore(
        player.scoreboardIdentity,
        Math.max(0, Math.floor(amount)),
    );
}

function addObjectiveBalance(player, objectiveId, amount, displayName) {
    const current = getObjectiveBalance(player, objectiveId, displayName);
    setObjectiveBalance(player, objectiveId, current + amount, displayName);
}

function deductObjectiveBalance(player, objectiveId, amount, displayName) {
    const current = getObjectiveBalance(player, objectiveId, displayName);
    if (current < amount) return false;

    setObjectiveBalance(player, objectiveId, current - amount, displayName);
    return true;
}

export class SkygenExchange {
    static ensureEconomyObjectives() {
        ensureMoneyObjective();
        ensureObjective(CTOKEN_OBJECTIVE_ID, "CTokens");
    }

    static getConfig() {
        const config = getSkygenConfig();
        return {
            tokenToMoneyRate: config.tokenToMoneyRate,
            moneyPerCToken: config.moneyPerCToken,
            maxActiveTokenCashout: config.maxActiveTokenCashout,
        };
    }

    static getMoney(player) {
        return getObjectiveBalance(player, MONEY_OBJECTIVE_ID, "Money");
    }

    static getCTokens(player) {
        return getObjectiveBalance(player, CTOKEN_OBJECTIVE_ID, "CTokens");
    }

    static getExchangeState(player) {
        const data = SkygenProgress.get(player.uid);
        const money = this.getMoney(player);
        const ctokens = this.getCTokens(player);
        const config = this.getConfig();
        const activeCashoutMoney = Math.max(0, data.activeCashoutMoney);
        const remainingCashout = Math.max(
            0,
            config.maxActiveTokenCashout - activeCashoutMoney,
        );
        const maxTokensSellableByCap = Math.floor(
            remainingCashout / config.tokenToMoneyRate,
        );

        return {
            data,
            money,
            ctokens,
            activeCashoutMoney,
            remainingCashout,
            maxTokensSellableByCap,
            tokenToMoneyRate: config.tokenToMoneyRate,
            moneyPerCToken: config.moneyPerCToken,
            maxActiveTokenCashout: config.maxActiveTokenCashout,
        };
    }

    static sellTokensForMoney(player, tokenAmount) {
        const requestedTokens = Math.max(0, Math.floor(Number(tokenAmount) || 0));
        if (requestedTokens <= 0) {
            return {
                success: false,
                message: "Enter a token amount above 0.",
            };
        }

        const data = SkygenProgress.get(player.uid);
        if (data.tokens <= 0) {
            return {
                success: false,
                message: "You do not have any tokens to exchange.",
            };
        }

        const state = this.getExchangeState(player);
        if (state.maxTokensSellableByCap <= 0) {
            return {
                success: false,
                message:
                    "Your token cashout cap is full. Spend some money on CTokens to unlock more cashout room.",
            };
        }

        const sellAmount = Math.min(
            requestedTokens,
            data.tokens,
            state.maxTokensSellableByCap,
        );
        if (sellAmount <= 0) {
            return {
                success: false,
                message: "You cannot exchange that amount right now.",
            };
        }

        const payout = sellAmount * state.tokenToMoneyRate;

        data.tokens -= sellAmount;
        data.tokensSold += sellAmount;
        data.moneyEarnedFromTokens += payout;
        data.activeCashoutMoney += payout;
        SkygenProgress.save(player.uid, data);

        addObjectiveBalance(player, MONEY_OBJECTIVE_ID, payout, "Money");

        return {
            success: true,
            soldTokens: sellAmount,
            payout,
            capped: sellAmount < requestedTokens,
            state: this.getExchangeState(player),
        };
    }

    static buyCTokens(player, ctokenAmount) {
        const requestedAmount = Math.max(0, Math.floor(Number(ctokenAmount) || 0));
        if (requestedAmount <= 0) {
            return {
                success: false,
                message: "Enter a CToken amount above 0.",
            };
        }

        const state = this.getExchangeState(player);
        const totalCost = requestedAmount * state.moneyPerCToken;

        if (state.money < totalCost) {
            return {
                success: false,
                message: `You need $${formatNumber(totalCost - state.money)} more to buy that many CTokens.`,
            };
        }

        if (!deductObjectiveBalance(player, MONEY_OBJECTIVE_ID, totalCost, "Money")) {
            return {
                success: false,
                message: "Your money could not be deducted.",
            };
        }

        addObjectiveBalance(player, CTOKEN_OBJECTIVE_ID, requestedAmount, "CTokens");

        const data = SkygenProgress.get(player.uid);
        const unlockedCashout = Math.min(data.activeCashoutMoney, totalCost);
        data.activeCashoutMoney = Math.max(
            0,
            data.activeCashoutMoney - unlockedCashout,
        );
        data.ctokensPurchased += requestedAmount;
        data.moneySpentOnCTokens += totalCost;
        SkygenProgress.save(player.uid, data);

        return {
            success: true,
            ctokenAmount: requestedAmount,
            totalCost,
            unlockedCashout,
            state: this.getExchangeState(player),
        };
    }

    static formatEconomyBody(player) {
        const state = this.getExchangeState(player);
        return [
            `\u00A72Money: \u00A7a$${formatNumber(state.money)}`,
            `\u00A7bCTokens: \u00A7f${formatNumber(state.ctokens)}`,
            `\u00A76Sell Rate: \u00A7e1 token = $${formatNumber(state.tokenToMoneyRate)}`,
            `\u00A7dCToken Cost: \u00A7f$${formatNumber(state.moneyPerCToken)} each`,
            `\u00A7cCashout Lock Used: \u00A7f$${formatNumber(state.activeCashoutMoney)} / $${formatNumber(state.maxActiveTokenCashout)}`,
            `\u00A7aCashout Room Left: \u00A7f$${formatNumber(state.remainingCashout)}`,
            "",
            "\u00A78Buying CTokens with money frees this cashout lock back up.",
        ].join("\n");
    }
}

system.run(() => {
    SkygenExchange.ensureEconomyObjectives();
});
