import { ItemStack, world } from "@minecraft/server";
import { formatNumber } from "../utils/Formats";
import { vector3ToString } from "../utils/Locations";
import { ItemStorer } from "./itemStorer/ItemStorer";
import {
    evaluateSkygenSellAccess,
    summarizeBlockedSellItems,
} from "./SkygenSellRules";

const SELL_WAND_ITEM_ID = "minecraft:blaze_rod";
const SELL_WAND_NAME = "\u00A76Sell Wand";
const PLOTSHOP_ECONOMY_SETTINGS_KEY = "plotshop_economy_settings_v25";
const PLOTSHOP_ECONOMY_DATA_PREFIX = "plotshop_economy_data_v18:";
const MONEY_OBJECTIVE_ID = "Money";
const LEGACY_MONEY_OBJECTIVE_ID = "money";
const SKYGEN_MULTIPLIER_OBJECTIVE_ID = "skygen_mul";
const SUPPORTED_SELL_WAND_CONTAINER_IDS = new Set([
    "minecraft:chest",
    "minecraft:trapped_chest",
]);

function ensureObjective(objectiveId, displayName) {
    const existing = world.scoreboard.getObjective(objectiveId);
    if (existing) return existing;
    return world.scoreboard.addObjective(objectiveId, displayName ?? objectiveId);
}

function ensureMoneyObjective() {
    const existing = world.scoreboard.getObjective(MONEY_OBJECTIVE_ID);
    if (existing) return existing;

    const objective = world.scoreboard.addObjective(MONEY_OBJECTIVE_ID, "Money");
    const legacy = world.scoreboard.getObjective(LEGACY_MONEY_OBJECTIVE_ID);
    if (!legacy) return objective;

    for (const player of world.getAllPlayers()) {
        const identity = player.scoreboardIdentity;
        if (!identity) continue;
        try {
            const legacyScore = legacy.getScore(identity);
            if (typeof legacyScore === "number") {
                objective.setScore(identity, legacyScore);
            }
        } catch {}
    }

    return objective;
}

function getScore(player, objectiveId, displayName) {
    if (!player?.scoreboardIdentity) return 0;
    const objective =
        objectiveId === MONEY_OBJECTIVE_ID
            ? ensureMoneyObjective()
            : ensureObjective(objectiveId, displayName);

    try {
        const score = objective.getScore(player.scoreboardIdentity);
        return typeof score === "number" ? score : 0;
    } catch {
        objective.setScore(player.scoreboardIdentity, 0);
        return 0;
    }
}

function addMoney(player, amount) {
    if (!player?.scoreboardIdentity) return;
    const objective = ensureMoneyObjective();
    const current = getScore(player, MONEY_OBJECTIVE_ID, "Money");
    objective.setScore(player.scoreboardIdentity, Math.max(0, current + amount));
}

function loadPlotshopEconomySettings() {
    const defaults = {
        sellableItems: [],
        sellGlobalMultiplier: 1,
        sellTaxPercent: 0,
        economyBoostEnabled: false,
        economyBoostMultiplier: 1.25,
        rebirthBonusPerLevel: 0.2,
    };

    const raw = world.getDynamicProperty(PLOTSHOP_ECONOMY_SETTINGS_KEY);
    if (!raw || typeof raw !== "string") return defaults;

    try {
        const parsed = JSON.parse(raw);
        const sellableItems = Array.isArray(parsed.sellableItems)
            ? parsed.sellableItems
                  .map((entry) => ({
                      itemId: String(entry?.itemId ?? "").trim(),
                      price: Math.max(0, Math.floor(Number(entry?.price) || 0)),
                  }))
                  .filter((entry) => entry.itemId.includes(":") && entry.price > 0)
            : [];

        return {
            sellableItems,
            sellGlobalMultiplier: Math.max(
                0,
                Number(parsed.sellGlobalMultiplier) || 1,
            ),
            sellTaxPercent: Math.min(
                100,
                Math.max(0, Number(parsed.sellTaxPercent) || 0),
            ),
            economyBoostEnabled: Boolean(parsed.economyBoostEnabled),
            economyBoostMultiplier: Math.max(
                0,
                Number(parsed.economyBoostMultiplier) || 1.25,
            ),
            rebirthBonusPerLevel: Math.max(
                0,
                Number(parsed.rebirthBonusPerLevel) || 0.2,
            ),
        };
    } catch {
        return defaults;
    }
}

function loadPlotshopEconomyData(player) {
    const raw = world.getDynamicProperty(
        `${PLOTSHOP_ECONOMY_DATA_PREFIX}${player.id}`,
    );
    if (!raw || typeof raw !== "string") {
        return { multiplierLevel: 0, rebirths: 0 };
    }

    try {
        const parsed = JSON.parse(raw);
        return {
            multiplierLevel: Math.max(
                0,
                Math.floor(Number(parsed?.multiplierLevel) || 0),
            ),
            rebirths: Math.max(0, Math.floor(Number(parsed?.rebirths) || 0)),
        };
    } catch {
        return { multiplierLevel: 0, rebirths: 0 };
    }
}

function getMultiplierFromPlotshop(player, data) {
    const fromScoreboard = getScore(
        player,
        SKYGEN_MULTIPLIER_OBJECTIVE_ID,
        SKYGEN_MULTIPLIER_OBJECTIVE_ID,
    );
    const level = Math.max(fromScoreboard, data.multiplierLevel);
    return Number((1 + level * 0.1).toFixed(2));
}

function getPayoutContext(player) {
    const settings = loadPlotshopEconomySettings();
    const priceMap = new Map(
        settings.sellableItems.map((entry) => [entry.itemId, entry.price]),
    );
    const playerEconomyData = loadPlotshopEconomyData(player);
    const multiplier = getMultiplierFromPlotshop(player, playerEconomyData);
    const rebirthBonus = Number(
        (1 + playerEconomyData.rebirths * settings.rebirthBonusPerLevel).toFixed(2),
    );
    const boostMultiplier = settings.economyBoostEnabled
        ? settings.economyBoostMultiplier
        : 1;
    const taxMultiplier = 1 - settings.sellTaxPercent / 100;

    return {
        priceMap,
        settings,
        multiplier,
        rebirthBonus,
        boostMultiplier,
        taxMultiplier,
    };
}

function calculateFinalEarned(baseValue, context) {
    return Math.max(
        0,
        Math.floor(
            baseValue *
                context.settings.sellGlobalMultiplier *
                context.multiplier *
                context.rebirthBonus *
                context.boostMultiplier *
                context.taxMultiplier,
        ),
    );
}

function recordBlockedItem(blockedCounts, itemId, amount, access) {
    const current = blockedCounts.get(itemId) ?? {
        amount: 0,
        reason: access.reason,
        requiredRebirth: access.requiredRebirth ?? 0,
    };
    current.amount += amount;
    current.reason = access.reason;
    current.requiredRebirth = access.requiredRebirth ?? current.requiredRebirth;
    blockedCounts.set(itemId, current);
}

function formatBlockedSuffix(blockedCounts) {
    const summaries = summarizeBlockedSellItems(blockedCounts);
    if (summaries.length === 0) return [];
    return summaries.slice(0, 4).map((line) => `\u00A7cSkipped: \u00A77${line}`);
}

export class SellWand {
    static isSellWand(itemStack) {
        if (!itemStack) return false;
        if (itemStack.typeId !== SELL_WAND_ITEM_ID) return false;
        return itemStack.nameTag === SELL_WAND_NAME;
    }

    static supportsBlock(block) {
        if (!block) return false;
        return SUPPORTED_SELL_WAND_CONTAINER_IDS.has(block.typeId);
    }

    static createSellWandItem() {
        const item = new ItemStack(SELL_WAND_ITEM_ID, 1);
        item.nameTag = SELL_WAND_NAME;
        item.setLore([
            "\u00A77Use on your Item Storer, chest, or double chest to sell items.",
            "\u00A77Uses Plotshop economy prices, multiplier, and rebirth bonus.",
        ]);
        return item;
    }

    static giveSellWand(player) {
        const container = player.getComponent("inventory")?.container;
        if (!container) return false;

        const wand = this.createSellWandItem();
        if (container.emptySlotsCount > 0) {
            container.addItem(wand);
            return true;
        }

        player.dimension.spawnItem(wand, player.location);
        return true;
    }

    static sellFromItemStorer(dimension, location, player) {
        const dimId = dimension.id;
        const xyz = vector3ToString(location);
        const storageData = ItemStorer.data?.[dimId]?.[xyz];

        if (!storageData) {
            return { success: false, message: "No Item Storer data found here." };
        }
        if (storageData.owner !== player.uid) {
            return { success: false, message: "You do not own this Item Storer." };
        }
        if (!storageData.item || storageData.amount <= 0) {
            return { success: false, message: "This Item Storer is empty." };
        }

        const context = getPayoutContext(player);
        const itemPrice = context.priceMap.get(storageData.item);
        if (!itemPrice || itemPrice <= 0) {
            return {
                success: false,
                message: `No sell price configured for ${storageData.item}.`,
            };
        }

        const access = evaluateSkygenSellAccess(player, storageData.item);
        if (!access.allowed) {
            return {
                success: false,
                message:
                    access.reason === "rebirth"
                        ? `You need rebirth ${access.requiredRebirth} before selling ${storageData.item}.`
                        : `You must own a matching generator before selling ${storageData.item}.`,
            };
        }

        const soldAmount = storageData.amount;
        const baseValue = itemPrice * soldAmount;
        const finalEarned = calculateFinalEarned(baseValue, context);

        if (finalEarned <= 0) {
            return {
                success: false,
                message: "Calculated sell value is zero. Check economy settings.",
            };
        }

        addMoney(player, finalEarned);
        storageData.amount = 0;
        ItemStorer.save();

        return {
            success: true,
            soldItemId: storageData.item,
            soldAmount,
            earned: finalEarned,
            pricePerItem: itemPrice,
            multiplier: context.multiplier,
            rebirthBonus: context.rebirthBonus,
            blockedCounts: new Map(),
        };
    }

    static sellFromContainerBlock(block, player) {
        if (!this.supportsBlock(block)) {
            return {
                success: false,
                message:
                    "This Sell Wand build only supports normal and double chests.",
            };
        }

        const container = block.getComponent("inventory")?.container;
        if (!container) {
            return {
                success: false,
                message: "This chest could not be read right now.",
            };
        }

        const context = getPayoutContext(player);
        let baseValue = 0;
        let soldAmount = 0;
        let soldTypes = 0;
        const blockedCounts = new Map();

        for (let slot = 0; slot < container.size; slot++) {
            const item = container.getItem(slot);
            if (!item) continue;

            const itemPrice = context.priceMap.get(item.typeId);
            if (!itemPrice || itemPrice <= 0) continue;

            const access = evaluateSkygenSellAccess(player, item.typeId);
            if (!access.allowed) {
                recordBlockedItem(blockedCounts, item.typeId, item.amount, access);
                continue;
            }

            baseValue += itemPrice * item.amount;
            soldAmount += item.amount;
            soldTypes++;
            container.setItem(slot);
        }

        if (soldAmount <= 0 || baseValue <= 0) {
            const blockedMessages = formatBlockedSuffix(blockedCounts);
            return {
                success: false,
                message:
                    blockedMessages.length > 0
                        ? blockedMessages[0].replace(/^\u00A7cSkipped: \u00A77/, "")
                        : "No sellable items were found in this chest.",
            };
        }

        const finalEarned = calculateFinalEarned(baseValue, context);
        if (finalEarned <= 0) {
            return {
                success: false,
                message: "Calculated sell value is zero. Check economy settings.",
            };
        }

        addMoney(player, finalEarned);

        return {
            success: true,
            soldAmount,
            soldTypes,
            earned: finalEarned,
            multiplier: context.multiplier,
            rebirthBonus: context.rebirthBonus,
            blockedCounts,
        };
    }

    static formatSellMessage(result) {
        return `\u00A7a* [MSC] Sold \u00A7e${formatNumber(result.soldAmount)}\u00A7a x \u00A7b${result.soldItemId}\u00A7a for \u00A72$${formatNumber(result.earned)}\u00A7a.`;
    }

    static formatContainerSellMessage(result) {
        return `\u00A7a* [MSC] Sold \u00A7e${formatNumber(result.soldAmount)}\u00A7a items across \u00A7b${formatNumber(result.soldTypes)}\u00A7a sellable type(s) for \u00A72$${formatNumber(result.earned)}\u00A7a.`;
    }

    static formatBlockedMessages(result) {
        return formatBlockedSuffix(result.blockedCounts ?? new Map());
    }
}
