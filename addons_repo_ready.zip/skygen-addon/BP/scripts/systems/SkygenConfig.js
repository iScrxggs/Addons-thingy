import { world } from "@minecraft/server";

export const SKYGEN_CONFIG_KEY = "msc:SkygenConfig:v1";
export const SKYGEN_SELL_CATALOG_KEY = "msc:SkygenSellCatalog:v1";
export const SKYGEN_OWNED_GEN_PREFIX = "msc:OwnedGenTypes:";
export const SKYGEN_SELL_CATALOG_VERSION = 1;
export const PLOTSHOP_ECONOMY_DATA_PREFIX = "plotshop_economy_data_v18:";

const DEFAULT_SKYGEN_CONFIG = {
    tokenToMoneyRate: 10000,
    moneyPerCToken: 2500000,
    maxActiveTokenCashout: 2147483647,
    baseTokensPerBreak: 1,
    jackpotBaseChancePercent: 0.1,
    jackpotUpgradeIncrementPercent: 0.1,
    jackpotChanceMaxPercent: 2.5,
    jackpotUpgradeBaseCost: 500,
    jackpotUpgradeMaxCost: 25000,
    jackpotRewardTiers: [
        { min: 50, max: 150, weight: 78 },
        { min: 151, max: 300, weight: 18 },
        { min: 301, max: 500, weight: 4 },
    ],
    overclockMultipliers: [1, 2, 3],
    overclockCosts: [5000, 20000],
    rebirthSellGates: [
        { minPrice: 6000, requiredRebirth: 1 },
        { minPrice: 7200, requiredRebirth: 2 },
        { minPrice: 8400, requiredRebirth: 3 },
    ],
    ownershipExemptItemIds: [
        "minecraft:oak_log",
        "minecraft:cobblestone",
        "minecraft:raw_iron",
        "minecraft:coal",
        "minecraft:raw_gold",
        "minecraft:lapis_lazuli",
        "minecraft:diamond",
        "minecraft:netherite_scrap",
        "minecraft:quartz_block",
        "minecraft:copper_block",
        "minecraft:end_stone",
        "minecraft:granite",
        "minecraft:diorite",
        "minecraft:bamboo_block",
        "minecraft:slime",
        "minecraft:packed_ice",
        "minecraft:magma",
        "minecraft:quartz",
        "minecraft:amethyst_block",
        "minecraft:calcite",
        "minecraft:podzol",
        "minecraft:redstone",
        "minecraft:honey_block",
        "minecraft:prismarine_bricks",
        "minecraft:moss_block",
        "minecraft:sponge",
        "minecraft:emerald_block",
        "minecraft:lodestone",
        "minecraft:nether_brick",
    ],
};

function normalizeRewardTier(tier, fallback) {
    const min = Math.max(1, Math.floor(Number(tier?.min) || fallback.min));
    const max = Math.max(min, Math.floor(Number(tier?.max) || fallback.max));
    const weight = Math.max(1, Math.floor(Number(tier?.weight) || fallback.weight));
    return { min, max, weight };
}

function normalizeRebirthGate(gate, fallback) {
    return {
        minPrice: Math.max(
            0,
            Math.floor(Number(gate?.minPrice) || fallback.minPrice),
        ),
        requiredRebirth: Math.max(
            0,
            Math.floor(Number(gate?.requiredRebirth) || fallback.requiredRebirth),
        ),
    };
}

export function getDefaultSkygenConfig() {
    return {
        ...DEFAULT_SKYGEN_CONFIG,
        jackpotRewardTiers: DEFAULT_SKYGEN_CONFIG.jackpotRewardTiers.map((tier) => ({
            ...tier,
        })),
        overclockMultipliers: [...DEFAULT_SKYGEN_CONFIG.overclockMultipliers],
        overclockCosts: [...DEFAULT_SKYGEN_CONFIG.overclockCosts],
        rebirthSellGates: DEFAULT_SKYGEN_CONFIG.rebirthSellGates.map((gate) => ({
            ...gate,
        })),
        ownershipExemptItemIds: [...DEFAULT_SKYGEN_CONFIG.ownershipExemptItemIds],
    };
}

export function normalizeSkygenConfig(rawConfig) {
    const defaults = getDefaultSkygenConfig();
    const rewardTiers = Array.isArray(rawConfig?.jackpotRewardTiers)
        ? rawConfig.jackpotRewardTiers
              .slice(0, defaults.jackpotRewardTiers.length)
              .map((tier, index) =>
                  normalizeRewardTier(
                      tier,
                      defaults.jackpotRewardTiers[
                          Math.min(index, defaults.jackpotRewardTiers.length - 1)
                      ],
                  ),
              )
        : defaults.jackpotRewardTiers;
    const overclockMultipliers = Array.isArray(rawConfig?.overclockMultipliers)
        ? rawConfig.overclockMultipliers
              .map((value) => Math.max(1, Number(value) || 1))
              .filter((value) => Number.isFinite(value))
        : defaults.overclockMultipliers;
    const overclockCosts = Array.isArray(rawConfig?.overclockCosts)
        ? rawConfig.overclockCosts
              .map((value) => Math.max(0, Math.floor(Number(value) || 0)))
              .filter((value) => Number.isFinite(value))
        : defaults.overclockCosts;
    const rebirthSellGates = Array.isArray(rawConfig?.rebirthSellGates)
        ? rawConfig.rebirthSellGates
              .map((gate, index) =>
                  normalizeRebirthGate(
                      gate,
                      defaults.rebirthSellGates[
                          Math.min(index, defaults.rebirthSellGates.length - 1)
                      ],
                  ),
              )
              .sort((a, b) => a.minPrice - b.minPrice)
        : defaults.rebirthSellGates;
    const ownershipExemptItemIds = Array.isArray(rawConfig?.ownershipExemptItemIds)
        ? rawConfig.ownershipExemptItemIds
              .map((itemId) => String(itemId ?? "").trim())
              .filter((itemId) => itemId.includes(":"))
        : defaults.ownershipExemptItemIds;

    return {
        tokenToMoneyRate: Math.max(
            1,
            Math.floor(Number(rawConfig?.tokenToMoneyRate) || defaults.tokenToMoneyRate),
        ),
        moneyPerCToken: Math.max(
            1,
            Math.floor(Number(rawConfig?.moneyPerCToken) || defaults.moneyPerCToken),
        ),
        maxActiveTokenCashout: Math.max(
            1,
            Math.floor(
                Number(rawConfig?.maxActiveTokenCashout) ||
                    defaults.maxActiveTokenCashout,
            ),
        ),
        baseTokensPerBreak: Math.max(
            1,
            Math.floor(Number(rawConfig?.baseTokensPerBreak) || defaults.baseTokensPerBreak),
        ),
        jackpotBaseChancePercent: Math.max(
            0,
            Number(rawConfig?.jackpotBaseChancePercent) ||
                defaults.jackpotBaseChancePercent,
        ),
        jackpotUpgradeIncrementPercent: Math.max(
            0.01,
            Number(rawConfig?.jackpotUpgradeIncrementPercent) ||
                defaults.jackpotUpgradeIncrementPercent,
        ),
        jackpotChanceMaxPercent: Math.max(
            0.1,
            Number(rawConfig?.jackpotChanceMaxPercent) ||
                defaults.jackpotChanceMaxPercent,
        ),
        jackpotUpgradeBaseCost: Math.max(
            0,
            Math.floor(
                Number(rawConfig?.jackpotUpgradeBaseCost) ||
                    defaults.jackpotUpgradeBaseCost,
            ),
        ),
        jackpotUpgradeMaxCost: Math.max(
            0,
            Math.floor(
                Number(rawConfig?.jackpotUpgradeMaxCost) ||
                    defaults.jackpotUpgradeMaxCost,
            ),
        ),
        jackpotRewardTiers: rewardTiers,
        overclockMultipliers:
            overclockMultipliers.length > 0
                ? overclockMultipliers
                : defaults.overclockMultipliers,
        overclockCosts:
            overclockCosts.length > 0 ? overclockCosts : defaults.overclockCosts,
        rebirthSellGates:
            rebirthSellGates.length > 0 ? rebirthSellGates : defaults.rebirthSellGates,
        ownershipExemptItemIds:
            ownershipExemptItemIds.length > 0
                ? ownershipExemptItemIds
                : defaults.ownershipExemptItemIds,
    };
}

export function getSkygenConfig() {
    const raw = world.getDynamicProperty(SKYGEN_CONFIG_KEY);
    if (!raw || typeof raw !== "string") return getDefaultSkygenConfig();
    try {
        return normalizeSkygenConfig(JSON.parse(raw));
    } catch {
        return getDefaultSkygenConfig();
    }
}

export function saveSkygenConfig(config) {
    world.setDynamicProperty(
        SKYGEN_CONFIG_KEY,
        JSON.stringify(normalizeSkygenConfig(config)),
    );
}

export function getMaxJackpotUpgradeLevel(config = getSkygenConfig()) {
    const base = Math.max(0, config.jackpotBaseChancePercent);
    const max = Math.max(base, config.jackpotChanceMaxPercent);
    const increment = Math.max(0.01, config.jackpotUpgradeIncrementPercent);
    return Math.max(0, Math.floor((max - base) / increment));
}

export function getJackpotChancePercent(upgradeLevel, config = getSkygenConfig()) {
    const level = Math.max(0, Math.floor(Number(upgradeLevel) || 0));
    return Number(
        Math.min(
            config.jackpotChanceMaxPercent,
            config.jackpotBaseChancePercent +
                level * config.jackpotUpgradeIncrementPercent,
        ).toFixed(2),
    );
}

export function getJackpotUpgradeCost(level, config = getSkygenConfig()) {
    const maxLevel = getMaxJackpotUpgradeLevel(config);
    if (level >= maxLevel) return 0;
    if (maxLevel <= 0) return Math.max(0, config.jackpotUpgradeBaseCost);

    const progress = maxLevel <= 1 ? 1 : level / (maxLevel - 1);
    return Math.max(
        config.jackpotUpgradeBaseCost,
        Math.floor(
            config.jackpotUpgradeBaseCost +
                (config.jackpotUpgradeMaxCost - config.jackpotUpgradeBaseCost) *
                    Math.pow(progress, 1.35),
        ),
    );
}

export function getOverclockMultiplier(level, config = getSkygenConfig()) {
    const values = config.overclockMultipliers;
    const index = Math.max(0, Math.min(values.length - 1, Math.floor(level || 0)));
    return Math.max(1, Number(values[index] || 1));
}

export function getOverclockCost(level, config = getSkygenConfig()) {
    const costs = config.overclockCosts;
    const index = Math.max(0, Math.floor(level || 0));
    return index >= costs.length ? 0 : Math.max(0, Math.floor(costs[index] || 0));
}

export function rollJackpotReward(config = getSkygenConfig()) {
    const tiers = config.jackpotRewardTiers;
    const totalWeight = tiers.reduce((sum, tier) => sum + tier.weight, 0);
    let cursor = Math.random() * totalWeight;

    for (const tier of tiers) {
        cursor -= tier.weight;
        if (cursor <= 0) {
            return tier.min + Math.floor(Math.random() * (tier.max - tier.min + 1));
        }
    }

    const fallback = tiers[tiers.length - 1];
    return fallback.min;
}

export function getRequiredRebirthForPrice(price, config = getSkygenConfig()) {
    let required = 0;
    for (const gate of config.rebirthSellGates) {
        if (price >= gate.minPrice) {
            required = Math.max(required, gate.requiredRebirth);
        }
    }
    return required;
}
