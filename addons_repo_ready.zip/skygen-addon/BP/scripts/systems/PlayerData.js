import { ActionFormData } from "@minecraft/server-ui";
import { Player, world, system } from "@minecraft/server";
import { ADDON_UPDATE_DESC, ADDON_VERSION } from "../constants";

export class PlayerData {
    /**
     * Good for grabbing offline player names via the player.uid
     *
     *  this.data = {
     *      [player.uid]: {
     *          name: 'username'
     *      },
     *      ...
     *  }
     */
    static data = {};

    /**
     * Good for grabbing offline players uid from names
     *
     *  this.names = {
     *      [player.name]: player.uid,
     *      ...
     *  }
     */
    static names = {};

    /** Sets this.data & this.names to the world saved data */
    static initialize() {
        this.data = JSON.parse(
            world.getDynamicProperty("msc:PlayerUIDs") || "{}",
        );
        this.names = JSON.parse(
            world.getDynamicProperty("msc:PlayerNames") || "{}",
        );
    }

    /** Details Menu */
    static onJoinMenu(player) {
        const form = new ActionFormData()
            .title("Myth's Skygen Creator")
            .body(ADDON_UPDATE_DESC.join("\n"))
            .button("Close");

        form.show(player).then((formData) => {
            if (formData.cancelationReason === "UserBusy") {
                system.runTimeout(() => {
                    this.onJoinMenu(player);
                }, 5);
                return;
            }

            player.setDynamicProperty(
                "msc:AddonVersion",
                ADDON_VERSION.join("."),
            );
        });
    }

    /** Updates names to match new name- compares changes using the 'player.uid' */
    static onJoin(player) {
        /** Information and Warning */
        const playerVersion = player.getDynamicProperty("msc:AddonVersion");
        if (playerVersion !== ADDON_VERSION.join(".")) {
            system.runTimeout(() => {
                this.onJoinMenu(player);
            }, 200);
        }

        /** Assign world hosts uid to the server as the world hosts uid */
        if (this.names[player.name] === 0) player.uid = this.names[player.name];

        /** If never had an entry previously, create one and save */
        if (!this.data[player.uid]) {
            this.data[player.uid] = { name: player.name };
            this.names[player.name] = player.uid;

            this.save();
            return;
        }

        /** If PlayerUID has an outdated username, update PlayerUID.names & PlayerUID.data for that player */
        if (this.data[player.uid].name !== player.name) {
            this.data[player.uid].name = player.name;

            for (const name of Object.keys(this.names)) {
                if (this.names[name].uid !== player.uid) continue;
                delete this.names[name];

                this.names[player.name] = player.uid;
            }

            this.save();
            return;
        }
    }

    /** Saves UIDs & Names whenever a new player joins */
    static save() {
        world.setDynamicProperty("msc:PlayerUIDs", JSON.stringify(this.data));
        world.setDynamicProperty("msc:PlayerNames", JSON.stringify(this.names));
    }
}

/** initialises the PlayerUID.data & PlayerUID.names */
system.run(() => {
    PlayerData.initialize();
});

/** Defines 'player.uid' as a typing */
Object.defineProperty(Player.prototype, "uid", {
    get() {
        /** If the uid exists, return the value */
        if (this.getDynamicProperty("uid"))
            return this.getDynamicProperty("uid");

        /** If the uid doesn't exist when trying to get it, auto create it */
        const num = Object.keys(PlayerData.data).length + 1;
        this.setDynamicProperty("uid", num);
        return num;
    },
    set(uid) {
        this.setDynamicProperty("uid", uid);
    },
});
