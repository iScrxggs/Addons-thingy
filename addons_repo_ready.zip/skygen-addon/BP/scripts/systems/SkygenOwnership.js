import { world } from "@minecraft/server";
import { Generator } from "./gens/GenData";
import { SKYGEN_OWNED_GEN_PREFIX } from "./SkygenConfig";

function ownershipKey(uid) {
    return `${SKYGEN_OWNED_GEN_PREFIX}${uid}`;
}

function normalizeCounts(rawCounts) {
    const normalized = {};
    if (!rawCounts || typeof rawCounts !== "object") return normalized;

    for (const [type, count] of Object.entries(rawCounts)) {
        const safeType = String(type ?? "").trim();
        const safeCount = Math.max(0, Math.floor(Number(count) || 0));
        if (!safeType || safeCount <= 0) continue;
        normalized[safeType] = safeCount;
    }

    return normalized;
}

export class SkygenOwnership {
    static getOwnedGeneratorCounts(uid) {
        const raw = world.getDynamicProperty(ownershipKey(uid));
        if (!raw || typeof raw !== "string") return {};
        try {
            return normalizeCounts(JSON.parse(raw));
        } catch {
            return {};
        }
    }

    static saveOwnedGeneratorCounts(uid, counts) {
        world.setDynamicProperty(
            ownershipKey(uid),
            JSON.stringify(normalizeCounts(counts)),
        );
    }

    static clearOwnedGeneratorCounts(uid) {
        world.setDynamicProperty(ownershipKey(uid), JSON.stringify({}));
    }

    static syncOwnedGeneratorCounts(uid) {
        const nextCounts = {};
        for (const dimensionId of Object.keys(Generator.data)) {
            for (const data of Object.values(Generator.data[dimensionId] ?? {})) {
                if (!data || data.owner !== uid) continue;
                const type = String(data.type ?? "").trim();
                if (!type) continue;
                nextCounts[type] = (nextCounts[type] ?? 0) + 1;
            }
        }

        this.saveOwnedGeneratorCounts(uid, nextCounts);
        return nextCounts;
    }

    static playerOwnsAnyGeneratorType(uid, types) {
        const owned = this.getOwnedGeneratorCounts(uid);
        for (const type of types) {
            if ((owned[type] ?? 0) > 0) return true;
        }
        return false;
    }
}
