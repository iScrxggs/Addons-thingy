import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { SkygenExchange } from "../SkygenExchange";
import { SkygenProgress } from "../SkygenProgress";
import {
    getJackpotChancePercent,
    getJackpotUpgradeCost,
    getMaxJackpotUpgradeLevel,
    getOverclockCost,
    getOverclockMultiplier,
    getSkygenConfig,
} from "../SkygenConfig";
import { SkygenAdminMenu } from "./SkygenAdminMenu";

export class SkygenProfileMenu {
    constructor(player) {
        this.player = player;
        this.main();
    }

    main() {
        const config = getSkygenConfig();
        const progress = SkygenProgress.get(this.player.uid);
        const isAdmin =
            this.player.hasTag("mscRealmDev") ||
            this.player.hasTag("admin") ||
            this.player.hasTag("plotadmin") ||
            this.player.hasTag("guiadmin");

        const form = new ActionFormData()
            .title("MSC SkyGen Profile")
            .body(
                [
                    SkygenProgress.formatStatBody(this.player),
                    "",
                    SkygenExchange.formatEconomyBody(this.player),
                    "",
                    `\u00A7bOverclock: \u00A7f${getOverclockMultiplier(progress.overclockLevel, config).toFixed(2)}x`,
                    `\u00A76Jackpot Chance: \u00A7e${getJackpotChancePercent(progress.jackpotChanceLevel, config).toFixed(2)}%`,
                ].join("\n"),
            )
            .button("Top Tokens")
            .button("Top Miners")
            .button("Cash Out Tokens")
            .button("Buy CTokens")
            .button("Upgrades");

        if (isAdmin) {
            form.button("Admin Config");
        }
        form.button("Close");

        form.show(this.player).then((formData) => {
            if (formData.canceled || formData.selection === undefined) return;

            if (formData.selection === 0) return this.leaderboard("tokens");
            if (formData.selection === 1) return this.leaderboard("blocksMined");
            if (formData.selection === 2) return this.cashOutMenu();
            if (formData.selection === 3) return this.buyCTokensMenu();
            if (formData.selection === 4) return this.upgradeMenu();
            if (isAdmin && formData.selection === 5) {
                new SkygenAdminMenu(this.player);
            }
        });
    }

    leaderboard(field) {
        const isTokenBoard = field === "tokens";
        const entries = SkygenProgress.topBy(
            isTokenBoard ? "tokens" : "blocksMined",
        );
        const body = entries.length
            ? entries
                  .map(
                      (entry, index) =>
                          `\u00A7e#${index + 1} \u00A7b${entry.name}\u00A77 - \u00A7f${entry.value.toLocaleString("en-US")} ${isTokenBoard ? "tokens" : "blocks"}`,
                  )
                  .join("\n")
            : "\u00A77No progress has been recorded yet.";

        new ActionFormData()
            .title(isTokenBoard ? "Top Tokens" : "Top Miners")
            .body(body)
            .button("Back")
            .show(this.player)
            .then(() => this.main());
    }

    cashOutMenu() {
        const state = SkygenExchange.getExchangeState(this.player);
        const form = new ActionFormData()
            .title("Cash Out Tokens")
            .body(
                [
                    `\u00A76Your tokens: \u00A7e${state.data.tokens.toLocaleString("en-US")}`,
                    `\u00A72Rate: \u00A7a1 token = $${state.tokenToMoneyRate.toLocaleString("en-US")}`,
                    `\u00A7cCashout room: \u00A7f$${state.remainingCashout.toLocaleString("en-US")}`,
                    `\u00A77Max tokens sellable right now: \u00A7f${Math.max(0, state.maxTokensSellableByCap).toLocaleString("en-US")}`,
                ].join("\n"),
            )
            .button("Sell 25 Tokens")
            .button("Sell 100 Tokens")
            .button("Sell 500 Tokens")
            .button("Custom Amount")
            .button("Back");

        form.show(this.player).then((formData) => {
            if (formData.canceled || formData.selection === 4) {
                this.main();
                return;
            }

            if (formData.selection === 0) return this.completeTokenCashout(25);
            if (formData.selection === 1) return this.completeTokenCashout(100);
            if (formData.selection === 2) return this.completeTokenCashout(500);
            if (formData.selection === 3) this.customTokenCashout();
        });
    }

    customTokenCashout() {
        const state = SkygenExchange.getExchangeState(this.player);
        new ModalFormData()
            .title("Custom Token Cashout")
            .textField(
                `Enter token amount to cash out.\nRate: $${state.tokenToMoneyRate.toLocaleString("en-US")} each\nCashout room left: $${state.remainingCashout.toLocaleString("en-US")}`,
                "100",
            )
            .submitButton("Exchange")
            .show(this.player)
            .then((formData) => {
                if (formData.canceled) {
                    this.cashOutMenu();
                    return;
                }

                const amount = Math.floor(Number(formData.formValues[0]) || 0);
                this.completeTokenCashout(amount);
            });
    }

    completeTokenCashout(amount) {
        const result = SkygenExchange.sellTokensForMoney(this.player, amount);
        if (!result.success) {
            this.player.sendMessage(`\u00A7c* [MSC] ${result.message}`);
            this.cashOutMenu();
            return;
        }

        const cappedSuffix = result.capped
            ? " \u00A78(Capped by your current cashout room)"
            : "";
        this.player.sendMessage(
            `\u00A7a* [MSC] Exchanged \u00A7e${result.soldTokens.toLocaleString("en-US")} tokens \u00A7afor \u00A72$${result.payout.toLocaleString("en-US")}\u00A7a.${cappedSuffix}`,
        );
        this.cashOutMenu();
    }

    buyCTokensMenu() {
        const state = SkygenExchange.getExchangeState(this.player);
        const form = new ActionFormData()
            .title("Buy CTokens")
            .body(
                [
                    `\u00A72Your money: \u00A7a$${state.money.toLocaleString("en-US")}`,
                    `\u00A7bYour CTokens: \u00A7f${state.ctokens.toLocaleString("en-US")}`,
                    `\u00A76Cost: \u00A7e$${state.moneyPerCToken.toLocaleString("en-US")} per CToken`,
                    `\u00A78Buying CTokens reduces your active cashout lock.`,
                ].join("\n"),
            )
            .button("Buy 1 CToken")
            .button("Buy 5 CTokens")
            .button("Buy 10 CTokens")
            .button("Custom Amount")
            .button("Back");

        form.show(this.player).then((formData) => {
            if (formData.canceled || formData.selection === 4) {
                this.main();
                return;
            }

            if (formData.selection === 0) return this.completeCTokenPurchase(1);
            if (formData.selection === 1) return this.completeCTokenPurchase(5);
            if (formData.selection === 2) return this.completeCTokenPurchase(10);
            if (formData.selection === 3) this.customCTokenPurchase();
        });
    }

    customCTokenPurchase() {
        const state = SkygenExchange.getExchangeState(this.player);
        new ModalFormData()
            .title("Custom CToken Purchase")
            .textField(
                `Enter how many CTokens to buy.\nCost: $${state.moneyPerCToken.toLocaleString("en-US")} each`,
                "1",
            )
            .submitButton("Buy")
            .show(this.player)
            .then((formData) => {
                if (formData.canceled) {
                    this.buyCTokensMenu();
                    return;
                }

                const amount = Math.floor(Number(formData.formValues[0]) || 0);
                this.completeCTokenPurchase(amount);
            });
    }

    completeCTokenPurchase(amount) {
        const result = SkygenExchange.buyCTokens(this.player, amount);
        if (!result.success) {
            this.player.sendMessage(`\u00A7c* [MSC] ${result.message}`);
            this.buyCTokensMenu();
            return;
        }

        this.player.sendMessage(
            `\u00A7a* [MSC] Bought \u00A7b${result.ctokenAmount.toLocaleString("en-US")} CTokens \u00A7afor \u00A72$${result.totalCost.toLocaleString("en-US")}\u00A7a. Cashout lock freed: \u00A7f$${result.unlockedCashout.toLocaleString("en-US")}`,
        );
        this.buyCTokensMenu();
    }

    upgradeMenu() {
        const config = getSkygenConfig();
        const progress = SkygenProgress.get(this.player.uid);
        const overclockCost = getOverclockCost(progress.overclockLevel, config);
        const overclockMultiplier = getOverclockMultiplier(
            progress.overclockLevel,
            config,
        );
        const jackpotCost = getJackpotUpgradeCost(
            progress.jackpotChanceLevel,
            config,
        );
        const jackpotChancePercent = getJackpotChancePercent(
            progress.jackpotChanceLevel,
            config,
        );
        const maxJackpotLevel = getMaxJackpotUpgradeLevel(config);
        const maxOverclockLevel = Math.max(
            0,
            config.overclockMultipliers.length - 1,
        );

        new ActionFormData()
            .title("Generator Upgrades")
            .body(
                [
                    `\u00A76Tokens: \u00A7e${progress.tokens.toLocaleString("en-US")}`,
                    `\u00A7bOverclock: \u00A7f${overclockMultiplier.toFixed(2)}x \u00A78(level ${progress.overclockLevel}/${maxOverclockLevel})`,
                    `\u00A76Jackpot Chance: \u00A7e${jackpotChancePercent.toFixed(2)}% \u00A78(level ${progress.jackpotChanceLevel}/${maxJackpotLevel})`,
                ].join("\n"),
            )
            .button(
                progress.overclockLevel >= maxOverclockLevel
                    ? "Overclock Maxed"
                    : `Upgrade Overclock (${overclockCost.toLocaleString("en-US")} tokens)`,
            )
            .button(
                progress.jackpotChanceLevel >= maxJackpotLevel
                    ? "Jackpot Chance Maxed"
                    : `Upgrade Jackpot (${jackpotCost.toLocaleString("en-US")} tokens)`,
            )
            .button("Back")
            .show(this.player)
            .then((response) => {
                if (response.canceled || response.selection === 2) {
                    this.main();
                    return;
                }

                if (response.selection === 0) {
                    const result = SkygenProgress.purchaseOverclock(this.player);
                    if (!result.success) {
                        this.player.sendMessage(`\u00A7c* [MSC] ${result.message}`);
                    } else {
                        this.player.sendMessage(
                            `\u00A7a* [MSC] Overclock upgraded to \u00A7b${result.multiplier.toFixed(2)}x\u00A7a for \u00A7e${result.cost.toLocaleString("en-US")}\u00A7a tokens.`,
                        );
                    }
                    this.upgradeMenu();
                    return;
                }

                if (response.selection === 1) {
                    const result = SkygenProgress.purchaseJackpotUpgrade(this.player);
                    if (!result.success) {
                        this.player.sendMessage(`\u00A7c* [MSC] ${result.message}`);
                    } else {
                        this.player.sendMessage(
                            `\u00A7a* [MSC] Jackpot chance upgraded to \u00A7e${result.jackpotChancePercent.toFixed(2)}%\u00A7a for \u00A76${result.cost.toLocaleString("en-US")}\u00A7a tokens.`,
                        );
                    }
                    this.upgradeMenu();
                }
            });
    }
}
