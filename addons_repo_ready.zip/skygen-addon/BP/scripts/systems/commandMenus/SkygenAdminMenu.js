import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import {
    getDefaultSkygenConfig,
    getSkygenConfig,
    saveSkygenConfig,
} from "../SkygenConfig";
import { syncWorldSellCatalog } from "../SkygenCatalog";

function parseNumber(value, fallback) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
}

function parseInteger(value, fallback) {
    return Math.floor(parseNumber(value, fallback));
}

function parseNumberList(value, fallback) {
    const parsed = String(value ?? "")
        .split(/[,\n]+/)
        .map((entry) => Number(entry.trim()))
        .filter((entry) => Number.isFinite(entry));
    return parsed.length > 0 ? parsed : fallback;
}

function parseRebirthGates(value, fallback) {
    const parsed = String(value ?? "")
        .split(/[;\n]+/)
        .map((line) => line.trim())
        .filter(Boolean)
        .map((line) => {
            const [minPriceRaw, rebirthRaw] = line.split("|");
            const minPrice = Math.max(0, parseInteger(minPriceRaw, 0));
            const requiredRebirth = Math.max(0, parseInteger(rebirthRaw, 0));
            return { minPrice, requiredRebirth };
        })
        .filter((gate) => Number.isFinite(gate.minPrice) && Number.isFinite(gate.requiredRebirth));
    return parsed.length > 0 ? parsed : fallback;
}

export class SkygenAdminMenu {
    constructor(player) {
        this.player = player;
        this.main();
    }

    main() {
        const config = getSkygenConfig();
        const form = new ActionFormData()
            .title("MSC SkyGen Admin")
            .body(
                [
                    `\u00A76Token Rate: \u00A7e1 token = $${config.tokenToMoneyRate.toLocaleString("en-US")}`,
                    `\u00A7dCToken Cost: \u00A7f$${config.moneyPerCToken.toLocaleString("en-US")}`,
                    `\u00A7cCashout Cap: \u00A7f$${config.maxActiveTokenCashout.toLocaleString("en-US")}`,
                    `\u00A7bBase Tokens/Break: \u00A7f${config.baseTokensPerBreak}`,
                    `\u00A76Jackpot Chance: \u00A7e${config.jackpotBaseChancePercent.toFixed(2)}% base`,
                    `\u00A7bOverclock Levels: \u00A7f${config.overclockMultipliers.join("x, ")}x`,
                ].join("\n"),
            )
            .button("Token Economy")
            .button("Jackpot Rates")
            .button("Overclock Upgrades")
            .button("Rebirth Sell Gates")
            .button("Reset Config")
            .button("Back");

        form.show(this.player).then((response) => {
            if (response.canceled || response.selection === 5) return;
            if (response.selection === 0) return this.tokenEconomy();
            if (response.selection === 1) return this.jackpotSettings();
            if (response.selection === 2) return this.overclockSettings();
            if (response.selection === 3) return this.rebirthSellGates();
            if (response.selection === 4) {
                const defaults = getDefaultSkygenConfig();
                saveSkygenConfig(defaults);
                syncWorldSellCatalog(defaults);
                this.player.sendMessage(
                    "\u00A7a* [MSC] SkyGen admin config reset and sell catalog refreshed.",
                );
                this.main();
            }
        });
    }

    tokenEconomy() {
        const config = getSkygenConfig();
        const form = new ModalFormData()
            .title("Token Economy")
            .textField("Money per token cashout", "10000", `${config.tokenToMoneyRate}`)
            .textField("Money per CToken", "2500000", `${config.moneyPerCToken}`)
            .textField("Max active cashout lock", "2147483647", `${config.maxActiveTokenCashout}`)
            .textField("Base tokens per generator break", "1", `${config.baseTokensPerBreak}`)
            .submitButton("Save");

        form.show(this.player).then((response) => {
            if (response.canceled || !response.formValues) {
                this.main();
                return;
            }

            const nextConfig = {
                ...config,
                tokenToMoneyRate: Math.max(
                    1,
                    parseInteger(response.formValues[0], config.tokenToMoneyRate),
                ),
                moneyPerCToken: Math.max(
                    1,
                    parseInteger(response.formValues[1], config.moneyPerCToken),
                ),
                maxActiveTokenCashout: Math.max(
                    1,
                    parseInteger(response.formValues[2], config.maxActiveTokenCashout),
                ),
                baseTokensPerBreak: Math.max(
                    1,
                    parseInteger(response.formValues[3], config.baseTokensPerBreak),
                ),
            };
            saveSkygenConfig(nextConfig);
            syncWorldSellCatalog(nextConfig);
            this.player.sendMessage("\u00A7a* [MSC] Token economy settings updated.");
            this.main();
        });
    }

    jackpotSettings() {
        const config = getSkygenConfig();
        const rewardLines = config.jackpotRewardTiers
            .map((tier) => `${tier.min}|${tier.max}|${tier.weight}`)
            .join("\n");
        const form = new ModalFormData()
            .title("Jackpot Rates")
            .textField("Base jackpot chance (%)", "0.1", `${config.jackpotBaseChancePercent}`)
            .textField(
                "Jackpot chance upgrade increment (%)",
                "0.1",
                `${config.jackpotUpgradeIncrementPercent}`,
            )
            .textField("Jackpot chance max (%)", "2.5", `${config.jackpotChanceMaxPercent}`)
            .textField("Jackpot upgrade base cost", "500", `${config.jackpotUpgradeBaseCost}`)
            .textField("Jackpot upgrade max cost", "25000", `${config.jackpotUpgradeMaxCost}`)
            .textField("Reward tiers (min|max|weight, one per line)", "50|150|78", rewardLines)
            .submitButton("Save");

        form.show(this.player).then((response) => {
            if (response.canceled || !response.formValues) {
                this.main();
                return;
            }

            const rewardTiers = String(response.formValues[5] ?? "")
                .split(/[;\n]+/)
                .map((line) => line.trim())
                .filter(Boolean)
                .map((line) => {
                    const [minRaw, maxRaw, weightRaw] = line.split("|");
                    const min = Math.max(1, parseInteger(minRaw, 50));
                    const max = Math.max(min, parseInteger(maxRaw, 150));
                    const weight = Math.max(1, parseInteger(weightRaw, 1));
                    return { min, max, weight };
                });

            const nextConfig = {
                ...config,
                jackpotBaseChancePercent: Math.max(
                    0,
                    parseNumber(response.formValues[0], config.jackpotBaseChancePercent),
                ),
                jackpotUpgradeIncrementPercent: Math.max(
                    0.01,
                    parseNumber(
                        response.formValues[1],
                        config.jackpotUpgradeIncrementPercent,
                    ),
                ),
                jackpotChanceMaxPercent: Math.max(
                    0.1,
                    parseNumber(response.formValues[2], config.jackpotChanceMaxPercent),
                ),
                jackpotUpgradeBaseCost: Math.max(
                    0,
                    parseInteger(response.formValues[3], config.jackpotUpgradeBaseCost),
                ),
                jackpotUpgradeMaxCost: Math.max(
                    0,
                    parseInteger(response.formValues[4], config.jackpotUpgradeMaxCost),
                ),
                jackpotRewardTiers:
                    rewardTiers.length > 0 ? rewardTiers : config.jackpotRewardTiers,
            };
            saveSkygenConfig(nextConfig);
            syncWorldSellCatalog(nextConfig);
            this.player.sendMessage("\u00A7a* [MSC] Jackpot settings updated.");
            this.main();
        });
    }

    overclockSettings() {
        const config = getSkygenConfig();
        const form = new ModalFormData()
            .title("Overclock Upgrades")
            .textField(
                "Overclock multipliers (comma separated)",
                "1,2,3",
                config.overclockMultipliers.join(","),
            )
            .textField(
                "Overclock costs (comma separated)",
                "5000,20000",
                config.overclockCosts.join(","),
            )
            .submitButton("Save");

        form.show(this.player).then((response) => {
            if (response.canceled || !response.formValues) {
                this.main();
                return;
            }

            const nextConfig = {
                ...config,
                overclockMultipliers: parseNumberList(
                    response.formValues[0],
                    config.overclockMultipliers,
                ).map((value) => Math.max(1, value)),
                overclockCosts: parseNumberList(
                    response.formValues[1],
                    config.overclockCosts,
                ).map((value) => Math.max(0, Math.floor(value))),
            };
            saveSkygenConfig(nextConfig);
            this.player.sendMessage("\u00A7a* [MSC] Overclock settings updated.");
            this.main();
        });
    }

    rebirthSellGates() {
        const config = getSkygenConfig();
        const gateLines = config.rebirthSellGates
            .map((gate) => `${gate.minPrice}|${gate.requiredRebirth}`)
            .join("\n");
        const form = new ModalFormData()
            .title("Rebirth Sell Gates")
            .textField("Price|rebirth per line", "6000|1", gateLines)
            .submitButton("Save");

        form.show(this.player).then((response) => {
            if (response.canceled || !response.formValues) {
                this.main();
                return;
            }

            const nextConfig = {
                ...config,
                rebirthSellGates: parseRebirthGates(
                    response.formValues[0],
                    config.rebirthSellGates,
                ),
            };
            saveSkygenConfig(nextConfig);
            syncWorldSellCatalog(nextConfig);
            this.player.sendMessage("\u00A7a* [MSC] Rebirth sell gates updated.");
            this.main();
        });
    }
}
