import { ActionFormData } from "@minecraft/server-ui";

const topics = {
    Download: "textures/ui/msc/mcpedl",
    "Gens & Gen Eggs": "textures/BlockGenEggs/acacia_log",
    "Auto Miners": "textures/ui/msc/auto_miner",
    "Experience Tanks": "textures/ui/msc/experience_tank",
    "Item Storers": "textures/ui/msc/item_storer",
    "Admin Wrench": "textures/wrenches/admin_wrench",
};

export class mscHelpMenu {
    // use case: 'new mscHelpMenu(player)'
    constructor(player) {
        this.player = player;
        this.main();
    }

    // Main Page
    main() {
        const form = new ActionFormData().title("Myth's Skygen Creator : Help");

        for (const topic of Object.keys(topics)) {
            form.button(topic, topics[topic]);
        }

        form.show(this.player).then((formData) => {
            if (formData.canceled) return;

            // Download
            if (formData.selection === 0) {
                this.downloadLinkMSC();
                return;
            }

            // Gens & Gen Eggs
            if (formData.selection === 1) {
                this.gensAndGenEggs();
                return;
            }

            // Auto Miners
            if (formData.selection === 2) {
                this.autoMiners();
                return;
            }

            // Experience Tanks
            if (formData.selection === 3) {
                this.expTanks();
                return;
            }

            // Item Storers
            if (formData.selection === 4) {
                this.itemStorers();
                return;
            }

            // Admin Wrench
            if (formData.selection === 5) {
                this.adminWrench();
                return;
            }
        });
    }

    // --------------------------------------------

    // Download MSC Links
    downloadLinkMSC() {
        // Body Text
        const desc = [
            "",
            "§dMyth's Skygen Creator §bis a free pack on MCPEDL and Curseforge. You can find the packs from the following links;",
            "",
            "§l§6Curseforge§r§6",
            "curseforge.com/members/",
            "mythicode/projects",
            "",
            "§l§aMCPEDL§r§a",
            "mcpedl.com/user/mythicode",
            "",
            " ",
        ];

        // Form
        const form = new ActionFormData()
            .title("Download MSC")
            .body(desc.join("\n"))
            .button("Back");

        form.show(this.player).then((formData) => {
            if (formData.canceled) return;

            // Back
            this.main();
        });
    }

    // --------------------------------------------

    // Gens & Gen Eggs
    gensAndGenEggs() {
        // Body Text
        const desc = [
            "",
            "§eGen Eggs §bspawn §eGenerators §bwhen placed; this is the back bone of Skygens.",
            "",
            "§l§e[Sneak §r§e+ §lInteract §r§e+ §lEmpty Hand]§r",
            "§7Picks up the generator as a Gen Egg if you own it, letting you move it.",
            "§c* Doing this in Creative as an Operator deletes the generator instead.",
            "",
            "§e§l[Interact §r§e+ §lAdmin Wrench]§r",
            "§7This opens a menu where the player can universally edit all respawn times for Generators of that specific type.§r",
            " ",
        ];

        // Form
        const form = new ActionFormData()
            .title("Gens & Gen Eggs")
            .body(desc.join("\n"))
            .button("Back");

        form.show(this.player).then((formData) => {
            if (formData.canceled) return;

            // Back
            this.main();
        });
    }

    // --------------------------------------------

    // Auto Miners
    autoMiners() {
        // Body Text
        const desc = [
            "",
            "§eAuto Miners §bmine the block below it automatically; typically paired with Generators.",
            "",
            "§bYou can pickup and move autominers with their levels saved, other players cannot move your miners.",
            "§c* Breaking in creative as an operator deletes the miner.",
            "",
            "§l§e[Levels]§r",
            "§7Autominers can be configured to have have levels, this is based on Base Mining Speed & Max Levels to ensure the Max Level is always 0 ticks.",
            "§c* Max Level is 1 by default which disables levels effectively.",
            "",
            "§e§l[Interact §r§e+ §lAdmin Wrench]§r",
            "§7This opens a menu where you can edit the config for ALL autominers. This includes the following settings...",
            "§b- Max Levels\n- Base Mining Speed\n- Exponential Level Cost\n- Base Level Cost§r",
            " ",
        ];

        // Form
        const form = new ActionFormData()
            .title("Auto Miners")
            .body(desc.join("\n"))
            .button("Back");

        form.show(this.player).then((formData) => {
            if (formData.canceled) return;

            // Back
            this.main();
        });
    }

    // --------------------------------------------

    // Experience Tanks
    expTanks() {
        // Body Text
        const desc = [
            "",
            "§eExperience Tanks §bautomatically store nearby exp orbs; intended to reduce entity lag but it also has a few other mechanics.",
            "",
            "§bYou can move your exp tanks with all the exp inside. Once placed, other players cannot pick it up.",
            "§c* Breaking it in creative as an op deletes the experience tank.",
            "",
            "§l§e[Mend Items]§r",
            "§7Items inside of a container directly above the Experience Tank will use 1 exp per item to repair 1 durability every second.",
            "§a* Items do NOT need Mending to be repaired this way.",
            "",
            "§l§e[Interact §r§e+ §lGlass Bottle]§r",
            "§7This will create 1 experience bottle from the stack you used on the experience tank for every 15 experience it uses.",
            "§a* This means a full stack of EXP Bottles is 980 exp & 64 glass bottles.",
            " ",
        ];

        // Form
        const form = new ActionFormData()
            .title("Experience Tanks")
            .body(desc.join("\n"))
            .button("Back");

        form.show(this.player).then((formData) => {
            if (formData.canceled) return;

            // Back
            this.main();
        });
    }

    // --------------------------------------------

    // Item Storers
    itemStorers() {
        // Body Text
        const desc = [
            "",
            "§eItem Storers §bautomatically store nearby ground items of an assigned type infinitely; intended to reduce entity lag and store items better.",
            "",
            "§bOnce placed, others cannot move them. But on breaking this block the stored items are deleted.",
            "§c* Ops in Creative can break them.",
            "",
            "§l§e[INTERACT §r§e+ §lANY ITEM]§r",
            "§7Interacting on the item storer with an item after it is placed will assign that type of item.",
            "§b* To assign a different item, you need to replace the item storer.",
            "",
            "§l§e[Super Fast Output]§r",
            "§7Containers directly below the item storer will output items from the item storer extremely fast; you can imagine the item storer as a faster hopper that cannot be backed up.",
            // "§a* Items do NOT need Mending to be repaired this way.",
            // "",
            // "§l§e[Interact §r§e+ §lGlass Bottle]§r",
            // "§7This will create 1 experience bottle from the stack you used on the experience tank for every 15 experience it uses.",
            // "§a* This means a full stack of EXP Bottles is 980 exp & 64 glass bottles.",
            " ",
        ];

        // Form
        const form = new ActionFormData()
            .title("Item Storers")
            .body(desc.join("\n"))
            .button("Back");

        form.show(this.player).then((formData) => {
            if (formData.canceled) return;

            // Back
            this.main();
        });
    }

    // --------------------------------------------

    // Admin Wrench
    adminWrench() {
        // Body Text
        const desc = [
            "",
            "§bThe §eAdmin Wrench§b is an important tool for configuring machines or features within the pack.",
            "",
            "§bUsing them on different features opens different admin menu's to allow for their configuring.",
            "§6* Player must be an Operator in Creative to use it.",
            "",
            "§l§e[Use on Auto Miners]§r",
            "§7Opens the Auto Miner menu with the config menu option, letting the user to edit the following...",
            "§e- Max Levels\n- Base Mining Speed\n- Exponential Level Cost\n- Base Level Cost",
            "",
            "§e§l[Use on Generators]§r",
            "§7Opens the Generator menu allowing the universal edit option, this edits all the respawn times for gens of the type you interacted on. So you can set ALL coal gens to 10t respawn delay if you want by interacting on Coal Gens and universally editing them.",
            " ",
        ];

        // Form
        const form = new ActionFormData()
            .title("Admin Wrench")
            .body(desc.join("\n"))
            .button("Back");

        form.show(this.player).then((formData) => {
            if (formData.canceled) return;

            // Back
            this.main();
        });
    }
}
