import {
    Block,
    Dimension,
    ItemStack,
    Player,
    system,
    world,
} from "@minecraft/server";
import { DIMENSION_NUM } from "../../constants";
import { stringToVector3, vector3ToString } from "../../utils/Locations";
import { devLog } from "../DeveloperMode";
import { splitByLength } from "../../utils/Formats";
import { centerLocation } from "../../utils/Blocks";
import { ITEM_STORER_SOUNDS } from "../../sounds";
import { isOpInGMC } from "../../utils/Player";

export class ItemStorer {
    /**
     *  "minecraft:overworld": {
     *      "x,y,z": { owner: 0, itemTypeId: "minecraft:diamond", amountStored: 0 }
     *  },
     *  "minecraft:nether": {},
     *  "minecraft:the_end": {}
     */
    static data = {
        "minecraft:overworld": {},
        "minecraft:nether": {},
        "minecraft:the_end": {},
    };

    // -----------------------------------------------------
    // -----------------------------------------------------

    /** Initialises all data */
    static init() {
        this.loadParts();
    }

    /** Loads Storage Addon Data */
    static loadParts() {
        if (!world.getDynamicProperty("msc:ItemStorerParts")) {
            world.setDynamicProperty("msc:ItemStorerParts", 0);
        }

        const partsAmt = world.getDynamicProperty("msc:ItemStorerParts");
        const parts = [];

        // For part, push to the string list
        for (let i = 0; i < partsAmt; i++) {
            const property = world.getDynamicProperty(`msc:ItemStorerData${i}`);
            parts.push(property);
        }

        // After all parts are pushed, join then parse it to this.data
        const property = parts.join("");
        if (property === "") return;

        // Sets this.data
        this.data = JSON.parse(parts.join(""), null, "\t");
        devLog(`§6Loaded §bItem Storer §6data [§b${parts.length} parts§6]`);
    }

    /**
     * Saves Storage Addon Data
     * @param {Boolean} log determines whether or not to signal the devlog, true by default so that autosaves every 10s for storage addons arent broadcast
     */
    static save(log = true) {
        const charactersPerPart = 10000;

        // New amount of parts
        const parts = splitByLength(
            JSON.stringify(this.data),
            charactersPerPart,
        );

        // Save part indexes as ordered in the parts lsit
        for (let i = 0; i < parts.length; i++) {
            world.setDynamicProperty(`msc:ItemStorerData${i}`, parts[i]);
        }

        world.setDynamicProperty("msc:ItemStorerParts", parts.length);
        if (log) {
            system.runTimeout(() => {
                devLog(
                    `§6Saved §bItem Storer §6data [§b${parts.length} parts§6]`,
                );
            }, 1);
        }
    }

    // -----------------------------------------------------
    // -----------------------------------------------------

    /**
     * Returns true/false is the player is the owner of the specififed item storer
     * @param {Dimension.id} dimensionId
     * @param {String} locationString
     * @param {Player} player
     * @returns {Boolean}
     */
    static isOwner(dimensionId, locationString, player) {
        const ownerUID = this.data[dimensionId][locationString].owner;
        if (ownerUID === player.uid) return true;
        return false;
    }

    // -----------------------------------------------------
    // -----------------------------------------------------

    /**
     * Adds item storer to a location & dimension
     * @param {Dimension} dimension
     * @param {Vector3} location
     * @param {Player} player
     */
    static add(dimension, location, player) {
        const xyz = vector3ToString(location);
        const dimId = dimension.id;

        // Add data entry
        this.data[dimId][xyz] = {
            owner: player.uid,
            item: false,
            amount: 0,
        };

        // Playsound
        const soundOnPlace = ITEM_STORER_SOUNDS.onPlace;
        dimension.playSound(
            soundOnPlace.string,
            centerLocation(location),
            soundOnPlace.optional,
        );

        // Dev Log
        devLog(`${player.name}[${player.uid}] placed §bItem Storer §e@${xyz}`);

        // Save Data
        this.save();
    }

    /**
     * Removes an existing storage addon entry
     * @param {Dimension} dimension
     * @param {Vector3} location
     * @param {Player} player
     * @returns {Boolean} If 'true'- cancel break event, if 'false' don't cancel break event
     */
    static remove(dimension, location, player) {
        const xyz = vector3ToString(location);
        const dimId = dimension.id;

        const soundOnPickup = ITEM_STORER_SOUNDS.onPickup;
        const soundOnFailPickup = ITEM_STORER_SOUNDS.onFailPickup;

        // Prevents false errors when removing
        if (!this.data[dimId][xyz]) return true;

        // Is op in creative
        if (isOpInGMC(player)) {
            // Remove Data
            this.removeAllEntries(dimId, xyz);

            // Dev Log
            devLog(
                `${player.name}[${player.uid}] §cdeleted §bItem Storer §e@${xyz}`,
            );

            // Playsound
            dimension.playSound(
                soundOnPickup.string,
                centerLocation(location),
                soundOnPickup.optional,
            );
            return;
        }

        // Is owner
        if (this.isOwner(dimId, xyz, player)) {
            // Remove Data
            this.removeAllEntries(dimId, xyz);

            // Dev Log
            devLog(
                `${player.name}[${player.uid}] picked up §bItem Storer §e@${xyz}`,
            );

            // Playsound
            dimension.playSound(
                soundOnPickup.string,
                centerLocation(location),
                soundOnPickup.optional,
            );
            return;
        }

        // Dev Log
        devLog(
            `${player.name}[${player.uid}] tried §cremoving §bItem Storers §e@${xyz} §awithout owning it`,
        );

        // Sound
        player.sendMessage("§c* [MSC] Cannot move Item Storers you don't own!");
        player.playSound(soundOnFailPickup.string, soundOnFailPickup.optional);
        return;
    }

    /**
     * Removes all entries related to the dimension id and location
     * @param {Dimension.id} dimensionId
     * @param {String} locationString
     */
    static removeAllEntries(dimensionId, locationString) {
        delete this.data[dimensionId][locationString];
        this.save();

        // Remove floating text, if it exists
        const location = centerLocation(stringToVector3(locationString));
        const dimension = world.getDimension(dimensionId);

        const textQuery = {
            type: "msc:floating_text",
            location: location,
            maxDistance: 1,
        };
        const floatingText = [...dimension.getEntities(textQuery)][0];
        if (floatingText) floatingText.remove();
    }

    /**
     * Assigns an itemstack to the storage addon
     * @param {Dimension} dimension
     * @param {Vector3} location
     * @param {Player} player
     * @param {ItemStack} itemStack
     */
    static assign(dimension, location, player, itemStack) {
        const xyz = vector3ToString(location);
        const dimId = dimension.id;

        /** Return if not owner */
        if (this.data[dimId][xyz].owner !== player.uid) {
            devLog(
                `${player.name}[${player.uid}] tried assigning §bStorage Addon §aitem §e@${xyz} §awithout being the owner`,
            );
            player.sendMessage(
                "§c* [MSC] Cannot assign items to a Storage Addon you don't own!",
            );
            player.playSound("note.bass");
            return;
        }

        /** If already has the item */
        if (this.data[dimId][xyz].item) {
            devLog(
                `${player.name}[${player.uid}] tried to assigning §bStorage Addon §aitem §e@${xyz} §abut it has one already`,
            );
            player.sendMessage(
                "§c* [MSC] This addon already has an item assigned!",
            );
            player.playSound("note.bass");
            return;
        }

        /** Assign item */
        this.data[dimId][xyz].item = itemStack.typeId;
        devLog(
            `${player.name}[${player.uid}] assigned §b${itemStack.typeId} §aas §bStorage Addon §aitem §e@${xyz}`,
        );
        player.sendMessage("§a* [MSC] Assigned item to the block!");
        player.playSound("note.chime");
        this.save();
    }

    /**
     * Runs storage addon functionality per tick
     * @param {Dimension} dimension
     * @param {Vector3} location
     */
    static onTick(dimension, location) {
        const xyz = vector3ToString(location);
        const dimId = dimension.id;

        // Data
        const storageData = this.data[dimId][xyz];
        const targetItem = storageData.item;

        // Run check for item
        const query = {
            type: "minecraft:item",
            location: centerLocation(location),
            maxDistance: 3,
        };
        const entities = [...dimension.getEntities(query)];

        // If item is input
        if (targetItem) {
            // For each item entity on ground within 2 block radius of addon
            for (const itemEntity of entities) {
                const itemStack = itemEntity.getComponent("item").itemStack;
                const typeId = itemStack.typeId;

                // If not target item, continue
                if (targetItem !== typeId) continue;

                // Add item to storage then remove it
                this.data[dimId][xyz].amount += itemStack.amount;
                itemEntity.remove();
            }
        }

        // Output to container below (if space)
        if (this.data[dimId][xyz].amount > 0) {
            const targetBlock = dimension.getBlock(location);
            if (!targetBlock) return;

            const blockUnder = targetBlock.below();
            if (!blockUnder.getComponent("inventory")) return;

            // Container Add
            if (this.outputToContainer(blockUnder, targetItem)) {
                this.data[dimId][xyz].amount -= 1;
                return;
            }
        }
    }

    /**
     * Outputs items from the storer to the container directly below it
     * @param {Block} blockUnder
     * @param {ItemStack.typeId} itemTypeId
     */
    static outputToContainer(blockUnder, itemTypeId) {
        const itemStack = new ItemStack(itemTypeId);
        const container = blockUnder.getComponent("inventory").container;

        // If there is spaces left at all
        if (container.emptySlotsCount > 0) {
            container.addItem(itemStack);
            return true;
        }

        // If the item already exists and there exists a stack that is BELOW 64
        if (container.contains(itemStack)) {
            let noRoom = true;
            for (let i = 0; i < container.size; i++) {
                const item = container.getItem(i);
                if (!item || item.typeId !== itemTypeId) continue;
                if (item.amount === itemStack.maxAmount) continue;
                noRoom = false;
                break;
            }

            // If room, add item
            if (!noRoom) {
                container.addItem(itemStack);
                return true;
            }
        }

        return false;
    }

    // -----------------------------------------------------
    // -----------------------------------------------------

    /**
     * Checks whether the storage addon owner is online and does a true/false
     * @param {Dimension.id} dimensionId
     * @param {String} locationString
     * @returns {Boolean}
     */
    static _storageOwnerOnline(dimensionId, locationString) {
        const storageData = this.data[dimensionId][locationString];
        for (const player of world.getAllPlayers()) {
            if (player.uid === storageData.owner) return true;
        }
        return false;
    }
}

system.run(() => {
    ItemStorer.init();
});

const dimensionIds = Object.keys(DIMENSION_NUM);
system.runInterval(() => {
    for (const dimension of dimensionIds) {
        // Storage Data Tick
        for (const xyz of Object.keys(ItemStorer.data[dimension])) {
            const storageData = ItemStorer.data[dimension][xyz];
            const location = stringToVector3(xyz);
            const dim = world.getDimension(dimension);

            // If not loaded
            if (!dim.getBlock(location)) continue;

            // If loaded but is not present anymore
            if (dim.getBlock(location).typeId !== "msc:item_storer") {
                devLog(`§cRemoved §aunpresent §bItem Storer §aentry from data`);
                ItemStorer.removeAllEntries(dimension, xyz);
                continue;
            }

            // If no item is assigned yet
            if (!storageData.item) continue;

            // If owner is not online
            if (!ItemStorer._storageOwnerOnline(dimension, xyz)) continue;

            // Runs the tick functionality of storage addons
            ItemStorer.onTick(dim, location);
        }
    }
});

// Save every 10s
system.runInterval(() => {
    system.run(() => {
        ItemStorer.save(false);
    });
}, 200);
