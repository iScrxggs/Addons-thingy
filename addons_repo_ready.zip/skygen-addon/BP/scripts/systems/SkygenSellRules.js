import { world } from "@minecraft/server";
import { loadSkygenSellCatalog } from "./SkygenCatalog";
import { PLOTSHOP_ECONOMY_DATA_PREFIX } from "./SkygenConfig";
import { SkygenOwnership } from "./SkygenOwnership";

function getPlayerRebirths(player) {
    const raw = world.getDynamicProperty(
        `${PLOTSHOP_ECONOMY_DATA_PREFIX}${player.id}`,
    );
    if (!raw || typeof raw !== "string") return 0;

    try {
        const parsed = JSON.parse(raw);
        return Math.max(0, Math.floor(Number(parsed?.rebirths) || 0));
    } catch {
        return 0;
    }
}

function buildCatalogMap() {
    return new Map(
        loadSkygenSellCatalog().entries.map((entry) => [entry.itemId, entry]),
    );
}

export function evaluateSkygenSellAccess(player, itemId) {
    const entry = buildCatalogMap().get(itemId);
    if (!entry) {
        return {
            allowed: true,
            reason: null,
            entry: null,
        };
    }

    const rebirths = getPlayerRebirths(player);
    if (rebirths < entry.requiredRebirth) {
        return {
            allowed: false,
            reason: "rebirth",
            entry,
            requiredRebirth: entry.requiredRebirth,
        };
    }

    if (entry.alwaysAllowed || entry.requiredGenerators.length === 0) {
        return {
            allowed: true,
            reason: null,
            entry,
        };
    }

    if (!SkygenOwnership.playerOwnsAnyGeneratorType(player.uid, entry.requiredGenerators)) {
        return {
            allowed: false,
            reason: "ownership",
            entry,
        };
    }

    return {
        allowed: true,
        reason: null,
        entry,
    };
}

export function summarizeBlockedSellItems(blockedCounts) {
    const summaries = [];
    for (const [itemId, details] of blockedCounts.entries()) {
        const label = itemId.split(":")[1] ?? itemId;
        if (details.reason === "rebirth") {
            summaries.push(
                `${label} x${details.amount} because you need rebirth ${details.requiredRebirth}`,
            );
            continue;
        }
        if (details.reason === "ownership") {
            summaries.push(
                `${label} x${details.amount} because you do not own that generator yet`,
            );
        }
    }
    return summaries;
}
