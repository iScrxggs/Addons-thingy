// EXPERIENCE TANK SOUNDS
export const EXPERIENCE_TANK_SOUNDS = {
    // Place Stuff
    onPlace: {
        string: "block.end_portal_frame.fill",
        optional: {
            pitch: 1.5,
        },
    },

    // Break Stuff
    onBreak: {
        string: "dig.basalt",
        optional: {
            pitch: 0.5,
        },
    },
    failBreak: {
        string: "note.bass",
        optional: {},
    },

    // Craft Stuff
    failCraft: {
        string: "note.bass",
        optional: {},
    },
    onCraft: {
        string: "random.orb",
        optional: {},
    },
};

// AUTO MINER SOUNDS
export const AUTOMINER_SOUNDS = {
    // Place Stuff
    onPlace: {
        string: "place.chiseled_bookshelf",
        optional: {},
    },

    // Break Stuff
    onBreak: {
        string: "pickup.chiseled_bookshelf",
        optional: {
            pitch: 0.8,
        },
    },
    failBreak: {
        string: "note.bass",
        optional: {},
    },

    // Level UP Struff
    onUpgrade: {
        string: "random.levelup",
        optional: {},
    },
    onFailUpgrade: {
        string: "note.bass",
        optional: {},
    },

    // Config Change Stuff
    onConfigChange: {
        string: "note.chime",
        optional: {},
    },
    failConfigChange: {
        string: "note.bass",
        optional: {},
    },
};

// GENERATOR SOUNDS
export const GENERATOR_SOUNDS = {
    // Place Stuff
    onPlace: {
        string: "beacon.activate",
        optional: {},
    },

    // Pickup Stuff
    onPickup: {
        string: "beacon.deactivate",
        optional: {},
    },
    onFailPickup: {
        string: "note.bass",
        optional: {},
    },

    // Gen Menu
    onValidInput: {
        string: "note.chime",
        optional: {},
    },
    onInvalidInput: {
        string: "note.bass",
        optional: {},
    },
};

// ITEM STORER
export const ITEM_STORER_SOUNDS = {
    // Place Stuff
    onPlace: {
        string: "random.chestopen",
        optional: {},
    },

    // Pickup Stuff
    onPickup: {
        string: "random.chestclosed",
        optional: {},
    },
    onFailPickup: {
        string: "note.bass",
        optional: {},
    },
};
