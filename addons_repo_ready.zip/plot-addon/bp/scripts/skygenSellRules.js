import { world } from "@minecraft/server";

const SKYGEN_SELL_CATALOG_KEY = "msc:SkygenSellCatalog:v1";
const SKYGEN_OWNED_GEN_PREFIX = "msc:OwnedGenTypes:";

function loadOwnedGeneratorCounts(uid) {
  const raw = world.getDynamicProperty(`${SKYGEN_OWNED_GEN_PREFIX}${uid}`);
  if (!raw || typeof raw !== "string") return {};
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return {};
    return parsed;
  } catch {
    return {};
  }
}

export function loadSkygenSellCatalog() {
  const raw = world.getDynamicProperty(SKYGEN_SELL_CATALOG_KEY);
  if (!raw || typeof raw !== "string") return { version: 0, entries: [] };
  try {
    const parsed = JSON.parse(raw);
    return {
      version: Math.max(0, Math.floor(Number(parsed?.version) || 0)),
      entries: Array.isArray(parsed?.entries) ? parsed.entries.map((entry) => ({
        itemId: String(entry?.itemId ?? "").trim(),
        name: String(entry?.name ?? "").trim(),
        category: String(entry?.category ?? "Generator Drops").trim(),
        price: Math.max(0, Math.floor(Number(entry?.price) || 0)),
        alwaysAllowed: Boolean(entry?.alwaysAllowed),
        requiredGenerators: Array.isArray(entry?.requiredGenerators) ? entry.requiredGenerators.map((type) => String(type ?? "").trim()).filter(Boolean) : [],
        requiredRebirth: Math.max(0, Math.floor(Number(entry?.requiredRebirth) || 0))
      })).filter((entry) => entry.itemId.includes(":")) : []
    };
  } catch {
    return { version: 0, entries: [] };
  }
}

export function mergeSellablesWithSkygenCatalog(existingItems, catalogVersion) {
  const catalog = loadSkygenSellCatalog();
  if (catalog.entries.length === 0) {
    return {
      items: existingItems,
      skygenCatalogVersion: Math.max(0, Math.floor(Number(catalogVersion) || 0)),
      changed: false
    };
  }
  const existing = Array.isArray(existingItems) ? existingItems : [];
  const seen = new Set();
  const merged = [];
  let changed = false;
  const shouldRefreshKnownEntries = Math.max(0, Math.floor(Number(catalogVersion) || 0)) < catalog.version;
  const catalogMap = new Map(catalog.entries.map((entry) => [entry.itemId, entry]));
  for (const item of existing) {
    const catalogEntry = catalogMap.get(item.itemId);
    if (catalogEntry && shouldRefreshKnownEntries) {
      merged.push({
        ...item,
        name: catalogEntry.name || item.name,
        category: catalogEntry.category || item.category,
        price: catalogEntry.price > 0 ? catalogEntry.price : item.price
      });
      if (item.price !== catalogEntry.price || item.name !== catalogEntry.name || item.category !== catalogEntry.category) {
        changed = true;
      }
      seen.add(item.itemId);
      continue;
    }
    merged.push(item);
    seen.add(item.itemId);
  }
  for (const entry of catalog.entries) {
    if (seen.has(entry.itemId)) continue;
    merged.push({
      itemId: entry.itemId,
      name: entry.name,
      category: entry.category,
      price: entry.price
    });
    changed = true;
  }
  return {
    items: merged,
    skygenCatalogVersion: catalog.version,
    changed
  };
}

export function evaluateSkygenSellAccess(player, itemId) {
  const catalog = loadSkygenSellCatalog();
  const entry = catalog.entries.find((candidate) => candidate.itemId === itemId);
  if (!entry) return { allowed: true, reason: null, entry: null };
  const rawEconomy = world.getDynamicProperty(`plotshop_economy_data_v18:${player.id}`);
  let rebirths = 0;
  if (rawEconomy && typeof rawEconomy === "string") {
    try {
      rebirths = Math.max(0, Math.floor(Number(JSON.parse(rawEconomy)?.rebirths) || 0));
    } catch {
      rebirths = 0;
    }
  }
  if (rebirths < entry.requiredRebirth) {
    return { allowed: false, reason: "rebirth", entry, requiredRebirth: entry.requiredRebirth };
  }
  if (entry.alwaysAllowed || entry.requiredGenerators.length === 0) {
    return { allowed: true, reason: null, entry };
  }
  const uid = player.uid;
  if (!uid) {
    return { allowed: false, reason: "ownership", entry };
  }
  const owned = loadOwnedGeneratorCounts(uid);
  const ownsAny = entry.requiredGenerators.some((type) => Math.max(0, Math.floor(Number(owned[type]) || 0)) > 0);
  if (!ownsAny) {
    return { allowed: false, reason: "ownership", entry };
  }
  return { allowed: true, reason: null, entry };
}

export function summarizeBlockedSellCounts(blockedCounts) {
  const lines = [];
  for (const [itemId, details] of blockedCounts.entries()) {
    const label = itemId.split(":")[1] ?? itemId;
    if (details.reason === "rebirth") {
      lines.push(`${label} x${details.amount} because you need rebirth ${details.requiredRebirth}`);
      continue;
    }
    if (details.reason === "ownership") {
      lines.push(`${label} x${details.amount} because you do not own that generator yet`);
    }
  }
  return lines;
}
