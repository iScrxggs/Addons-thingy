// scripts/main.ts
import {
  system,
  world,
  Player,
  ItemStack,
  ItemLockMode,
  EquipmentSlot
} from "@minecraft/server";
import {
  ActionFormData,
  MessageFormData,
  ModalFormData
} from "@minecraft/server-ui";
import {
  mergeSellablesWithSkygenCatalog,
  evaluateSkygenSellAccess,
  summarizeBlockedSellCounts
} from "./skygenSellRules";
var PLOTS_KEY = "plotshop_plots";
var MONEY_OBJECTIVE_ID = "Money";
var LEGACY_MONEY_OBJECTIVE_ID = "money";
var SKYGEN_MULTIPLIER_OBJECTIVE_ID = "skygen_mul";
var PRESTIGE_OBJECTIVE_CANDIDATES = ["prestige", "Prestige"];
var PRESTIGE_FIRST_LEVEL = 1;
var PRESTIGE_TOTAL_LEVELS = 5;
var ECONOMY_MAX_REBIRTHS = 3;
var PRESTIGE_FIRST_RESET_TAG = "plotshop_prestige_first_reset";
var EXTERNAL_REBIRTH_TAG = "Rebirth";
var GENERATOR_REBIRTH_SYNC_TAG = "msc_rebirth_sync_pending";
var PLOT_MANAGER_ITEM_ID = "com_plotshop_star_td3uf2sh:my_sword";
var PLOT_ADMIN_TOOL_ITEM_ID = "com_plotshop_star_td3uf2sh:plot_admin_tool";
var PLOT_CONFIGURATOR_ITEM_ID = "com_plotshop_star_td3uf2sh:plot_configurator";
var CTOKEN_OBJECTIVE_ID = "CTokens";
var PLOT_MANAGER_SLOT = 0;
var PLOT_ADMIN_SLOT = 8;
var PLOT_WORLD_MIN_Y = -64;
var PLOT_WORLD_MAX_Y = 319;
var TOOL_CHECK_INTERVAL_TICKS = 100;
var MENU_USE_COOLDOWN_TICKS = 10;
var COMBAT_DURATION_TICKS = 100;
var TELEPORT_COOLDOWN_TICKS = 200;
var PAGE_SIZE = 6;
var BASE_MEMBER_LIMIT = 5;
var MAX_ACCESS_LOG_ENTRIES = 50;
var AUTO_RESET_INACTIVE_TICKS = 20 * 60 * 60 * 24 * 7;
var DELAYED_UNLOCK_TICKS = 60;
var BOUNDARY_CHECK_INTERVAL = 2;
var LOCKED_ENTRY_MESSAGE_COOLDOWN_TICKS = 30;
var SAFE_LOCATION_SEARCH_RADIUS = 5;
var SAFE_EJECT_SEARCH_DISTANCE = 4;
var PLOT_STATUS_VISUAL_INTERVAL = 18;
var PLOT_STATUS_VISUAL_RANGE = 36;
var LOCKED_PLOT_PARTICLE_SPACING = 5;
var UNLOCKED_PLOT_PARTICLE_SPACING = 8;
var LOCKED_PLOT_PARTICLE_HEIGHTS = [0.8, 2.6];
var UNLOCKED_PLOT_PARTICLE_HEIGHTS = [0.8];
var LOCKED_PLOT_PARTICLE = "minecraft:villager_angry";
var UNLOCKED_PLOT_PARTICLE = "minecraft:villager_happy";
var WELCOME_TAG = "plotshop_welcomed";
var PRESTIGE_CHECK_INTERVAL_TICKS = 20;
var PLOT_CLEAR_CHUNK_SIZE_X = 16;
var PLOT_CLEAR_CHUNK_SIZE_Y = 64;
var PLOT_CLEAR_CHUNK_SIZE_Z = 16;
var PLOT_RESET_PRESERVE_BLOCKS = ["minecraft:polished_deepslate", "minecraft:polished_deepslate_wall", "minecraft:soul_lantern", "minecraft:grass_block"];
var REBIRTH_SPAWN_LOCATION = { x: -95, y: -4, z: -93 };
var LOCKPICK_T1_ID = "com_plotshop_star_td3uf2sh:lockpick_t1";
var LOCKPICK_T2_ID = "com_plotshop_star_td3uf2sh:lockpick_t2";
var LOCKPICK_T3_ID = "com_plotshop_star_td3uf2sh:lockpick_t3";
var LOCKPICK_TIERS = [
  { itemId: LOCKPICK_T1_ID, tier: 1 },
  { itemId: LOCKPICK_T2_ID, tier: 2 },
  { itemId: LOCKPICK_T3_ID, tier: 3 }
];
var LOCKPICK_MOVEMENT_TOLERANCE = 1.5;
var LOCKPICK_CHECK_INTERVAL = 4;
var CONTAINER_SHIELD_DURATION_TICKS = 30 * 20;
var CONTAINER_SHIELD_UPGRADE_COST = 750;
var RAID_SETTINGS_KEY = "plotshop_raid_settings";
var RAID_COUNTER_WINDOW_TICKS = 24e3;
var DEFENSE_SETTINGS_KEY = "plotshop_defense_settings";
var DEFENSE_UPKEEP_KEY = "plotshop_defense_upkeep";
var DEFENSE_UPKEEP_CHECK_INTERVAL_TICKS = 20;
var PLOT_LAYOUT_VERSION_KEY = "plotshop_layout_version";
var CURRENT_PLOT_LAYOUT_VERSION = "17_side_a_b_c_d";
var PLAYER_SOUNDS_KEY = "plotshop_personal_sounds";
var PLAYER_VISUALS_KEY = "plotshop_personal_visuals";
var BORDER_BLOCK_KEYWORD = "border_block";
var PLOT_MANAGER_ITEM_SETTINGS_KEY = "plotshop_plot_manager_item_settings_v30";
var ECONOMY_SETTINGS_KEY = "plotshop_economy_settings_v25";
var ECONOMY_DATA_PREFIX = "plotshop_economy_data_v18:";
var ECONOMY_SELL_COOLDOWN_TICKS = 40;
var ECONOMY_PURCHASE_COOLDOWN_TICKS = 20;
var ECONOMY_MULTIPLIER_MIN_LEVEL = 0;
var ECONOMY_MULTIPLIER_MAX_LEVEL = 15;
var ECONOMY_MULTIPLIER_BASE = 1;
var ECONOMY_MULTIPLIER_STEP = 0.1;
var ECONOMY_REBIRTH_REQUIRED_MULTIPLIER_LEVEL = 15;
var ECONOMY_CATEGORY_ORDER = ["Generator Drops", "Ores", "Mob Drops", "Rare Items", "Event Items"];
var PLOT_CREATION_PRESETS = [
  { label: "17x14", width: 17, depth: 14 },
  { label: "6x6", width: 6, depth: 6 },
  { label: "Custom", width: null, depth: null }
];
var PLOT_ORIENTATION_OPTIONS = [
  { key: "north", label: "North (0deg)" },
  { key: "east", label: "East (90deg)" },
  { key: "south", label: "South (180deg)" },
  { key: "west", label: "West (270deg)" }
];
function createDefaultRaidSettings() {
  return {
    breachDurationSeconds: 90,
    pickTimesSeconds: [25, 18, 10],
    nightOnly: true,
    requireOwnerOnline: true,
    raidTimeRequirement: "night",
    ownerPresenceRequirement: "online",
    requirePlotLocked: true,
    baseSuccessRates: [40, 60, 80],
    failPenaltyMode: "both",
    tierScalingMode: "hybrid",
    tierSuccessBonus: 0,
    tierTimeReductionSeconds: 0,
    movementCancels: true,
    toolCosts: [1e5, 5e5, 2e6],
    costScalePercent: 0,
    repairEnabled: true,
    repairCostPercent: 40,
    useCTokensForTier2: false,
    useCTokensForTier3: false,
    ctokenCosts: [0, 0, 0],
    ctokenScalePercent: 0,
    playerCooldownSeconds: 30,
    plotCooldownMinutes: 15,
    globalCooldownSeconds: 0,
    entryMode: "all_players",
    allowContainerAccessDuringRaid: true,
    blockBreakingDuringRaid: false,
    keepCoreBlocksProtected: true,
    broadcastOnBreach: true,
    broadcastTemplate: "{plot} has been breached by {attacker}!",
    ownerAlertEnabled: true,
    ownerAlertTemplate: "{attacker} is raiding your plot {plot}!",
    afkDetection: false,
    afkIdleSeconds: 90,
    reRaidProtection: true,
    maxRaidsPerPlayer: 0
  };
}
function loadRaidSettings() {
  const raw = world.getDynamicProperty(RAID_SETTINGS_KEY);
  const defaults = createDefaultRaidSettings();
  if (!raw) return defaults;
  try {
    const parsed = JSON.parse(raw);
    return {
      ...defaults,
      ...parsed,
      raidTimeRequirement: parsed.raidTimeRequirement === "day" || parsed.raidTimeRequirement === "any" ? parsed.raidTimeRequirement : parsed.nightOnly === false ? "any" : defaults.raidTimeRequirement,
      ownerPresenceRequirement: parsed.ownerPresenceRequirement === "offline" || parsed.ownerPresenceRequirement === "any" ? parsed.ownerPresenceRequirement : parsed.requireOwnerOnline === false ? "any" : defaults.ownerPresenceRequirement,
      requirePlotLocked: Boolean(parsed.requirePlotLocked ?? defaults.requirePlotLocked),
      nightOnly: parsed.raidTimeRequirement === "night" || (parsed.raidTimeRequirement === void 0 ? Boolean(parsed.nightOnly ?? defaults.nightOnly) : false),
      requireOwnerOnline: parsed.ownerPresenceRequirement === "online" || (parsed.ownerPresenceRequirement === void 0 ? Boolean(parsed.requireOwnerOnline ?? defaults.requireOwnerOnline) : false),
      pickTimesSeconds: Array.isArray(parsed.pickTimesSeconds) && parsed.pickTimesSeconds.length === 3 ? [Number(parsed.pickTimesSeconds[0]), Number(parsed.pickTimesSeconds[1]), Number(parsed.pickTimesSeconds[2])] : defaults.pickTimesSeconds,
      baseSuccessRates: Array.isArray(parsed.baseSuccessRates) && parsed.baseSuccessRates.length === 3 ? [Number(parsed.baseSuccessRates[0]), Number(parsed.baseSuccessRates[1]), Number(parsed.baseSuccessRates[2])] : defaults.baseSuccessRates,
      toolCosts: Array.isArray(parsed.toolCosts) && parsed.toolCosts.length === 3 ? [Number(parsed.toolCosts[0]), Number(parsed.toolCosts[1]), Number(parsed.toolCosts[2])] : defaults.toolCosts,
      ctokenCosts: Array.isArray(parsed.ctokenCosts) && parsed.ctokenCosts.length === 3 ? [Number(parsed.ctokenCosts[0]), Number(parsed.ctokenCosts[1]), Number(parsed.ctokenCosts[2])] : defaults.ctokenCosts
    };
  } catch {
    return defaults;
  }
}
function saveRaidSettings(settings) {
  settings.nightOnly = settings.raidTimeRequirement === "night";
  settings.requireOwnerOnline = settings.ownerPresenceRequirement === "online";
  world.setDynamicProperty(RAID_SETTINGS_KEY, JSON.stringify(settings));
}
function getRaidDayTimeTicks() {
  const getTimeOfDay = world.getTimeOfDay;
  if (typeof getTimeOfDay === "function") {
    const value = Number(getTimeOfDay.call(world));
    if (Number.isFinite(value)) return (Math.floor(value) % 24e3 + 24e3) % 24e3;
  }
  return 0;
}
function isRaidNightTime() {
  const time = getRaidDayTimeTicks();
  return time >= 13e3 && time <= 23e3;
}
function isRaidDayTime() {
  return !isRaidNightTime();
}
function getRaidTimeRequirement(settings) {
  if (settings.raidTimeRequirement === "day" || settings.raidTimeRequirement === "any") return settings.raidTimeRequirement;
  return settings.nightOnly ? "night" : "any";
}
function getRaidOwnerPresenceRequirement(settings) {
  if (settings.ownerPresenceRequirement === "offline" || settings.ownerPresenceRequirement === "any") return settings.ownerPresenceRequirement;
  return settings.requireOwnerOnline ? "online" : "any";
}
function formatRaidTimeRequirement(settings) {
  const requirement = getRaidTimeRequirement(settings);
  if (requirement === "day") return "Day only";
  if (requirement === "night") return "Night only";
  return "Any time";
}
function formatRaidOwnerPresenceRequirement(settings) {
  const requirement = getRaidOwnerPresenceRequirement(settings);
  if (requirement === "online") return "Owner online";
  if (requirement === "offline") return "Owner offline";
  return "Owner online or offline";
}
function isPlotshopAdmin(player) {
  return player.hasTag("guiadmin") || player.hasTag("plotadmin") || player.hasTag("admin");
}
function queueFormOpen(player, openCallback) {
  system.run(() => openCallback(player));
}
function getPlotAtOrNearLocation(x, y, z, searchRadius = 2) {
  const plots = loadPlots();
  let nearest;
  let nearestDistance = Number.MAX_SAFE_INTEGER;
  for (const plot of plots) {
    const minX = Math.min(plot.x1, plot.x2) - searchRadius;
    const maxX = Math.max(plot.x1, plot.x2) + searchRadius;
    const minY = Math.min(plot.y1, plot.y2) - searchRadius;
    const maxY = Math.max(plot.y1, plot.y2) + searchRadius;
    const minZ = Math.min(plot.z1, plot.z2) - searchRadius;
    const maxZ = Math.max(plot.z1, plot.z2) + searchRadius;
    if (x < minX || x > maxX || y < minY || y > maxY || z < minZ || z > maxZ) continue;
    const centerX = (plot.x1 + plot.x2) / 2;
    const centerZ = (plot.z1 + plot.z2) / 2;
    const distance = Math.abs(centerX - x) + Math.abs(centerZ - z);
    if (distance < nearestDistance) {
      nearestDistance = distance;
      nearest = plot;
    }
  }
  return nearest;
}
function validateRaidAccessRule(player, plot, settings) {
  const timeRequirement = getRaidTimeRequirement(settings);
  if (timeRequirement === "night" && !isRaidNightTime()) return "\xA7cRaids are currently night-only.";
  if (timeRequirement === "day" && !isRaidDayTime()) return "\xA7cRaids are currently day-only.";
  const ownerPresenceRequirement = getRaidOwnerPresenceRequirement(settings);
  const ownerOnline = plot.ownerId ? world.getAllPlayers().some((onlinePlayer) => onlinePlayer.id === plot.ownerId) : false;
  if (ownerPresenceRequirement === "online" && !ownerOnline) return "\xA7cThe plot owner must be online to raid this plot.";
  if (ownerPresenceRequirement === "offline" && ownerOnline) return "\xA7cThe plot owner must be offline to raid this plot.";
  if (settings.requirePlotLocked && !plot.locked) return "\xA7cThe owner's plot lock must be enabled before this plot can be raided.";
  if (plot.ownerId === player.id) return "\xA7cYou cannot raid your own plot.";
  return null;
}
function applyAdminEditCooldown(player) {
  const lastEdit = economyAdminEditCooldowns.get(player.id) ?? 0;
  if (system.currentTick - lastEdit < 10) {
    player.sendMessage("\xA7cPlease wait a moment before editing another PlotShop setting.");
    return false;
  }
  economyAdminEditCooldowns.set(player.id, system.currentTick);
  return true;
}
function createDefaultPlotManagerItemSettings() {
  return {
    autoGiveEnabled: true,
    preferredSlot: PLOT_MANAGER_SLOT,
    lockToSlot: true,
    replaceMissingOnly: true,
    giveOnConfigSave: true
  };
}
function loadPlotManagerItemSettings() {
  const defaults = createDefaultPlotManagerItemSettings();
  const raw = world.getDynamicProperty(PLOT_MANAGER_ITEM_SETTINGS_KEY);
  if (!raw) return defaults;
  try {
    const parsed = JSON.parse(raw);
    return {
      ...defaults,
      ...parsed,
      preferredSlot: clampNumber(Math.floor(Number(parsed.preferredSlot ?? defaults.preferredSlot)), 0, 8),
      autoGiveEnabled: Boolean(parsed.autoGiveEnabled ?? defaults.autoGiveEnabled),
      lockToSlot: Boolean(parsed.lockToSlot ?? defaults.lockToSlot),
      replaceMissingOnly: Boolean(parsed.replaceMissingOnly ?? defaults.replaceMissingOnly),
      giveOnConfigSave: Boolean(parsed.giveOnConfigSave ?? defaults.giveOnConfigSave)
    };
  } catch {
    return defaults;
  }
}
function savePlotManagerItemSettings(settings) {
  world.setDynamicProperty(PLOT_MANAGER_ITEM_SETTINGS_KEY, JSON.stringify({
    ...settings,
    preferredSlot: clampNumber(Math.floor(settings.preferredSlot), 0, 8)
  }));
}
function createPlotManagerItemStack(settings = loadPlotManagerItemSettings()) {
  const stack = new ItemStack(PLOT_MANAGER_ITEM_ID, 1);
  if (settings.lockToSlot) {
    stack.lockMode = ItemLockMode.slot;
  }
  return stack;
}
function getPlayerInventoryContainer(player) {
  return player.getComponent("minecraft:inventory")?.container;
}
function findPlotManagerItemSlot(player) {
  const container = getPlayerInventoryContainer(player);
  if (!container) return -1;
  for (let slot = 0; slot < container.size; slot++) {
    const stack = container.getItem(slot);
    if (stack?.typeId === PLOT_MANAGER_ITEM_ID) return slot;
  }
  return -1;
}
function giveConfiguredPlotManagerItem(player, forceRefresh) {
  const settings = loadPlotManagerItemSettings();
  if (!forceRefresh && !settings.autoGiveEnabled) return false;
  const container = getPlayerInventoryContainer(player);
  if (!container) return false;
  const preferredSlot = clampNumber(Math.floor(settings.preferredSlot), 0, Math.min(8, container.size - 1));
  const existingSlot = findPlotManagerItemSlot(player);
  if (existingSlot >= 0 && settings.replaceMissingOnly && !forceRefresh) return false;
  if (existingSlot >= 0 && existingSlot !== preferredSlot) container.setItem(existingSlot, void 0);
  container.setItem(preferredSlot, createPlotManagerItemStack(settings));
  return true;
}
function giveConfiguredPlotManagerToAllPlayers(forceRefresh) {
  let changed = 0;
  for (const onlinePlayer of world.getPlayers()) {
    if (giveConfiguredPlotManagerItem(onlinePlayer, forceRefresh)) changed++;
  }
  return changed;
}
function openPlotManagerItemConfigMenu(player) {
  if (!isPlotshopAdmin(player)) {
    player.sendMessage("\xA7cYou need the guiadmin or plotadmin tag to configure the Plot Manager item.");
    return;
  }
  const settings = loadPlotManagerItemSettings();
  const form = new ActionFormData().title("Plot Manager Item Config").body([
    "\xA77Configure how players receive the main \xA7aPlot Manager\xA77 item.",
    `\xA7eAuto-give: \xA7f${settings.autoGiveEnabled ? "On" : "Off"}`,
    `\xA7ePreferred hotbar slot: \xA7f${settings.preferredSlot + 1}`,
    `\xA7eSlot lock: \xA7f${settings.lockToSlot ? "On" : "Off"}`,
    `\xA7eReplace only when missing: \xA7f${settings.replaceMissingOnly ? "Yes" : "No"}`
  ].join("\n")).button("\u2699 Edit Item Settings").button("\u2B50 Give/Refresh My Plot Manager").button("\u2B50 Give/Refresh Online Players").button("\u21BB Reset To Defaults").button("Back");
  form.show(player).then((response) => {
    if (response.canceled) return queueFormOpen(player, openPlotshopAdminQuickConfig);
    if (response.selection === 0) queueFormOpen(player, openPlotManagerItemSettingsForm);
    else if (response.selection === 1) {
      giveConfiguredPlotManagerItem(player, true);
      player.sendMessage("\xA7aYour Plot Manager item was refreshed.");
      system.run(() => openPlotManagerItemConfigMenu(player));
    } else if (response.selection === 2) {
      const count = giveConfiguredPlotManagerToAllPlayers(true);
      player.sendMessage(`\xA7aRefreshed Plot Manager items for ${count} online player(s).`);
      system.run(() => openPlotManagerItemConfigMenu(player));
    } else if (response.selection === 3) {
      if (!applyAdminEditCooldown(player)) return;
      savePlotManagerItemSettings(createDefaultPlotManagerItemSettings());
      giveConfiguredPlotManagerToAllPlayers(true);
      player.sendMessage("\xA7aPlot Manager item settings were reset.");
      system.run(() => openPlotManagerItemConfigMenu(player));
    } else {
      queueFormOpen(player, openPlotshopAdminQuickConfig);
    }
  }).catch(() => void 0);
}
function openPlotManagerItemSettingsForm(player) {
  const settings = loadPlotManagerItemSettings();
  const form = new ModalFormData().title("Configure Plot Manager Item").toggle("Auto-give Plot Manager to players", { defaultValue: settings.autoGiveEnabled }).textField("Preferred hotbar slot", "1-9", { defaultValue: String(settings.preferredSlot + 1) }).toggle("Lock Plot Manager to that slot", { defaultValue: settings.lockToSlot }).toggle("Only replace item when missing", { defaultValue: settings.replaceMissingOnly }).toggle("Refresh online players after saving", { defaultValue: settings.giveOnConfigSave });
  form.show(player).then((response) => {
    if (response.canceled || !response.formValues) return queueFormOpen(player, openPlotManagerItemConfigMenu);
    if (!applyAdminEditCooldown(player)) return;
    const values = response.formValues;
    const preferredSlot = clampNumber(Math.floor(Number(values[1]) || 1) - 1, 0, 8);
    const nextSettings = {
      autoGiveEnabled: Boolean(values[0]),
      preferredSlot,
      lockToSlot: Boolean(values[2]),
      replaceMissingOnly: Boolean(values[3]),
      giveOnConfigSave: Boolean(values[4])
    };
    savePlotManagerItemSettings(nextSettings);
    if (nextSettings.giveOnConfigSave) giveConfiguredPlotManagerToAllPlayers(true);
    player.sendMessage("\xA7aPlot Manager item settings updated.");
    system.run(() => openPlotManagerItemConfigMenu(player));
  }).catch(() => void 0);
}
function openPlotshopAdminQuickConfig(player) {
  if (!isPlotshopAdmin(player)) {
    player.sendMessage("\xA7cYou need the guiadmin or plotadmin tag to use PlotShop admin settings.");
    return;
  }
  const raidSettings = loadRaidSettings();
  const economySettings = loadEconomySettings();
  const defenseSettings = loadDefenseSettings();
  const form = new ActionFormData().title("Admin: PlotShop GUI").body([
    "\xA77Quick access to configurable values that may be missing from older admin pages.",
    "\xA7bUse the new PlotShop Configurator item to open this menu directly from Creative.",
    `\xA7eRaid owner rule: \xA7f${formatRaidOwnerPresenceRequirement(raidSettings)}`,
    `\xA7eRaid time rule: \xA7f${formatRaidTimeRequirement(raidSettings)}`,
    `\xA7eRequires locked plot: \xA7f${raidSettings.requirePlotLocked ? "Yes" : "No"}`,
    `\xA7aSell tax: \xA7f${economySettings.sellTaxPercent}% \xA77| \xA7aBoost: \xA7f${economySettings.economyBoostEnabled ? "On" : "Off"}`,
    `\xA7bUpkeep: \xA7f${defenseSettings.upkeepPercentOfBalance}% every ${Math.max(1, Math.ceil(defenseSettings.upkeepChargeIntervalTicks / 20))}s`
  ].join("\n")).button("\u2694 Raid Settings").button("\u{1F4B0} Economy Variables").button("\u{1F6E1} Defense / Upkeep Variables").button("\u2B50 Plot Manager Item").button("\u21BB Reset Raid Settings").button("Close");
  form.show(player).then((response) => {
    if (response.canceled) return;
    if (response.selection === 0) queueFormOpen(player, openRaidAccessSettingsForm);
    else if (response.selection === 1) queueFormOpen(player, openEconomyVariablesForm);
    else if (response.selection === 2) queueFormOpen(player, openDefenseVariablesForm);
    else if (response.selection === 3) queueFormOpen(player, openPlotManagerItemConfigMenu);
    else if (response.selection === 4) {
      if (!applyAdminEditCooldown(player)) return;
      saveRaidSettings(createDefaultRaidSettings());
      player.sendMessage("\xA7aRaid settings were reset to defaults.");
      system.run(() => openPlotshopAdminQuickConfig(player));
    }
  }).catch(() => void 0);
}
function openPlotAdminToolHome(player) {
  if (!isPlotshopAdmin(player)) {
    player.sendMessage("\xA7cYou need the guiadmin or plotadmin tag to use the Plot Admin Tool.");
    return;
  }
  const canManagePlots = isAdmin(player);
  const form = new ActionFormData().title("Plot Admin Tool").body(canManagePlots ? "\xA77Choose regular plot management or the configurable Admin: PlotShop GUI settings." : "\xA77Choose the configurable Admin: PlotShop GUI settings. Plot Management appears when you have the plotadmin tag.");
  const actions = [];
  if (canManagePlots) {
    form.button("\u{1F3E0} Plot Management");
    actions.push(openAdminMenu);
  }
  form.button("\u2699 Admin Configuration");
  actions.push(openPlotshopAdminQuickConfig);
  form.button("\u2694 Raid Settings");
  actions.push(openRaidAccessSettingsForm);
  form.button("Close");
  form.show(player).then((response) => {
    if (response.canceled) return;
    const action = response.selection === void 0 ? void 0 : actions[response.selection];
    if (action) queueFormOpen(player, action);
  }).catch(() => void 0);
}
function openRaidAccessSettingsForm(player) {
  const settings = loadRaidSettings();
  const form = new ActionFormData().title("Raid Settings").body([
    "\xA77Configure every raid variable from the Plot Admin / PlotShop admin tools.",
    `\xA7eOwner presence: \xA7f${formatRaidOwnerPresenceRequirement(settings)}`,
    `\xA7eTime rule: \xA7f${formatRaidTimeRequirement(settings)}`,
    `\xA7eOwner lock required: \xA7f${settings.requirePlotLocked ? "Yes" : "No"}`,
    `\xA7bBreach window: \xA7f${settings.breachDurationSeconds}s`,
    `\xA7bLockpick times: \xA7fT1 ${settings.pickTimesSeconds[0]}s / T2 ${settings.pickTimesSeconds[1]}s / T3 ${settings.pickTimesSeconds[2]}s`,
    `\xA7aSuccess: \xA7fT1 ${settings.baseSuccessRates[0]}% / T2 ${settings.baseSuccessRates[1]}% / T3 ${settings.baseSuccessRates[2]}%`
  ].join("\n")).button("\u2694 Access Rules").button("\u23F1 Timers & Cooldowns").button("\u{1F3B2} Success, Scaling & Costs").button("\u{1F6E1} Raid Behavior / Protection").button("\u{1F4E3} Alerts & Limits").button("Back");
  form.show(player).then((response) => {
    if (response.canceled) return queueFormOpen(player, openPlotshopAdminQuickConfig);
    if (response.selection === 0) queueFormOpen(player, openRaidAccessRulesForm);
    else if (response.selection === 1) queueFormOpen(player, openRaidTimingSettingsForm);
    else if (response.selection === 2) queueFormOpen(player, openRaidSuccessAndCostSettingsForm);
    else if (response.selection === 3) queueFormOpen(player, openRaidBehaviorSettingsForm);
    else if (response.selection === 4) queueFormOpen(player, openRaidAlertLimitSettingsForm);
    else queueFormOpen(player, openPlotshopAdminQuickConfig);
  }).catch(() => void 0);
}
function openRaidAccessRulesForm(player) {
  const settings = loadRaidSettings();
  const timeRequirement = getRaidTimeRequirement(settings);
  const ownerPresenceRequirement = getRaidOwnerPresenceRequirement(settings);
  const timeOptions = ["any", "day", "night"];
  const ownerOptions = ["any", "online", "offline"];
  const form = new ModalFormData().title("Raid Settings").dropdown("When can raids start?", ["Any time", "Day only", "Night only"], { defaultValueIndex: Math.max(0, timeOptions.indexOf(timeRequirement)) }).dropdown("Owner presence required", ["Online or offline", "Owner online", "Owner offline"], { defaultValueIndex: Math.max(0, ownerOptions.indexOf(ownerPresenceRequirement)) }).toggle("Require owner's plot lock to be ON", { defaultValue: settings.requirePlotLocked }).toggle("Movement cancels lockpicking", { defaultValue: settings.movementCancels }).toggle("Allow container access during breach", { defaultValue: settings.allowContainerAccessDuringRaid }).toggle("Allow block breaking during breach", { defaultValue: settings.blockBreakingDuringRaid }).toggle("Keep core/border blocks protected", { defaultValue: settings.keepCoreBlocksProtected }).toggle("Broadcast successful breaches", { defaultValue: settings.broadcastOnBreach }).toggle("Alert owner when raid starts", { defaultValue: settings.ownerAlertEnabled }).textField("Breach window seconds", "60-120 recommended", { defaultValue: String(settings.breachDurationSeconds) }).textField("Player cooldown seconds", "Example: 30", { defaultValue: String(settings.playerCooldownSeconds) }).textField("Plot cooldown minutes", "Example: 15", { defaultValue: String(settings.plotCooldownMinutes) }).textField("Global cooldown seconds", "0 disables", { defaultValue: String(settings.globalCooldownSeconds) }).textField("Max raids per player per day", "0 disables", { defaultValue: String(settings.maxRaidsPerPlayer) });
  form.show(player).then((response) => {
    if (response.canceled || !response.formValues) return queueFormOpen(player, openPlotshopAdminQuickConfig);
    if (!applyAdminEditCooldown(player)) return;
    const values = response.formValues;
    const nextTimeRequirement = timeOptions[Number(values[0]) || 0] ?? "any";
    const nextOwnerRequirement = ownerOptions[Number(values[1]) || 0] ?? "any";
    const nextSettings = {
      ...settings,
      raidTimeRequirement: nextTimeRequirement,
      ownerPresenceRequirement: nextOwnerRequirement,
      requirePlotLocked: Boolean(values[2]),
      movementCancels: Boolean(values[3]),
      allowContainerAccessDuringRaid: Boolean(values[4]),
      blockBreakingDuringRaid: Boolean(values[5]),
      keepCoreBlocksProtected: Boolean(values[6]),
      broadcastOnBreach: Boolean(values[7]),
      ownerAlertEnabled: Boolean(values[8]),
      breachDurationSeconds: clampNumber(Math.floor(Number(values[9]) || settings.breachDurationSeconds), 10, 600),
      playerCooldownSeconds: clampNumber(Math.floor(Number(values[10]) || 0), 0, 86400),
      plotCooldownMinutes: clampNumber(Math.floor(Number(values[11]) || 0), 0, 1440),
      globalCooldownSeconds: clampNumber(Math.floor(Number(values[12]) || 0), 0, 86400),
      maxRaidsPerPlayer: clampNumber(Math.floor(Number(values[13]) || 0), 0, 1e3)
    };
    saveRaidSettings(nextSettings);
    player.sendMessage("\xA7aRaid Settings updated.");
    system.run(() => openPlotshopAdminQuickConfig(player));
  }).catch(() => void 0);
}
function openRaidTimingSettingsForm(player) {
  const settings = loadRaidSettings();
  const form = new ModalFormData().title("Raid Timers & Cooldowns").textField("Breach window seconds", "60-120 recommended", { defaultValue: String(settings.breachDurationSeconds) }).textField("Tier 1 lockpick time seconds", "Example: 25", { defaultValue: String(settings.pickTimesSeconds[0]) }).textField("Tier 2 lockpick time seconds", "Example: 18", { defaultValue: String(settings.pickTimesSeconds[1]) }).textField("Tier 3 lockpick time seconds", "Example: 10", { defaultValue: String(settings.pickTimesSeconds[2]) }).textField("Tier time reduction seconds", "0 disables", { defaultValue: String(settings.tierTimeReductionSeconds) }).textField("Player cooldown seconds", "Example: 30", { defaultValue: String(settings.playerCooldownSeconds) }).textField("Plot cooldown minutes", "Example: 15", { defaultValue: String(settings.plotCooldownMinutes) }).textField("Global cooldown seconds", "0 disables", { defaultValue: String(settings.globalCooldownSeconds) }).textField("Max raids per player per day", "0 disables", { defaultValue: String(settings.maxRaidsPerPlayer) });
  form.show(player).then((response) => {
    if (response.canceled || !response.formValues) return queueFormOpen(player, openRaidAccessSettingsForm);
    if (!applyAdminEditCooldown(player)) return;
    const values = response.formValues;
    saveRaidSettings({
      ...settings,
      breachDurationSeconds: clampNumber(Math.floor(Number(values[0]) || settings.breachDurationSeconds), 10, 600),
      pickTimesSeconds: [
        clampNumber(Math.floor(Number(values[1]) || settings.pickTimesSeconds[0]), 1, 300),
        clampNumber(Math.floor(Number(values[2]) || settings.pickTimesSeconds[1]), 1, 300),
        clampNumber(Math.floor(Number(values[3]) || settings.pickTimesSeconds[2]), 1, 300)
      ],
      tierTimeReductionSeconds: clampNumber(Math.floor(Number(values[4]) || 0), 0, 120),
      playerCooldownSeconds: clampNumber(Math.floor(Number(values[5]) || 0), 0, 86400),
      plotCooldownMinutes: clampNumber(Math.floor(Number(values[6]) || 0), 0, 1440),
      globalCooldownSeconds: clampNumber(Math.floor(Number(values[7]) || 0), 0, 86400),
      maxRaidsPerPlayer: clampNumber(Math.floor(Number(values[8]) || 0), 0, 1e3)
    });
    player.sendMessage("\xA7aRaid timers and cooldowns updated.");
    system.run(() => openRaidAccessSettingsForm(player));
  }).catch(() => void 0);
}
function openRaidSuccessAndCostSettingsForm(player) {
  const settings = loadRaidSettings();
  const scalingOptions = ["success", "time", "hybrid"];
  const entryOptions = ["all_players", "attacker_only"];
  const form = new ModalFormData().title("Raid Success & Costs").textField("Tier 1 success percent", "0-100", { defaultValue: String(settings.baseSuccessRates[0]) }).textField("Tier 2 success percent", "0-100", { defaultValue: String(settings.baseSuccessRates[1]) }).textField("Tier 3 success percent", "0-100", { defaultValue: String(settings.baseSuccessRates[2]) }).dropdown("Tier scaling mode", ["Success bonus only", "Faster time only", "Hybrid"], { defaultValueIndex: Math.max(0, scalingOptions.indexOf(settings.tierScalingMode)) }).textField("Tier success bonus percent", "0+", { defaultValue: String(settings.tierSuccessBonus) }).textField("Money cost T1", "Money", { defaultValue: String(settings.toolCosts[0]) }).textField("Money cost T2", "Money", { defaultValue: String(settings.toolCosts[1]) }).textField("Money cost T3", "Money", { defaultValue: String(settings.toolCosts[2]) }).textField("Cost scale percent", "0 disables", { defaultValue: String(settings.costScalePercent) }).toggle("Use CTokens for Tier 2", { defaultValue: settings.useCTokensForTier2 }).toggle("Use CTokens for Tier 3", { defaultValue: settings.useCTokensForTier3 }).textField("CToken cost T2", "0+", { defaultValue: String(settings.ctokenCosts[1]) }).textField("CToken cost T3", "0+", { defaultValue: String(settings.ctokenCosts[2]) }).dropdown("Who may enter during breach?", ["All players", "Attacker only"], { defaultValueIndex: Math.max(0, entryOptions.indexOf(settings.entryMode)) });
  form.show(player).then((response) => {
    if (response.canceled || !response.formValues) return queueFormOpen(player, openRaidAccessSettingsForm);
    if (!applyAdminEditCooldown(player)) return;
    const values = response.formValues;
    saveRaidSettings({
      ...settings,
      baseSuccessRates: [
        clampNumber(Math.floor(Number(values[0]) || 0), 0, 100),
        clampNumber(Math.floor(Number(values[1]) || 0), 0, 100),
        clampNumber(Math.floor(Number(values[2]) || 0), 0, 100)
      ],
      tierScalingMode: scalingOptions[Number(values[3]) || 0] ?? "hybrid",
      tierSuccessBonus: clampNumber(Math.floor(Number(values[4]) || 0), 0, 100),
      toolCosts: [
        Math.max(0, Math.floor(Number(values[5]) || 0)),
        Math.max(0, Math.floor(Number(values[6]) || 0)),
        Math.max(0, Math.floor(Number(values[7]) || 0))
      ],
      costScalePercent: Math.max(0, Math.floor(Number(values[8]) || 0)),
      useCTokensForTier2: Boolean(values[9]),
      useCTokensForTier3: Boolean(values[10]),
      ctokenCosts: [
        settings.ctokenCosts[0],
        Math.max(0, Math.floor(Number(values[11]) || 0)),
        Math.max(0, Math.floor(Number(values[12]) || 0))
      ],
      entryMode: entryOptions[Number(values[13]) || 0] ?? "all_players"
    });
    player.sendMessage("\xA7aRaid success rates and costs updated.");
    system.run(() => openRaidAccessSettingsForm(player));
  }).catch(() => void 0);
}
function openRaidBehaviorSettingsForm(player) {
  const settings = loadRaidSettings();
  const penaltyOptions = ["break_item", "cooldown", "both"];
  const form = new ModalFormData().title("Raid Behavior / Protection").toggle("Movement cancels lockpicking", { defaultValue: settings.movementCancels }).toggle("Allow container access during breach", { defaultValue: settings.allowContainerAccessDuringRaid }).toggle("Allow block breaking during breach", { defaultValue: settings.blockBreakingDuringRaid }).toggle("Keep core/border blocks protected", { defaultValue: settings.keepCoreBlocksProtected }).dropdown("Failed lockpick penalty", ["Break item", "Cooldown only", "Break item + cooldown"], { defaultValueIndex: Math.max(0, penaltyOptions.indexOf(settings.failPenaltyMode)) }).toggle("Repair failed lockpicks enabled", { defaultValue: settings.repairEnabled }).textField("Repair cost percent", "0-100", { defaultValue: String(settings.repairCostPercent) });
  form.show(player).then((response) => {
    if (response.canceled || !response.formValues) return queueFormOpen(player, openRaidAccessSettingsForm);
    if (!applyAdminEditCooldown(player)) return;
    const values = response.formValues;
    saveRaidSettings({
      ...settings,
      movementCancels: Boolean(values[0]),
      allowContainerAccessDuringRaid: Boolean(values[1]),
      blockBreakingDuringRaid: Boolean(values[2]),
      keepCoreBlocksProtected: Boolean(values[3]),
      failPenaltyMode: penaltyOptions[Number(values[4]) || 0] ?? "both",
      repairEnabled: Boolean(values[5]),
      repairCostPercent: clampNumber(Math.floor(Number(values[6]) || 0), 0, 100)
    });
    player.sendMessage("\xA7aRaid behavior settings updated.");
    system.run(() => openRaidAccessSettingsForm(player));
  }).catch(() => void 0);
}
function openRaidAlertLimitSettingsForm(player) {
  const settings = loadRaidSettings();
  const form = new ModalFormData().title("Raid Alerts & Limits").toggle("Broadcast successful breaches", { defaultValue: settings.broadcastOnBreach }).toggle("Alert owner when raid starts", { defaultValue: settings.ownerAlertEnabled }).textField("Broadcast message", "Use {plot} and {attacker}", { defaultValue: settings.broadcastTemplate }).textField("Owner alert message", "Use {plot} and {attacker}", { defaultValue: settings.ownerAlertTemplate }).toggle("AFK detection enabled", { defaultValue: settings.afkDetection }).textField("AFK idle seconds", "Example: 90", { defaultValue: String(settings.afkIdleSeconds) }).toggle("Re-raid protection enabled", { defaultValue: settings.reRaidProtection }).textField("Max raids per player per day", "0 disables", { defaultValue: String(settings.maxRaidsPerPlayer) });
  form.show(player).then((response) => {
    if (response.canceled || !response.formValues) return queueFormOpen(player, openRaidAccessSettingsForm);
    if (!applyAdminEditCooldown(player)) return;
    const values = response.formValues;
    saveRaidSettings({
      ...settings,
      broadcastOnBreach: Boolean(values[0]),
      ownerAlertEnabled: Boolean(values[1]),
      broadcastTemplate: String(values[2] ?? settings.broadcastTemplate).slice(0, 160),
      ownerAlertTemplate: String(values[3] ?? settings.ownerAlertTemplate).slice(0, 160),
      afkDetection: Boolean(values[4]),
      afkIdleSeconds: clampNumber(Math.floor(Number(values[5]) || 0), 0, 3600),
      reRaidProtection: Boolean(values[6]),
      maxRaidsPerPlayer: clampNumber(Math.floor(Number(values[7]) || 0), 0, 1e3)
    });
    player.sendMessage("\xA7aRaid alert and limit settings updated.");
    system.run(() => openRaidAccessSettingsForm(player));
  }).catch(() => void 0);
}
function openEconomyVariablesForm(player) {
  const settings = loadEconomySettings();
  const form = new ModalFormData().title("Economy Variables").textField("Global sell multiplier", "Example: 1", { defaultValue: String(settings.sellGlobalMultiplier) }).textField("Sell tax percent", "0-100", { defaultValue: String(settings.sellTaxPercent) }).textField("Auction tax percent", "0-100", { defaultValue: String(settings.auctionTaxPercent) }).textField("Raid entry cost", "Money", { defaultValue: String(settings.raidEntryCost) }).textField("Plot upkeep cost", "Money", { defaultValue: String(settings.plotUpkeepCost) }).textField("Minimum sell price cap", "0+", { defaultValue: String(settings.minPriceCap) }).textField("Maximum sell price cap", "0+", { defaultValue: String(settings.maxPriceCap) }).toggle("Economy boost enabled", { defaultValue: settings.economyBoostEnabled }).textField("Economy boost multiplier", "Example: 1.25", { defaultValue: String(settings.economyBoostMultiplier) }).textField("Multiplier max level", `1-${ECONOMY_MULTIPLIER_MAX_LEVEL}`, { defaultValue: String(settings.multiplierMaxLevel) }).textField("Multiplier increment", "Example: 0.1", { defaultValue: String(settings.multiplierIncrement) }).dropdown("Multiplier scaling mode", ["Fixed values", "Percentage growth"], { defaultValueIndex: settings.multiplierScalingMode === "percentage" ? 1 : 0 }).textField("Multiplier growth percent", "Used for percentage mode", { defaultValue: String(settings.multiplierGrowthPercent) }).textField("Rebirth money required", "Money", { defaultValue: String(settings.rebirthMoneyRequired) }).toggle("Rebirth requires plot", { defaultValue: settings.rebirthRequiresPlot }).textField("Rebirth bonus per level", "Example: 0.2", { defaultValue: String(settings.rebirthBonusPerLevel) }).dropdown("Rebirth money behavior", ["Reset to zero", "Reduce by percent"], { defaultValueIndex: settings.rebirthMoneyMode === "reduce" ? 1 : 0 }).textField("Rebirth reduction percent", "0-100", { defaultValue: String(settings.rebirthMoneyReductionPercent) }).toggle("Plot buy prices enabled", { defaultValue: settings.plotBuyPricesEnabled }).textField("Plot reset cost", "Money", { defaultValue: String(settings.plotResetCost) });
  form.show(player).then((response) => {
    if (response.canceled || !response.formValues) return queueFormOpen(player, openPlotshopAdminQuickConfig);
    if (!applyAdminEditCooldown(player)) return;
    const values = response.formValues;
    const minCap = Math.max(0, Math.floor(Number(values[5]) || 0));
    const maxCap = Math.max(minCap, Math.floor(Number(values[6]) || settings.maxPriceCap));
    saveEconomySettings({
      ...settings,
      sellGlobalMultiplier: Math.max(0, Number(values[0]) || 0),
      sellTaxPercent: clampNumber(Number(values[1]) || 0, 0, 100),
      auctionTaxPercent: clampNumber(Number(values[2]) || 0, 0, 100),
      raidEntryCost: Math.max(0, Math.floor(Number(values[3]) || 0)),
      plotUpkeepCost: Math.max(0, Math.floor(Number(values[4]) || 0)),
      minPriceCap: minCap,
      maxPriceCap: maxCap,
      economyBoostEnabled: Boolean(values[7]),
      economyBoostMultiplier: Math.max(0, Number(values[8]) || 1),
      multiplierMaxLevel: clampNumber(Math.floor(Number(values[9]) || settings.multiplierMaxLevel), 1, ECONOMY_MULTIPLIER_MAX_LEVEL),
      multiplierIncrement: Math.max(0.01, Number(values[10]) || settings.multiplierIncrement),
      multiplierScalingMode: Number(values[11]) === 1 ? "percentage" : "fixed",
      multiplierGrowthPercent: clampNumber(Number(values[12]) || 0, 0, 1e3),
      rebirthMoneyRequired: Math.max(0, Math.floor(Number(values[13]) || 0)),
      rebirthRequiresPlot: Boolean(values[14]),
      rebirthBonusPerLevel: Math.max(0, Number(values[15]) || 0),
      rebirthMoneyMode: Number(values[16]) === 1 ? "reduce" : "reset",
      rebirthMoneyReductionPercent: clampNumber(Number(values[17]) || 0, 0, 100),
      plotBuyPricesEnabled: Boolean(values[18]),
      plotResetCost: Math.max(0, Math.floor(Number(values[19]) || 0))
    });
    player.sendMessage("\xA7aEconomy variables updated.");
    system.run(() => openPlotshopAdminQuickConfig(player));
  }).catch(() => void 0);
}
function openDefenseVariablesForm(player) {
  const settings = loadDefenseSettings();
  const form = new ModalFormData().title("Defense / Upkeep Variables").textField("Upkeep percent of balance", "0-100", { defaultValue: String(settings.upkeepPercentOfBalance) }).textField("Upkeep daily cap", "Money", { defaultValue: String(settings.upkeepDailyCap) }).toggle("Upkeep cap enabled", { defaultValue: settings.upkeepCapEnabled }).textField("Upkeep charge interval ticks", "24000 = about one day", { defaultValue: String(settings.upkeepChargeIntervalTicks) }).textField("Max tier-3 upgrade types", "0-3", { defaultValue: String(settings.maxTier3UpgradeTypes) }).textField("Extra plot cost scale percent", "0+", { defaultValue: String(settings.extraPlotCostScalePercent) }).toggle("Alarm pulses on lockpick start", { defaultValue: settings.alarmPulseOnLockpickStart }).toggle("Alarm pulses on tier-3 breach", { defaultValue: settings.alarmPulseOnTier3Breach }).textField("Tier-3 breach pulse seconds", "Example: 5", { defaultValue: String(settings.alarmTier3BreachPulseSeconds) });
  form.show(player).then((response) => {
    if (response.canceled || !response.formValues) return queueFormOpen(player, openPlotshopAdminQuickConfig);
    if (!applyAdminEditCooldown(player)) return;
    const values = response.formValues;
    saveDefenseSettings({
      ...settings,
      upkeepPercentOfBalance: clampNumber(Number(values[0]) || 0, 0, 100),
      upkeepDailyCap: Math.max(0, Math.floor(Number(values[1]) || 0)),
      upkeepCapEnabled: Boolean(values[2]),
      upkeepChargeIntervalTicks: Math.max(20, Math.floor(Number(values[3]) || settings.upkeepChargeIntervalTicks)),
      maxTier3UpgradeTypes: clampNumber(Math.floor(Number(values[4]) || 0), 0, 3),
      extraPlotCostScalePercent: Math.max(0, Number(values[5]) || 0),
      alarmPulseOnLockpickStart: Boolean(values[6]),
      alarmPulseOnTier3Breach: Boolean(values[7]),
      alarmTier3BreachPulseSeconds: clampNumber(Number(values[8]) || 0, 0, 60)
    });
    player.sendMessage("\xA7aDefense/upkeep variables updated.");
    system.run(() => openPlotshopAdminQuickConfig(player));
  }).catch(() => void 0);
}
world.beforeEvents.itemUse.subscribe((event) => {
  const itemStack = event.itemStack;
  const player = event.source;
  if (!itemStack || !(player instanceof Player)) return;
  if (!LOCKPICK_TIERS.some((config) => config.itemId === itemStack.typeId)) return;
  const location = player.location;
  const plot = getPlotAtOrNearLocation(location.x, location.y, location.z, 3);
  if (!plot || !plot.ownerId) return;
  const failureMessage = validateRaidAccessRule(player, plot, loadRaidSettings());
  if (!failureMessage) return;
  event.cancel = true;
  system.run(() => player.sendMessage(failureMessage));
});
system.runInterval(() => {
  const settings = loadPlotManagerItemSettings();
  if (!settings.autoGiveEnabled) return;
  for (const player of world.getPlayers()) {
    giveConfiguredPlotManagerItem(player, false);
  }
}, TOOL_CHECK_INTERVAL_TICKS);
function createDefaultDefenseSettings() {
  return {
    lockStrengthCosts: [25e3, 75e3, 15e4],
    lockStrengthExtraSeconds: [3, 6, 10],
    lockStrengthSuccessPenaltyPercent: [3, 6, 10],
    alarmCosts: [3e4, 9e4, 18e4],
    alarmEffect1Ids: ["speed", "speed", "speed"],
    alarmEffect1Amplifiers: [0, 0, 1],
    alarmEffect2Ids: ["resistance", "resistance", "resistance"],
    alarmEffect2Amplifiers: [0, 1, 1],
    alarmEffect3Ids: ["", "strength", "strength"],
    alarmEffect3Amplifiers: [0, 0, 0],
    alarmDurationsSeconds: [5, 7, 10],
    alarmPulseOnLockpickStart: true,
    alarmPulseOnTier3Breach: true,
    alarmTier3BreachPulseSeconds: 5,
    reinforcedContainerCosts: [2e4, 6e4, 12e4],
    reinforcedContainerDelaySeconds: [1.5, 3, 5],
    maxTier3UpgradeTypes: 2,
    extraPlotCostScalePercent: 10,
    upkeepPercentOfBalance: 5,
    upkeepDailyCap: 25e4,
    upkeepCapEnabled: true,
    upkeepChargeIntervalTicks: 24e3
  };
}
function normalizeNumberTriplet(values, fallback) {
  if (!Array.isArray(values) || values.length !== 3) return fallback;
  return [Number(values[0]), Number(values[1]), Number(values[2])];
}
function normalizeStringTriplet(values, fallback) {
  if (!Array.isArray(values) || values.length !== 3) return fallback;
  return [String(values[0] ?? ""), String(values[1] ?? ""), String(values[2] ?? "")];
}
function loadDefenseSettings() {
  const raw = world.getDynamicProperty(DEFENSE_SETTINGS_KEY);
  const defaults = createDefaultDefenseSettings();
  if (!raw) return defaults;
  try {
    const parsed = JSON.parse(raw);
    return {
      ...defaults,
      ...parsed,
      lockStrengthCosts: normalizeNumberTriplet(parsed.lockStrengthCosts, defaults.lockStrengthCosts),
      lockStrengthExtraSeconds: normalizeNumberTriplet(parsed.lockStrengthExtraSeconds, defaults.lockStrengthExtraSeconds),
      lockStrengthSuccessPenaltyPercent: normalizeNumberTriplet(parsed.lockStrengthSuccessPenaltyPercent, defaults.lockStrengthSuccessPenaltyPercent),
      alarmCosts: normalizeNumberTriplet(parsed.alarmCosts, defaults.alarmCosts),
      alarmEffect1Ids: normalizeStringTriplet(parsed.alarmEffect1Ids, defaults.alarmEffect1Ids),
      alarmEffect1Amplifiers: normalizeNumberTriplet(parsed.alarmEffect1Amplifiers, defaults.alarmEffect1Amplifiers),
      alarmEffect2Ids: normalizeStringTriplet(parsed.alarmEffect2Ids, defaults.alarmEffect2Ids),
      alarmEffect2Amplifiers: normalizeNumberTriplet(parsed.alarmEffect2Amplifiers, defaults.alarmEffect2Amplifiers),
      alarmEffect3Ids: normalizeStringTriplet(parsed.alarmEffect3Ids, defaults.alarmEffect3Ids),
      alarmEffect3Amplifiers: normalizeNumberTriplet(parsed.alarmEffect3Amplifiers, defaults.alarmEffect3Amplifiers),
      alarmDurationsSeconds: normalizeNumberTriplet(parsed.alarmDurationsSeconds, defaults.alarmDurationsSeconds),
      reinforcedContainerCosts: normalizeNumberTriplet(parsed.reinforcedContainerCosts, defaults.reinforcedContainerCosts),
      reinforcedContainerDelaySeconds: normalizeNumberTriplet(parsed.reinforcedContainerDelaySeconds, defaults.reinforcedContainerDelaySeconds)
    };
  } catch {
    return defaults;
  }
}
function saveDefenseSettings(settings) {
  world.setDynamicProperty(DEFENSE_SETTINGS_KEY, JSON.stringify(settings));
}
function loadDefenseUpkeepStates() {
  const raw = world.getDynamicProperty(DEFENSE_UPKEEP_KEY);
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    const normalized = {};
    for (const [playerId, value] of Object.entries(parsed)) {
      normalized[playerId] = {
        accruedOnlineTicks: Math.max(0, Number(value.accruedOnlineTicks ?? 0)),
        upgradesDisabled: Boolean(value.upgradesDisabled),
        lastChargeAmount: Math.max(0, Number(value.lastChargeAmount ?? 0)),
        chargeBaseBalance: Math.max(0, Number(value.chargeBaseBalance ?? 0))
      };
    }
    return normalized;
  } catch {
    return {};
  }
}
function saveDefenseUpkeepStates(states) {
  world.setDynamicProperty(DEFENSE_UPKEEP_KEY, JSON.stringify(states));
}
function createDefaultEconomySettings() {
  return {
    sellableItems: [
      { itemId: "minecraft:oak_log", name: "Oak Log", category: "Generator Drops", price: 5 },
      { itemId: "minecraft:cobblestone", name: "Cobblestone", category: "Generator Drops", price: 8 },
      { itemId: "minecraft:raw_iron", name: "Raw Iron", category: "Ores", price: 15 },
      { itemId: "minecraft:coal", name: "Coal", category: "Ores", price: 12 },
      { itemId: "minecraft:raw_gold", name: "Raw Gold", category: "Ores", price: 35 },
      { itemId: "minecraft:lapis_lazuli", name: "Lapis Lazuli", category: "Ores", price: 45 },
      { itemId: "minecraft:diamond", name: "Diamond", category: "Rare Items", price: 120 },
      { itemId: "minecraft:netherite_scrap", name: "Netherite Scrap", category: "Rare Items", price: 250 },
      { itemId: "minecraft:quartz_block", name: "Quartz Block", category: "Generator Drops", price: 450 },
      { itemId: "minecraft:copper_block", name: "Copper Block", category: "Generator Drops", price: 600 },
      { itemId: "minecraft:end_stone", name: "Endstone", category: "Generator Drops", price: 750 },
      { itemId: "minecraft:granite", name: "Granite", category: "Generator Drops", price: 1e3 },
      { itemId: "minecraft:diorite", name: "Diorite", category: "Generator Drops", price: 1125 },
      { itemId: "minecraft:bamboo_block", name: "Bamboo Block", category: "Generator Drops", price: 1250 },
      { itemId: "minecraft:slime", name: "Slime", category: "Mob Drops", price: 1400 },
      { itemId: "minecraft:packed_ice", name: "Packed Ice", category: "Generator Drops", price: 1600 },
      { itemId: "minecraft:magma", name: "Magma", category: "Generator Drops", price: 1800 },
      { itemId: "minecraft:quartz", name: "Quartz", category: "Ores", price: 2e3 },
      { itemId: "minecraft:amethyst_block", name: "Amethyst Block", category: "Rare Items", price: 2250 },
      { itemId: "minecraft:calcite", name: "Calcite", category: "Generator Drops", price: 2500 },
      { itemId: "minecraft:podzol", name: "Podzol", category: "Generator Drops", price: 2800 },
      { itemId: "minecraft:redstone", name: "Redstone", category: "Ores", price: 3200 },
      { itemId: "minecraft:honey_block", name: "Honey Block", category: "Rare Items", price: 4400 },
      { itemId: "minecraft:prismarine_bricks", name: "Prismarine Bricks", category: "Rare Items", price: 5200 },
      { itemId: "minecraft:moss_block", name: "Moss Block", category: "Rare Items", price: 6000 },
      { itemId: "minecraft:sponge", name: "Sponge", category: "Rare Items", price: 6600 },
      { itemId: "minecraft:emerald_block", name: "Emerald Block", category: "Rare Items", price: 7200 },
      { itemId: "minecraft:lodestone", name: "Lodestone", category: "Rare Items", price: 8000 },
      { itemId: "minecraft:nether_brick", name: "Nether Brick", category: "Rare Items", price: 8400 }
    ],
    sellGlobalMultiplier: 1,
    sellTaxPercent: 0,
    auctionTaxPercent: 0,
    raidEntryCost: 0,
    plotUpkeepCost: 0,
    minPriceCap: 0,
    maxPriceCap: 1e9,
    economyBoostEnabled: false,
    economyBoostMultiplier: 1.25,
    multiplierCosts: [1e5, 45e4, 12e5, 25e5, 5e6, 9e6, 15e6, 25e6, 4e7, 6e7, 9e7, 13e7, 18e7, 25e7, 35e7],
    multiplierMaxLevel: 15,
    multiplierIncrement: 0.1,
    multiplierScalingMode: "fixed",
    multiplierGrowthPercent: 25,
    shopItems: [],
    rebirthMoneyRequired: 5e8,
    rebirthRequiresPlot: false,
    rebirthBonusPerLevel: 0.2,
    rebirthMoneyMode: "reset",
    rebirthMoneyReductionPercent: 100,
    skygenCatalogVersion: 0,
    plotBuyPricesEnabled: true,
    plotResetCost: 0,
    messageSellTemplate: "Sold items for: ${earned}",
    messagePurchaseTemplate: "Upgrade purchased: {item}\nCost: ${cost}",
    messageNeedMoreTemplate: "You need ${missing} more to buy this.",
    soundPurchase: "com.plotshop_star_td3uf2sh.plotshop_purchase",
    soundError: "mob.villager.no"
  };
}
function normalizeSellableItem(value, fallback) {
  const itemId = String(value.itemId ?? fallback?.itemId ?? "").trim();
  if (!itemId.includes(":")) return null;
  const categoryCandidate = String(value.category ?? fallback?.category ?? "Generator Drops");
  const category = ECONOMY_CATEGORY_ORDER.includes(categoryCandidate) ? categoryCandidate : "Generator Drops";
  const price = Math.max(0, Math.floor(Number(value.price ?? fallback?.price ?? 0)));
  return {
    itemId,
    name: String(value.name ?? fallback?.name ?? itemId.split(":")[1] ?? itemId).trim() || itemId,
    category,
    price
  };
}
function clampEconomyPrice(value, settings) {
  const minCap = Math.max(0, Math.floor(Number(settings.minPriceCap ?? 0)));
  const maxCap = Math.max(minCap, Math.floor(Number(settings.maxPriceCap ?? 1e9)));
  return clampNumber(Math.max(0, Math.ceil(Number(value) || 0)), minCap, maxCap);
}
function calculateEffectiveSellValue(basePrice, multiplier, settings) {
  const boost = settings.economyBoostEnabled ? Math.max(0, Number(settings.economyBoostMultiplier) || 1) : 1;
  const beforeTax = basePrice * Math.max(0, multiplier) * Math.max(0, settings.sellGlobalMultiplier || 1) * boost;
  const afterTax = beforeTax * (1 - clampNumber(Number(settings.sellTaxPercent) || 0, 0, 100) / 100);
  return clampEconomyPrice(afterTax, settings);
}
function getConfiguredMultiplierStep(settings) {
  return Math.max(0.01, Number(settings.multiplierIncrement) || ECONOMY_MULTIPLIER_STEP);
}
function getConfiguredMultiplierMaxLevel(settings) {
  return clampNumber(Math.floor(Number(settings.multiplierMaxLevel) || ECONOMY_MULTIPLIER_MAX_LEVEL), 1, ECONOMY_MULTIPLIER_MAX_LEVEL);
}
function getConfiguredMultiplierForLevel(level, settings) {
  const maxLevel = getConfiguredMultiplierMaxLevel(settings);
  const clampedLevel = clampNumber(Math.floor(level), ECONOMY_MULTIPLIER_MIN_LEVEL, maxLevel);
  return ECONOMY_MULTIPLIER_BASE + clampedLevel * getConfiguredMultiplierStep(settings);
}
function createPresetEconomySettings(preset) {
  const settings = createDefaultEconomySettings();
  if (preset === "high_grind") {
    settings.sellGlobalMultiplier = 0.65;
    settings.sellTaxPercent = 7;
    settings.multiplierGrowthPercent = 35;
    settings.multiplierScalingMode = "percentage";
    settings.multiplierCosts = settings.multiplierCosts.map((cost) => Math.ceil(cost * 1.75));
  } else if (preset === "fast_economy") {
    settings.sellGlobalMultiplier = 1.5;
    settings.sellTaxPercent = 0;
    settings.economyBoostEnabled = true;
    settings.economyBoostMultiplier = 1.25;
    settings.multiplierCosts = settings.multiplierCosts.map((cost) => Math.ceil(cost * 0.5));
  }
  return settings;
}
function loadEconomySettings() {
  const defaults = createDefaultEconomySettings();
  const raw = world.getDynamicProperty(ECONOMY_SETTINGS_KEY);
  if (!raw) {
    const mergedDefaults = mergeSellablesWithSkygenCatalog(
      defaults.sellableItems,
      defaults.skygenCatalogVersion
    );
    defaults.sellableItems = mergedDefaults.items;
    defaults.skygenCatalogVersion = mergedDefaults.skygenCatalogVersion;
    return defaults;
  }
  try {
    const parsed = JSON.parse(raw);
    const sellableItems = Array.isArray(parsed.sellableItems) ? parsed.sellableItems.map((item) => normalizeSellableItem(item)).filter((item) => item !== null) : defaults.sellableItems;
    const multiplierCosts = Array.isArray(parsed.multiplierCosts) && parsed.multiplierCosts.length >= ECONOMY_MULTIPLIER_MAX_LEVEL ? parsed.multiplierCosts.slice(0, ECONOMY_MULTIPLIER_MAX_LEVEL).map((cost) => Math.max(0, Math.floor(Number(cost)))) : defaults.multiplierCosts;
    const shopItems = Array.isArray(parsed.shopItems) ? parsed.shopItems.map((item) => normalizeSellableItem(item)).filter((item) => item !== null) : defaults.shopItems;
    const settings = {
      ...defaults,
      ...parsed,
      sellableItems: sellableItems.length > 0 ? sellableItems : defaults.sellableItems,
      sellGlobalMultiplier: Math.max(0, Number(parsed.sellGlobalMultiplier ?? defaults.sellGlobalMultiplier)),
      sellTaxPercent: clampNumber(Number(parsed.sellTaxPercent ?? defaults.sellTaxPercent), 0, 100),
      auctionTaxPercent: clampNumber(Number(parsed.auctionTaxPercent ?? defaults.auctionTaxPercent), 0, 100),
      raidEntryCost: Math.max(0, Math.floor(Number(parsed.raidEntryCost ?? defaults.raidEntryCost))),
      plotUpkeepCost: Math.max(0, Math.floor(Number(parsed.plotUpkeepCost ?? defaults.plotUpkeepCost))),
      minPriceCap: Math.max(0, Math.floor(Number(parsed.minPriceCap ?? defaults.minPriceCap))),
      maxPriceCap: Math.max(0, Math.floor(Number(parsed.maxPriceCap ?? defaults.maxPriceCap))),
      economyBoostEnabled: Boolean(parsed.economyBoostEnabled ?? defaults.economyBoostEnabled),
      economyBoostMultiplier: Math.max(0, Number(parsed.economyBoostMultiplier ?? defaults.economyBoostMultiplier)),
      multiplierCosts,
      multiplierMaxLevel: getConfiguredMultiplierMaxLevel({ ...defaults, ...parsed, multiplierCosts, sellableItems: sellableItems.length > 0 ? sellableItems : defaults.sellableItems, shopItems }),
      multiplierIncrement: Math.max(0.01, Number(parsed.multiplierIncrement ?? defaults.multiplierIncrement)),
      multiplierScalingMode: parsed.multiplierScalingMode === "percentage" ? "percentage" : "fixed",
      multiplierGrowthPercent: clampNumber(Number(parsed.multiplierGrowthPercent ?? defaults.multiplierGrowthPercent), 0, 1e3),
      shopItems,
      rebirthMoneyRequired: Math.max(0, Math.floor(Number(parsed.rebirthMoneyRequired ?? defaults.rebirthMoneyRequired))),
      rebirthRequiresPlot: Boolean(parsed.rebirthRequiresPlot ?? defaults.rebirthRequiresPlot),
      rebirthBonusPerLevel: Math.max(0, Number(parsed.rebirthBonusPerLevel ?? defaults.rebirthBonusPerLevel)),
      rebirthMoneyMode: parsed.rebirthMoneyMode === "reduce" ? "reduce" : "reset",
      rebirthMoneyReductionPercent: clampNumber(Number(parsed.rebirthMoneyReductionPercent ?? defaults.rebirthMoneyReductionPercent), 0, 100),
      skygenCatalogVersion: Math.max(0, Math.floor(Number(parsed.skygenCatalogVersion ?? defaults.skygenCatalogVersion) || 0)),
      plotBuyPricesEnabled: Boolean(parsed.plotBuyPricesEnabled ?? defaults.plotBuyPricesEnabled),
      plotResetCost: Math.max(0, Math.floor(Number(parsed.plotResetCost ?? defaults.plotResetCost))),
      messageSellTemplate: String(parsed.messageSellTemplate ?? defaults.messageSellTemplate),
      messagePurchaseTemplate: String(parsed.messagePurchaseTemplate ?? defaults.messagePurchaseTemplate),
      messageNeedMoreTemplate: String(parsed.messageNeedMoreTemplate ?? defaults.messageNeedMoreTemplate),
      soundPurchase: String(parsed.soundPurchase ?? defaults.soundPurchase),
      soundError: String(parsed.soundError ?? defaults.soundError)
    };
    const mergedSkygenSellables = mergeSellablesWithSkygenCatalog(
      settings.sellableItems,
      settings.skygenCatalogVersion
    );
    settings.sellableItems = mergedSkygenSellables.items;
    settings.skygenCatalogVersion = mergedSkygenSellables.skygenCatalogVersion;
    if (mergedSkygenSellables.changed) {
      system.run(() => saveEconomySettings(settings));
    }
    return settings;
  } catch {
    return defaults;
  }
}
function saveEconomySettings(settings) {
  world.setDynamicProperty(ECONOMY_SETTINGS_KEY, JSON.stringify(settings));
}
var menuUseTimestamps = /* @__PURE__ */ new Map();
var combatTimestamps = /* @__PURE__ */ new Map();
var teleportCooldowns = /* @__PURE__ */ new Map();
var economySellCooldowns = /* @__PURE__ */ new Map();
var economyPurchaseCooldowns = /* @__PURE__ */ new Map();
var economyAdminEditCooldowns = /* @__PURE__ */ new Map();
var economyActiveTransactions = /* @__PURE__ */ new Set();
var pendingCreations = /* @__PURE__ */ new Map();
var playerPlotPresence = /* @__PURE__ */ new Map();
var pendingUnlocks = /* @__PURE__ */ new Map();
var lockedEntryWarnings = /* @__PURE__ */ new Map();
var activeLockpicks = /* @__PURE__ */ new Map();
var playerLockpickCooldowns = /* @__PURE__ */ new Map();
var lastKnownPlayerLocations = /* @__PURE__ */ new Map();
var playerLastActivityTicks = /* @__PURE__ */ new Map();
var playerRaidWindowUsage = /* @__PURE__ */ new Map();
var pendingContainerOpenDelays = /* @__PURE__ */ new Map();
var playerLastOutsidePlotLocations = /* @__PURE__ */ new Map();
var raidEntryPoints = /* @__PURE__ */ new Map();
var lastGlobalRaidTick = 0;
function loadPlots() {
  const raw = world.getDynamicProperty(PLOTS_KEY);
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    for (const p of parsed) {
      if (p.isPublic === void 0) p.isPublic = true;
      if (!p.members) p.members = [];
      if (p.memberSlotUpgrade === void 0) p.memberSlotUpgrade = 0;
      if (p.hasProtectionUpgrade === void 0) p.hasProtectionUpgrade = false;
      if (p.hasContainerShieldUpgrade === void 0) p.hasContainerShieldUpgrade = false;
      if (!p.accessLog) p.accessLog = [];
      if (p.lastOwnerActivity === void 0) p.lastOwnerActivity = 0;
      if (p.autoResetDays === void 0) p.autoResetDays = 0;
      if (p.breachedUntil === void 0) p.breachedUntil = 0;
      if (p.breachedBy === void 0) p.breachedBy = null;
      if (p.breachedById === void 0) p.breachedById = null;
      if (p.lastRaidedTick === void 0) p.lastRaidedTick = 0;
      if (p.containerShieldUntil === void 0) p.containerShieldUntil = 0;
      if (p.lockStrengthTier === void 0) p.lockStrengthTier = 0;
      if (p.alarmUpgradeTier === void 0) p.alarmUpgradeTier = 0;
      if (p.reinforcedContainerTier === void 0) p.reinforcedContainerTier = 0;
    }
    return parsed;
  } catch {
    return [];
  }
}
function savePlots(plots) {
  if (!Array.isArray(plots)) {
    world.sendMessage("§c[PlotShop] ERROR: Tried to save invalid plot data.");
    return false;
  }
  for (const p of plots) {
    if (!p || typeof p !== "object") continue;
    if (!Array.isArray(p.accessLog)) p.accessLog = [];
    if (p.accessLog.length > MAX_ACCESS_LOG_ENTRIES) {
      p.accessLog = p.accessLog.slice(-MAX_ACCESS_LOG_ENTRIES);
    }
  }
  const serialized = JSON.stringify(plots);
  // Bedrock dynamic properties have a 32,767 character limit.
  // If we exceed it, the save silently fails and member/plot data is lost.
  if (serialized.length > 32000) {
    world.sendMessage("§c[PlotShop] WARNING: Plot data is too large to save! (§e" + serialized.length + "§c / 32000 chars). Trim access logs or split plots to prevent data loss.");
    // Retry with access logs stripped entirely as a fallback
    const stripped = plots.map(p => ({ ...p, accessLog: [] }));
    const fallback = JSON.stringify(stripped);
    if (fallback.length <= 32000) {
      world.setDynamicProperty(PLOTS_KEY, fallback);
      world.sendMessage("§e[PlotShop] Saved with access logs cleared as emergency fallback.");
      return true;
    } else {
      world.sendMessage("§c[PlotShop] CRITICAL: Could not save plot data even after stripping logs! Data NOT saved this tick.");
      return false;
    }
  }
  try {
    world.setDynamicProperty(PLOTS_KEY, serialized);
    return true;
  } catch (e) {
    world.sendMessage("§c[PlotShop] ERROR saving plot data: " + String(e));
    return false;
  }
}
function ensureMoneyObjective() {
  const scoreboard = world.scoreboard;
  const existingObjective = scoreboard.getObjective(MONEY_OBJECTIVE_ID);
  if (existingObjective) return existingObjective;
  const objective = scoreboard.addObjective(MONEY_OBJECTIVE_ID, "Money");
  const legacyObjective = scoreboard.getObjective(LEGACY_MONEY_OBJECTIVE_ID);
  if (legacyObjective) {
    for (const player of world.getAllPlayers()) {
      const identity = player.scoreboardIdentity;
      if (!identity) continue;
      try {
        const legacyScore = legacyObjective.getScore(identity);
        if (typeof legacyScore === "number") {
          objective.setScore(identity, legacyScore);
        }
      } catch {
      }
    }
  }
  return objective;
}
function ensureObjective(objectiveId, displayName) {
  if (objectiveId === MONEY_OBJECTIVE_ID) return ensureMoneyObjective();
  const scoreboard = world.scoreboard;
  const existingObjective = scoreboard.getObjective(objectiveId);
  if (existingObjective) return existingObjective;
  return scoreboard.addObjective(objectiveId, displayName ?? objectiveId);
}
function getObjectiveIfExists(objectiveId) {
  const scoreboard = world.scoreboard;
  return scoreboard.getObjective(objectiveId) ?? void 0;
}
function ensurePlayerMoneyEntry(player) {
  const objective = ensureMoneyObjective();
  const identity = player.scoreboardIdentity;
  if (!identity) return;
  try {
    const score = objective.getScore(identity);
    if (typeof score !== "number") objective.setScore(identity, 0);
  } catch {
    objective.setScore(identity, 0);
  }
}
function getBalance(playerId) {
  const player = world.getAllPlayers().find((c) => c.id === playerId);
  if (!player?.scoreboardIdentity) return 0;
  const objective = ensureMoneyObjective();
  try {
    const score = objective.getScore(player.scoreboardIdentity);
    if (typeof score === "number") return score;
  } catch {
  }
  objective.setScore(player.scoreboardIdentity, 0);
  return 0;
}
function setBalance(playerId, amount) {
  const player = world.getAllPlayers().find((c) => c.id === playerId);
  if (!player?.scoreboardIdentity) return;
  ensureMoneyObjective().setScore(player.scoreboardIdentity, Math.max(0, Math.floor(amount)));
}
function addBalance(playerId, amount) {
  setBalance(playerId, getBalance(playerId) + amount);
}
function deductBalance(playerId, amount) {
  const current = getBalance(playerId);
  if (current < amount) return false;
  setBalance(playerId, current - amount);
  return true;
}
function getPlayerById(playerId) {
  return world.getAllPlayers().find((player) => player.id === playerId);
}
function getObjectiveBalance(playerId, objectiveId, displayName) {
  const player = getPlayerById(playerId);
  if (!player?.scoreboardIdentity) return 0;
  const objective = ensureObjective(objectiveId, displayName ?? objectiveId);
  try {
    const score = objective.getScore(player.scoreboardIdentity);
    return typeof score === "number" ? score : 0;
  } catch {
    objective.setScore(player.scoreboardIdentity, 0);
    return 0;
  }
}
function setObjectiveBalance(playerId, objectiveId, amount, displayName) {
  const player = getPlayerById(playerId);
  if (!player?.scoreboardIdentity) return;
  ensureObjective(objectiveId, displayName ?? objectiveId).setScore(player.scoreboardIdentity, Math.max(0, Math.floor(amount)));
}
function deductObjectiveBalance(playerId, objectiveId, amount, displayName) {
  const current = getObjectiveBalance(playerId, objectiveId, displayName);
  if (current < amount) return false;
  setObjectiveBalance(playerId, objectiveId, current - amount, displayName);
  return true;
}
function addObjectiveBalance(playerId, objectiveId, amount, displayName) {
  setObjectiveBalance(playerId, objectiveId, getObjectiveBalance(playerId, objectiveId, displayName) + amount, displayName);
}
function getPlayerScore(player, objectiveId) {
  const identity = player.scoreboardIdentity;
  if (!identity) return null;
  const objective = getObjectiveIfExists(objectiveId);
  if (!objective) return null;
  try {
    const score = objective.getScore(identity);
    return typeof score === "number" ? score : null;
  } catch {
    return null;
  }
}
function setPlayerScore(player, objectiveId, amount, displayName) {
  const identity = player.scoreboardIdentity;
  if (!identity) return;
  ensureObjective(objectiveId, displayName).setScore(identity, Math.floor(amount));
}
function getPrestigeLevel(player) {
  for (const objectiveId of PRESTIGE_OBJECTIVE_CANDIDATES) {
    const score = getPlayerScore(player, objectiveId);
    if (typeof score === "number") return score;
  }
  return 0;
}
function economyDataKey(playerId) {
  return `${ECONOMY_DATA_PREFIX}${playerId}`;
}
function createDefaultEconomyData() {
  return {
    multiplierLevel: ECONOMY_MULTIPLIER_MIN_LEVEL,
    rebirths: 0,
    totalEarned: 0,
    totalSpent: 0
  };
}
function normalizeEconomyData(data) {
  const defaults = createDefaultEconomyData();
  return {
    multiplierLevel: clampNumber(Math.floor(Number(data?.multiplierLevel ?? defaults.multiplierLevel)), ECONOMY_MULTIPLIER_MIN_LEVEL, ECONOMY_MULTIPLIER_MAX_LEVEL),
    rebirths: clampNumber(Math.floor(Number(data?.rebirths ?? defaults.rebirths)), 0, ECONOMY_MAX_REBIRTHS),
    totalEarned: Math.max(0, Math.floor(Number(data?.totalEarned ?? defaults.totalEarned))),
    totalSpent: Math.max(0, Math.floor(Number(data?.totalSpent ?? defaults.totalSpent)))
  };
}
function loadEconomyData(playerId) {
  const raw = world.getDynamicProperty(economyDataKey(playerId));
  if (!raw) return createDefaultEconomyData();
  try {
    return normalizeEconomyData(JSON.parse(raw));
  } catch {
    return createDefaultEconomyData();
  }
}
function saveEconomyData(playerId, data) {
  world.setDynamicProperty(economyDataKey(playerId), JSON.stringify(normalizeEconomyData(data)));
}
function getEconomyMultiplier(levelOrData) {
  const level = typeof levelOrData === "number" ? levelOrData : levelOrData.multiplierLevel;
  return Number((ECONOMY_MULTIPLIER_BASE + clampNumber(level, 0, ECONOMY_MULTIPLIER_MAX_LEVEL) * ECONOMY_MULTIPLIER_STEP).toFixed(2));
}
function getEconomyRebirthBonus(data, settings) {
  const economySettings = settings ?? loadEconomySettings();
  return Number((1 + data.rebirths * economySettings.rebirthBonusPerLevel).toFixed(2));
}
function formatMoney(amount) {
  return Math.floor(amount).toLocaleString("en-US");
}
function formatMultiplier(value) {
  return `${value.toFixed(2)}x`;
}
function syncEconomyScoreboards(player) {
  const data = loadEconomyData(player.id);
  setPlayerScore(player, SKYGEN_MULTIPLIER_OBJECTIVE_ID, data.multiplierLevel, SKYGEN_MULTIPLIER_OBJECTIVE_ID);
}
function isEconomyAdmin(player) {
  return player.hasTag("guiadmin");
}
function economyMessage(template, values) {
  let output = template;
  for (const [key, value] of Object.entries(values)) {
    output = output.replace(new RegExp(`\\{${key}\\}`, "g"), String(value));
  }
  return output;
}
function showNeedMoreMoney(player, cost, settings) {
  const balance = getBalance(player.id);
  const missing = Math.max(0, cost - balance);
  const economySettings = settings ?? loadEconomySettings();
  player.sendMessage(`\xA7c${economyMessage(economySettings.messageNeedMoreTemplate, { missing: formatMoney(missing), cost: formatMoney(cost), balance: formatMoney(balance) })}`);
  playSoundForPlayer(player, economySettings.soundError, { volume: 1, pitch: 0.65 });
}
function canStartEconomyTransaction(player, kind, key) {
  const lockKey = `${player.id}:${key}`;
  if (economyActiveTransactions.has(lockKey)) return false;
  const cooldowns = kind === "sell" ? economySellCooldowns : economyPurchaseCooldowns;
  const cooldownTicks = kind === "sell" ? ECONOMY_SELL_COOLDOWN_TICKS : ECONOMY_PURCHASE_COOLDOWN_TICKS;
  const last = cooldowns.get(player.id);
  if (last !== void 0 && system.currentTick - last < cooldownTicks) return false;
  cooldowns.set(player.id, system.currentTick);
  economyActiveTransactions.add(lockKey);
  return true;
}
function finishEconomyTransaction(player, key) {
  economyActiveTransactions.delete(`${player.id}:${key}`);
}
function spendMoney(player, cost, transactionKey, settings) {
  if (!Number.isFinite(cost) || cost < 0) return false;
  if (!canStartEconomyTransaction(player, "purchase", transactionKey)) {
    player.sendMessage("\xA7cTransaction is already processing. Please wait a moment.");
    return false;
  }
  try {
    if (getBalance(player.id) < cost) {
      showNeedMoreMoney(player, cost, settings);
      return false;
    }
    if (!deductBalance(player.id, cost)) {
      showNeedMoreMoney(player, cost, settings);
      return false;
    }
    const data = loadEconomyData(player.id);
    data.totalSpent += Math.floor(cost);
    saveEconomyData(player.id, data);
    return true;
  } finally {
    finishEconomyTransaction(player, transactionKey);
  }
}
function rewardMoney(player, amount) {
  const earned = Math.max(0, Math.floor(amount));
  addBalance(player.id, earned);
  const data = loadEconomyData(player.id);
  data.totalEarned += earned;
  saveEconomyData(player.id, data);
}
function refundSpentMoney(player, amount) {
  const refunded = Math.max(0, Math.floor(amount));
  addBalance(player.id, refunded);
  const data = loadEconomyData(player.id);
  data.totalSpent = Math.max(0, data.totalSpent - refunded);
  saveEconomyData(player.id, data);
}
function getInventoryContainer(player) {
  const inventory = player.getComponent("minecraft:inventory");
  return inventory?.container;
}
function findItemSlot(container, itemId) {
  for (let slot = 0; slot < container.size; slot++) {
    const item = container.getItem(slot);
    if (item?.typeId === itemId) return slot;
  }
  return -1;
}
function findEmptySlot(container, ignoredSlots = []) {
  for (let slot = 0; slot < container.size; slot++) {
    if (ignoredSlots.includes(slot)) continue;
    if (!container.getItem(slot)) return slot;
  }
  return -1;
}
function createLockedTool(itemId) {
  const item = new ItemStack(itemId, 1);
  try {
    item.lockMode = ItemLockMode.slot;
  } catch {
  }
  return item;
}
function ensureToolInSlot(player, itemId, preferredSlot) {
  const container = getInventoryContainer(player);
  if (!container) return;
  const preferredItem = container.getItem(preferredSlot);
  if (preferredItem?.typeId === itemId) return;
  const existingSlot = findItemSlot(container, itemId);
  if (existingSlot !== -1) {
    if (!preferredItem) {
      container.setItem(preferredSlot, container.getItem(existingSlot));
      container.setItem(existingSlot, void 0);
    }
    return;
  }
  const newTool = createLockedTool(itemId);
  if (!preferredItem) {
    container.setItem(preferredSlot, newTool);
    return;
  }
  const emptySlot = findEmptySlot(container, [preferredSlot]);
  if (emptySlot !== -1) {
    container.setItem(emptySlot, preferredItem);
    container.setItem(preferredSlot, newTool);
  }
}
function removeTool(player, itemId) {
  const container = getInventoryContainer(player);
  if (!container) return;
  for (let slot = 0; slot < container.size; slot++) {
    const item = container.getItem(slot);
    if (item?.typeId === itemId) container.setItem(slot, void 0);
  }
}
function clearContainer(container) {
  if (!container) return;
  for (let slot = 0; slot < container.size; slot++) {
    container.setItem(slot, void 0);
  }
}
function restoreSoldStacks(container, removedStacks) {
  for (const sold of removedStacks) {
    try {
      container.setItem(sold.slot, sold.item);
    } catch {
    }
  }
}
function runSellAllRemoval(player, settings) {
  const container = getInventoryContainer(player);
  if (!container) return null;
  const priceMap = new Map(settings.sellableItems.filter((item) => item.price > 0).map((item) => [item.itemId, item]));
  const soldCounts = /* @__PURE__ */ new Map();
  const blockedCounts = /* @__PURE__ */ new Map();
  const removedStacks = [];
  let baseValue = 0;
  for (let slot = 0; slot < container.size; slot++) {
    const item = container.getItem(slot);
    if (!item) continue;
    const sellable = priceMap.get(item.typeId);
    if (!sellable) continue;
    const access = evaluateSkygenSellAccess(player, item.typeId);
    if (!access.allowed) {
      const currentBlocked = blockedCounts.get(item.typeId) ?? {
        amount: 0,
        reason: access.reason,
        requiredRebirth: access.requiredRebirth ?? 0
      };
      currentBlocked.amount += Math.max(1, Number(item.amount ?? 1));
      currentBlocked.reason = access.reason;
      currentBlocked.requiredRebirth = access.requiredRebirth ?? currentBlocked.requiredRebirth;
      blockedCounts.set(item.typeId, currentBlocked);
      continue;
    }
    const amount = Math.max(1, Number(item.amount ?? 1));
    soldCounts.set(item.typeId, (soldCounts.get(item.typeId) ?? 0) + amount);
    baseValue += sellable.price * amount;
    removedStacks.push({ slot, item });
  }
  if (baseValue <= 0 || removedStacks.length === 0) return { soldCounts, blockedCounts, baseValue: 0, finalEarned: 0, removedStacks: [] };
  try {
    for (const sold of removedStacks) container.setItem(sold.slot, void 0);
  } catch {
    restoreSoldStacks(container, removedStacks);
    return null;
  }
  for (const sold of removedStacks) {
    const current = container.getItem(sold.slot);
    if (current?.typeId === sold.item.typeId) {
      restoreSoldStacks(container, removedStacks);
      return null;
    }
  }
  const data = loadEconomyData(player.id);
  const multiplier = getEconomyMultiplier(data);
  const rebirthBonus = getEconomyRebirthBonus(data, settings);
  const boostMultiplier = settings.economyBoostEnabled ? settings.economyBoostMultiplier : 1;
  const taxMultiplier = 1 - settings.sellTaxPercent / 100;
  const finalEarned = Math.floor(baseValue * settings.sellGlobalMultiplier * multiplier * rebirthBonus * boostMultiplier * taxMultiplier);
  return { soldCounts, blockedCounts, baseValue, finalEarned, removedStacks };
}
function getSoldItemSummary(soldCounts, settings) {
  const itemMap = new Map(settings.sellableItems.map((item) => [item.itemId, item.name]));
  const entries = [...soldCounts.entries()].map(([itemId, count]) => `${itemMap.get(itemId) ?? itemId} x${count}`).slice(0, 8);
  const extra = soldCounts.size > entries.length ? `
\xA78+${soldCounts.size - entries.length} more item type(s)` : "";
  return entries.length > 0 ? `${entries.join("\n")}${extra}` : "No valid Skygen items found.";
}
function getEnderChestContainer(player) {
  const enderChest = player.getComponent("minecraft:ender_chest_inventory") ?? void 0;
  return enderChest?.container ?? enderChest;
}
function escapeSelectorName(playerName) {
  return playerName.replace(/\\/g, "\\\\").replace(/\"/g, '\\"');
}
function getPlayerCommandSelector(player) {
  return `@a[name="${escapeSelectorName(player.name)}",c=1]`;
}
function clearPlayerInventoryAndEnderChest(player) {
  clearContainer(getInventoryContainer(player));
  clearContainer(getEnderChestContainer(player));
  const selector = getPlayerCommandSelector(player);
  try {
    player.dimension.runCommand(`clear ${selector}`);
  } catch {
  }
  for (let slot = 0; slot < 27; slot++) {
    try {
      player.dimension.runCommand(`replaceitem entity ${selector} slot.enderchest ${slot} air`);
    } catch {
    }
  }
}
function ensurePlayerTools(player) {
  ensurePlayerMoneyEntry(player);
  syncEconomyScoreboards(player);
  ensureToolInSlot(player, PLOT_MANAGER_ITEM_ID, PLOT_MANAGER_SLOT);
  if (isAdmin(player) || isEconomyAdmin(player)) {
    ensureToolInSlot(player, PLOT_ADMIN_TOOL_ITEM_ID, PLOT_ADMIN_SLOT);
  } else {
    removeTool(player, PLOT_ADMIN_TOOL_ITEM_ID);
  }
}
function tryOpenMenu(player, openCallback) {
  const lastUse = menuUseTimestamps.get(player.id);
  if (lastUse !== void 0 && system.currentTick - lastUse < MENU_USE_COOLDOWN_TICKS) return;
  menuUseTimestamps.set(player.id, system.currentTick);
  openCallback(player);
}
function getPlayerBooleanPreference(player, key, defaultValue) {
  const value = player.getDynamicProperty(key);
  return typeof value === "boolean" ? value : defaultValue;
}
function setPlayerBooleanPreference(player, key, value) {
  player.setDynamicProperty(key, value);
}
function arePersonalSoundsEnabled(player) {
  return getPlayerBooleanPreference(player, PLAYER_SOUNDS_KEY, true);
}
function arePersonalVisualsEnabled(player) {
  return getPlayerBooleanPreference(player, PLAYER_VISUALS_KEY, true);
}
function playSoundForPlayer(player, soundId, options) {
  if (!arePersonalSoundsEnabled(player)) return;
  try {
    player.playSound?.(soundId, options);
    if (player.playSound) return;
  } catch {
  }
  try {
    player.dimension.playSound(soundId, player.location, options);
  } catch {
  }
}
world.afterEvents.entityHurt.subscribe((event) => {
  if (event.hurtEntity instanceof Player) {
    combatTimestamps.set(event.hurtEntity.id, system.currentTick);
  }
  if (event.damageSource?.damagingEntity instanceof Player) {
    combatTimestamps.set(event.damageSource.damagingEntity.id, system.currentTick);
  }
});
function isInCombat(player) {
  const last = combatTimestamps.get(player.id);
  if (last === void 0) return false;
  if (system.currentTick - last >= COMBAT_DURATION_TICKS) {
    combatTimestamps.delete(player.id);
    return false;
  }
  return true;
}
function plotSize(p) {
  const dx = Math.abs(p.x2 - p.x1) + 1;
  const dz = Math.abs(p.z2 - p.z1) + 1;
  return `${dx}x${dz}`;
}
function getPlotNumber(plot) {
  const match = plot.id.match(/(\d+)/);
  if (!match) return null;
  const parsed = parseInt(match[1], 10);
  return Number.isFinite(parsed) ? parsed : null;
}
function getPlotSideLabel(plot) {
  const plotNumber = getPlotNumber(plot);
  if (plotNumber === null) return "Side ?";
  if (plotNumber >= 1 && plotNumber <= 12) return "Side A";
  if (plotNumber >= 13 && plotNumber <= 24) return "Side B";
  if (plotNumber >= 25 && plotNumber <= 36) return "Side C";
  if (plotNumber >= 37 && plotNumber <= 48) return "Side D";
  return "Extra";
}
function getPlotMenuLabel(plot) {
  return `${plot.id} | ${getPlotSideLabel(plot)}`;
}
function plotCenter(p) {
  return {
    x: Math.floor((p.x1 + p.x2) / 2),
    y: Math.min(p.y1, p.y2) + 1,
    z: Math.floor((p.z1 + p.z2) / 2)
  };
}
function plotReferenceY(plot) {
  return Math.min(plot.y1, plot.y2);
}
function getPlotBounds(plot) {
  return {
    minX: Math.min(plot.x1, plot.x2),
    maxX: Math.max(plot.x1, plot.x2),
    minZ: Math.min(plot.z1, plot.z2),
    maxZ: Math.max(plot.z1, plot.z2)
  };
}
function standardizePlotNumbering(plots) {
  if (plots.length === 0) return false;
  const sorted = [...plots].sort((a, b) => {
    const aCenterZ = (a.z1 + a.z2) / 2;
    const bCenterZ = (b.z1 + b.z2) / 2;
    const zCompare = aCenterZ - bCenterZ;
    if (Math.abs(zCompare) > 1) return zCompare;
    const aCenterX = (a.x1 + a.x2) / 2;
    const bCenterX = (b.x1 + b.x2) / 2;
    return aCenterX - bCenterX;
  });
  let changed = false;
  for (let i = 0; i < sorted.length; i++) {
    const standardizedId = `Plot ${i + 1}`;
    if (sorted[i].id !== standardizedId) {
      addAccessLog(sorted[i], "System", `renumbered from ${sorted[i].id} to ${standardizedId}`);
      sorted[i].id = standardizedId;
      changed = true;
    }
  }
  return changed;
}
function standardizePlotsIfNeeded() {
  const currentVersion = world.getDynamicProperty(PLOT_LAYOUT_VERSION_KEY);
  if (currentVersion === CURRENT_PLOT_LAYOUT_VERSION) return;
  const plots = loadPlots();
  const changed = standardizePlotNumbering(plots);
  if (changed) savePlots(plots);
  world.setDynamicProperty(PLOT_LAYOUT_VERSION_KEY, CURRENT_PLOT_LAYOUT_VERSION);
}
function plotVerticalCoverageText() {
  return `${PLOT_WORLD_MIN_Y} to ${PLOT_WORLD_MAX_Y}`;
}
function getOwnedPlotsForPlayer(plots, playerId) {
  return plots.filter((plot) => plot.ownerId === playerId);
}
function getPrimaryOwnedPlot(plots, playerId) {
  return getOwnedPlotsForPlayer(plots, playerId)[0];
}
function canPlayerReceiveOwnership(plots, playerId, excludedPlotId) {
  return !plots.some((plot) => plot.ownerId === playerId && plot.id !== excludedPlotId);
}
function getOnePlotLimitMessage(currentPlot) {
  const currentPlotLine = currentPlot ? `\xA7fCurrent owned plot: \xA76${currentPlot.id}

` : "\n";
  return "\xA7cYou can only own one plot at a time.\n\n" + currentPlotLine + "\xA7fSell or transfer your current plot before buying or receiving another one.";
}
function showOnePlotLimitMessage(player, currentPlot, onClose) {
  const form = new MessageFormData().title("\xA7cOne Plot Limit").body(getOnePlotLimitMessage(currentPlot)).button1("\xA76My Plot").button2("\xA78Back");
  form.show(player).then((res) => {
    if (res.selection === 0) {
      openMyPlotMenu(player);
      return;
    }
    onClose?.();
  }).catch(() => {
    onClose?.();
  });
}
function warnLegacyMultiPlotOwnership(player) {
  const plots = loadPlots();
  const owned = getOwnedPlotsForPlayer(plots, player.id);
  if (owned.length <= 1) return;
  player.sendMessage(
    `\xA7cThis server now limits players to one owned plot at a time. \xA7fYou currently have \xA76${owned.length}\xA7f legacy plots. Sell or transfer extras before getting any new plot.`
  );
}
function clampNumber(value, min, max) {
  return Math.max(min, Math.min(max, value));
}
function formatCompactCurrency(amount) {
  if (amount >= 1e9) return `${(amount / 1e9).toFixed(amount % 1e9 === 0 ? 0 : 1)}B`;
  if (amount >= 1e6) return `${(amount / 1e6).toFixed(amount % 1e6 === 0 ? 0 : 1)}M`;
  if (amount >= 1e3) return `${(amount / 1e3).toFixed(amount % 1e3 === 0 ? 0 : 1)}K`;
  return `${Math.floor(amount)}`;
}
function parsePositiveInteger(value, fallback) {
  const parsed = parseInt(value.trim(), 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}
function parsePositiveNumber(value, fallback) {
  const parsed = parseFloat(value.trim());
  return Number.isFinite(parsed) ? parsed : fallback;
}
function getRaidTierBaseSuccess(settings, tier) {
  return settings.baseSuccessRates[tier - 1] ?? settings.baseSuccessRates[0];
}
function getRaidTierSuccessPercent(settings, tier) {
  let success = getRaidTierBaseSuccess(settings, tier);
  if (settings.tierScalingMode === "success" || settings.tierScalingMode === "hybrid") {
    success += (tier - 1) * settings.tierSuccessBonus;
  }
  return clampNumber(Math.round(success), 1, 100);
}
function getRaidTierBaseTimeSeconds(settings, tier) {
  return settings.pickTimesSeconds[tier - 1] ?? settings.pickTimesSeconds[0];
}
function getRaidTierPickTimeSeconds(settings, tier) {
  let seconds = getRaidTierBaseTimeSeconds(settings, tier);
  if (settings.tierScalingMode === "time" || settings.tierScalingMode === "hybrid") {
    seconds -= (tier - 1) * settings.tierTimeReductionSeconds;
  }
  return clampNumber(Math.round(seconds), 5, 30);
}
function getRaidPlayerCooldownTicks(settings) {
  return clampNumber(settings.playerCooldownSeconds, 0, 300) * 20;
}
function getRaidPlotCooldownTicks(settings) {
  return clampNumber(settings.plotCooldownMinutes, 0, 120) * 60 * 20;
}
function getRaidGlobalCooldownTicks(settings) {
  return clampNumber(settings.globalCooldownSeconds, 0, 900) * 20;
}
function getRaidTierMoneyCost(settings, tier) {
  const baseCost = settings.toolCosts[tier - 1] ?? settings.toolCosts[0];
  const scaledCost = baseCost * (1 + (tier - 1) * settings.costScalePercent / 100);
  return Math.max(0, Math.round(scaledCost));
}
function getRaidTierCTokenCost(settings, tier) {
  const enabled = tier === 2 ? settings.useCTokensForTier2 : tier === 3 ? settings.useCTokensForTier3 : false;
  if (!enabled) return 0;
  const baseCost = settings.ctokenCosts[tier - 1] ?? 0;
  const scaledCost = baseCost * (1 + (tier - 1) * settings.ctokenScalePercent / 100);
  return Math.max(0, Math.round(scaledCost));
}
function getRaidTierCTokenLabel(settings, tier) {
  const cost = getRaidTierCTokenCost(settings, tier);
  return cost > 0 ? ` + ${cost} CT` : "";
}
function getRaidTierSummaryLines(settings, tier) {
  const name = tier === 1 ? "Tier 1 Lockpick" : tier === 2 ? "Tier 2 Lockpick" : "Tier 3 Lockpick";
  const success = getRaidTierSuccessPercent(settings, tier);
  const seconds = getRaidTierPickTimeSeconds(settings, tier);
  const moneyCost = formatCompactCurrency(getRaidTierMoneyCost(settings, tier));
  const ctokenLabel = getRaidTierCTokenLabel(settings, tier);
  return [
    name,
    `Success ${success}% | ${seconds}s`,
    `Cost $${moneyCost}${ctokenLabel}`
  ];
}
function getRaidTierDisplayName(tier) {
  return tier === 1 ? "\xA77Tier 1 Lockpick" : tier === 2 ? "\xA76Tier 2 Lockpick" : "\xA7bTier 3 Lockpick";
}
function plotHasAnyDefenseUpgrade(plot) {
  return plot.lockStrengthTier > 0 || plot.alarmUpgradeTier > 0 || plot.reinforcedContainerTier > 0;
}
function getDefenseUpkeepState(playerId, states) {
  const upkeepStates = states ?? loadDefenseUpkeepStates();
  return upkeepStates[playerId] ?? {
    accruedOnlineTicks: 0,
    upgradesDisabled: false,
    lastChargeAmount: 0,
    chargeBaseBalance: 0
  };
}
function areDefenseUpgradesActiveForPlayer(playerId, states) {
  return !getDefenseUpkeepState(playerId, states).upgradesDisabled;
}
function areDefenseUpgradesActiveForPlot(plot, states) {
  if (!plot.ownerId || !plotHasAnyDefenseUpgrade(plot)) return false;
  return areDefenseUpgradesActiveForPlayer(plot.ownerId, states);
}
function getActiveLockStrengthTier(plot, states) {
  return areDefenseUpgradesActiveForPlot(plot, states) ? clampNumber(plot.lockStrengthTier, 0, 3) : 0;
}
function getActiveAlarmUpgradeTier(plot, states) {
  return areDefenseUpgradesActiveForPlot(plot, states) ? clampNumber(plot.alarmUpgradeTier, 0, 3) : 0;
}
function getActiveReinforcedContainerTier(plot, states) {
  return areDefenseUpgradesActiveForPlot(plot, states) ? clampNumber(plot.reinforcedContainerTier, 0, 3) : 0;
}
function getPlotOwnedCountForPlayer(playerId) {
  return getOwnedPlotsForPlayer(loadPlots(), playerId).length;
}
function getDefenseScaledCost(baseCost, playerId, settings) {
  const extraPlots = Math.max(0, getPlotOwnedCountForPlayer(playerId) - 1);
  return Math.max(0, Math.round(baseCost * (1 + extraPlots * settings.extraPlotCostScalePercent / 100)));
}
function getDefenseUpgradeTier3Count(plot) {
  return [plot.lockStrengthTier, plot.alarmUpgradeTier, plot.reinforcedContainerTier].filter((tier) => tier >= 3).length;
}
function canUpgradeDefenseTypeToTier3(plot, currentTier, settings) {
  if (currentTier >= 3) return true;
  return getDefenseUpgradeTier3Count(plot) < Math.max(0, settings.maxTier3UpgradeTypes);
}
function getDefenseStatusLabel(plot, states) {
  if (!plotHasAnyDefenseUpgrade(plot)) return "\xA78No defense upgrades";
  return areDefenseUpgradesActiveForPlot(plot, states) ? "\xA72Active" : "\xA7cDisabled (upkeep unpaid)";
}
function getDefenseUpkeepChargeAmount(playerId, settings, baseBalance) {
  const balanceForCharge = baseBalance ?? getBalance(playerId);
  const percentCharge = Math.floor(balanceForCharge * (settings.upkeepPercentOfBalance / 100));
  const cappedCharge = settings.upkeepCapEnabled ? Math.min(percentCharge, Math.max(0, settings.upkeepDailyCap)) : percentCharge;
  return Math.max(0, cappedCharge);
}
function getDefenseUpkeepProgress(playerId, settings, states) {
  const state = getDefenseUpkeepState(playerId, states);
  const total = Math.max(1, settings.upkeepChargeIntervalTicks);
  return {
    current: clampNumber(state.accruedOnlineTicks, 0, total),
    total
  };
}
function getDefenseTierName(type) {
  switch (type) {
    case "lock":
      return "Lock Strength";
    case "alarm":
      return "Alarm Upgrade";
    default:
      return "Reinforced Containers";
  }
}
function getDefenseTierCost(type, tier, playerId, settings) {
  const tierIndex = clampNumber(tier, 1, 3) - 1;
  const baseCost = type === "lock" ? settings.lockStrengthCosts[tierIndex] : type === "alarm" ? settings.alarmCosts[tierIndex] : settings.reinforcedContainerCosts[tierIndex];
  return getDefenseScaledCost(baseCost, playerId, settings);
}
function getLockStrengthTimeBonusSeconds(plot, settings, states) {
  const defenseSettings = settings ?? loadDefenseSettings();
  const tier = getActiveLockStrengthTier(plot, states);
  if (tier <= 0) return 0;
  return Math.max(0, defenseSettings.lockStrengthExtraSeconds[tier - 1] ?? 0);
}
function getLockStrengthSuccessPenalty(plot, settings, states) {
  const defenseSettings = settings ?? loadDefenseSettings();
  const tier = getActiveLockStrengthTier(plot, states);
  if (tier <= 0) return 0;
  return Math.max(0, defenseSettings.lockStrengthSuccessPenaltyPercent[tier - 1] ?? 0);
}
function getReinforcedContainerDelaySeconds(plot, settings, states) {
  const defenseSettings = settings ?? loadDefenseSettings();
  const tier = getActiveReinforcedContainerTier(plot, states);
  if (tier <= 0) return 0;
  return Math.max(0, defenseSettings.reinforcedContainerDelaySeconds[tier - 1] ?? 0);
}
function getAlarmTierDurationSeconds(tier, settings) {
  const defenseSettings = settings ?? loadDefenseSettings();
  return Math.max(1, Math.round(defenseSettings.alarmDurationsSeconds[clampNumber(tier, 1, 3) - 1] ?? 5));
}
function sanitizeEffectId(effectId) {
  return String(effectId ?? "").trim().toLowerCase().replace(/[^a-z0-9_]/g, "");
}
function applyEffectToPlayer(player, effectId, durationSeconds, amplifier) {
  const sanitized = sanitizeEffectId(effectId);
  if (!sanitized) return;
  try {
    player.dimension.runCommand(`effect ${getPlayerCommandSelector(player)} ${sanitized} ${Math.max(1, Math.round(durationSeconds))} ${Math.max(0, Math.floor(amplifier))} true`);
  } catch {
  }
}
function getAlarmRecipients(plot) {
  const eligibleIds = /* @__PURE__ */ new Set();
  if (plot.ownerId) eligibleIds.add(plot.ownerId);
  for (const member of plot.members) {
    if (member.role === "visitor") continue;
    if (member.expiresAt !== null && system.currentTick >= member.expiresAt) continue;
    eligibleIds.add(member.playerId);
  }
  return world.getAllPlayers().filter((player) => eligibleIds.has(player.id));
}
function applyAlarmUpgradePulse(plot, trigger, attackerName, settings, upkeepStates) {
  const defenseSettings = settings ?? loadDefenseSettings();
  const tier = getActiveAlarmUpgradeTier(plot, upkeepStates);
  if (tier <= 0) return;
  if (trigger === "lockpick_start" && !defenseSettings.alarmPulseOnLockpickStart) return;
  if (trigger === "breach" && (tier < 3 || !defenseSettings.alarmPulseOnTier3Breach)) return;
  const durationSeconds = trigger === "breach" ? Math.max(1, Math.round(defenseSettings.alarmTier3BreachPulseSeconds)) : getAlarmTierDurationSeconds(tier, defenseSettings);
  const tierIndex = tier - 1;
  const recipients = getAlarmRecipients(plot);
  if (recipients.length === 0) return;
  for (const recipient of recipients) {
    applyEffectToPlayer(recipient, defenseSettings.alarmEffect1Ids[tierIndex], durationSeconds, defenseSettings.alarmEffect1Amplifiers[tierIndex]);
    applyEffectToPlayer(recipient, defenseSettings.alarmEffect2Ids[tierIndex], durationSeconds, defenseSettings.alarmEffect2Amplifiers[tierIndex]);
    applyEffectToPlayer(recipient, defenseSettings.alarmEffect3Ids[tierIndex], durationSeconds, defenseSettings.alarmEffect3Amplifiers[tierIndex]);
    recipient.sendMessage(
      trigger === "breach" ? `\xA76Alarm pulse: \xA7f${plot.id} was breached by \xA7c${attackerName}\xA7f. Defensive buffs refreshed for \xA7e${durationSeconds}s\xA7f.` : `\xA76Alarm pulse: \xA7f${attackerName} started lockpicking \xA7e${plot.id}\xA7f. Defensive buffs active for \xA7e${durationSeconds}s\xA7f.`
    );
  }
}
function getContainerDelayKey(playerId, plotId, blockKey) {
  return `${playerId}|${plotId}|${blockKey}`;
}
function getUpkeepIntervalLabel(settings) {
  return `${Math.max(1, Math.round(settings.upkeepChargeIntervalTicks / 20))}s / ${settings.upkeepChargeIntervalTicks}t`;
}
function getDefenseUpgradeSummary(plot, settings, upkeepStates) {
  const defenseSettings = settings ?? loadDefenseSettings();
  return `\xA7fLock Strength: \xA7eT${plot.lockStrengthTier}\xA7f` + (plot.lockStrengthTier > 0 ? ` \xA78(+${getLockStrengthTimeBonusSeconds(plot, defenseSettings, upkeepStates)}s, -${getLockStrengthSuccessPenalty(plot, defenseSettings, upkeepStates)}%)` : "") + `
\xA7fAlarm Upgrade: \xA7eT${plot.alarmUpgradeTier}\xA7f` + (plot.alarmUpgradeTier > 0 ? ` \xA78(${getAlarmTierDurationSeconds(plot.alarmUpgradeTier, defenseSettings)}s pulse)` : "") + `
\xA7fReinforced Containers: \xA7eT${plot.reinforcedContainerTier}\xA7f` + (plot.reinforcedContainerTier > 0 ? ` \xA78(${getReinforcedContainerDelaySeconds(plot, defenseSettings, upkeepStates)}s delay)` : "");
}
function getTierScalingLabel(mode) {
  switch (mode) {
    case "success":
      return "Success";
    case "time":
      return "Faster Time";
    default:
      return "Hybrid";
  }
}
function getEntryModeLabel(mode) {
  return mode === "attacker_only" ? "Attacker Only" : "All Players";
}
function getFailPenaltyLabel(mode) {
  switch (mode) {
    case "break_item":
      return "Break Item";
    case "cooldown":
      return "Cooldown";
    default:
      return "Both";
  }
}
function formatRaidMessage(template, plot, attackerName) {
  return template.replace(/\{plot\}/g, plot.id).replace(/\{attacker\}/g, attackerName).replace(/\{owner\}/g, plot.ownerName ?? "Unknown");
}
function isProtectedRaidCoreBlock(blockId) {
  const protectedKeywords = [
    "bedrock",
    "beacon",
    "lodestone",
    "respawn_anchor",
    "end_portal_frame",
    "command_block",
    "repeating_command_block",
    "chain_command_block",
    "vault",
    "trial_spawner"
  ];
  return protectedKeywords.some((keyword) => blockId.includes(keyword));
}
function isRaidEntryAllowed(plot, playerId, settings) {
  if (!isPlotBreached(plot)) return false;
  const raidSettings = settings ?? loadRaidSettings();
  return raidSettings.entryMode === "all_players" || plot.breachedById === playerId;
}
function isPlayerAfk(player, settings) {
  const raidSettings = settings ?? loadRaidSettings();
  const lastActiveTick = playerLastActivityTicks.get(player.id) ?? system.currentTick;
  return system.currentTick - lastActiveTick >= clampNumber(raidSettings.afkIdleSeconds, 15, 600) * 20;
}
function getPlayerRaidUsage(playerId) {
  const existing = playerRaidWindowUsage.get(playerId);
  if (!existing) {
    const fresh = { count: 0, windowStartTick: system.currentTick };
    playerRaidWindowUsage.set(playerId, fresh);
    return fresh;
  }
  if (system.currentTick - existing.windowStartTick >= RAID_COUNTER_WINDOW_TICKS) {
    const reset = { count: 0, windowStartTick: system.currentTick };
    playerRaidWindowUsage.set(playerId, reset);
    return reset;
  }
  return existing;
}
function incrementPlayerRaidUsage(playerId) {
  const usage = getPlayerRaidUsage(playerId);
  usage.count++;
  playerRaidWindowUsage.set(playerId, usage);
}
function getHeldLockpickRepairCost(player, settings) {
  const equip = player.getComponent("minecraft:equippable");
  const mainhand = equip?.getEquipment(EquipmentSlot.Mainhand);
  const tierConfig = mainhand ? getLockpickTier(mainhand.typeId) : null;
  if (!tierConfig) return null;
  const durability = mainhand.getComponent("minecraft:durability");
  if (!durability || !durability.maxDurability || (durability.damage ?? 0) <= 0) return null;
  const ratio = (durability.damage ?? 0) / durability.maxDurability;
  const baseCost = getRaidTierMoneyCost(settings, tierConfig.tier);
  return {
    tierConfig,
    cost: Math.max(1, Math.round(baseCost * (settings.repairCostPercent / 100) * ratio))
  };
}
function isAdmin(player) {
  return player.hasTag("plotadmin");
}
function isInsidePlot(plot, x, y, z) {
  const { minX, maxX, minZ, maxZ } = getPlotBounds(plot);
  return x >= minX && x <= maxX && z >= minZ && z <= maxZ;
}
function getPlotAtLocation(plots, x, y, z) {
  return plots.find((p) => isInsidePlot(p, x, y, z));
}
function isPlayerInsidePlot(player, plot) {
  const loc = player.location;
  return isInsidePlot(plot, Math.floor(loc.x), Math.floor(loc.y), Math.floor(loc.z));
}
function canUsePlotLockFeature(player, plot) {
  return plot.hasProtectionUpgrade || isPlayerInsidePlot(player, plot);
}
function resetPlotToUnownedState(plot) {
  plot.ownerId = null;
  plot.ownerName = null;
  plot.locked = false;
  plot.isPublic = true;
  plot.members = [];
  plot.memberSlotUpgrade = 0;
  plot.hasProtectionUpgrade = false;
  plot.hasContainerShieldUpgrade = false;
  plot.lastOwnerActivity = 0;
  plot.breachedUntil = 0;
  plot.breachedBy = null;
  plot.breachedById = null;
  plot.lastRaidedTick = 0;
  plot.containerShieldUntil = 0;
  plot.lockStrengthTier = 0;
  plot.alarmUpgradeTier = 0;
  plot.reinforcedContainerTier = 0;
}
function collectPreservedPlotBlocks(plot, dimension, startY) {
  const preserved = [];
  const preserveSet = new Set(PLOT_RESET_PRESERVE_BLOCKS);
  const { minX, maxX, minZ, maxZ } = getPlotBounds(plot);
  for (let x = minX; x <= maxX; x++) {
    for (let z = minZ; z <= maxZ; z++) {
      for (let y = startY; y <= PLOT_WORLD_MAX_Y; y++) {
        const block = dimension.getBlock({ x, y, z });
        if (!block) continue;
        if (!preserveSet.has(block.typeId)) continue;
        preserved.push({
          x,
          y,
          z,
          permutation: block.permutation,
          typeId: block.typeId
        });
      }
    }
  }
  return preserved;
}
function restorePreservedPlotBlocks(dimension, preservedBlocks) {
  for (const entry of preservedBlocks) {
    try {
      const block = dimension.getBlock({ x: entry.x, y: entry.y, z: entry.z });
      if (!block) continue;
      if (entry.permutation && typeof block.setPermutation === "function") {
        block.setPermutation(entry.permutation);
      } else {
        block.setType(entry.typeId);
      }
    } catch {
      try {
        dimension.runCommand(`setblock ${entry.x} ${entry.y} ${entry.z} ${entry.typeId}`);
      } catch {
      }
    }
  }
}
function clearPlotAboveGround(plot) {
  const dimension = world.getDimension("overworld");
  const { minX, maxX, minZ, maxZ } = getPlotBounds(plot);
  const startY = plotReferenceY(plot);
  if (startY > PLOT_WORLD_MAX_Y) return;
  const preservedBlocks = collectPreservedPlotBlocks(plot, dimension, startY);
  for (let x = minX; x <= maxX; x += PLOT_CLEAR_CHUNK_SIZE_X) {
    const xEnd = Math.min(x + PLOT_CLEAR_CHUNK_SIZE_X - 1, maxX);
    for (let z = minZ; z <= maxZ; z += PLOT_CLEAR_CHUNK_SIZE_Z) {
      const zEnd = Math.min(z + PLOT_CLEAR_CHUNK_SIZE_Z - 1, maxZ);
      for (let y = startY; y <= PLOT_WORLD_MAX_Y; y += PLOT_CLEAR_CHUNK_SIZE_Y) {
        const yEnd = Math.min(y + PLOT_CLEAR_CHUNK_SIZE_Y - 1, PLOT_WORLD_MAX_Y);
        try {
          dimension.runCommand(`fill ${x} ${y} ${z} ${xEnd} ${yEnd} ${zEnd} air [] replace`);
        } catch {
        }
      }
    }
  }
  restorePreservedPlotBlocks(dimension, preservedBlocks);
}
function getWorldSpawnTeleportLocation() {
  return {
    x: REBIRTH_SPAWN_LOCATION.x + 0.5,
    y: REBIRTH_SPAWN_LOCATION.y,
    z: REBIRTH_SPAWN_LOCATION.z + 0.5
  };
}
function runUnifiedRebirthReset(player, reason, incrementRebirth) {
  player.addTag(GENERATOR_REBIRTH_SYNC_TAG);
  const data = loadEconomyData(player.id);
  const currentBalance = getBalance(player.id);
  clearPlayerInventoryAndEnderChest(player);
  setBalance(player.id, 0);
  data.totalSpent += Math.max(0, currentBalance);
  data.multiplierLevel = 0;
  if (incrementRebirth) {
    data.rebirths = Math.min(ECONOMY_MAX_REBIRTHS, data.rebirths + 1);
  }
  saveEconomyData(player.id, data);
  syncEconomyScoreboards(player);
  const plots = loadPlots();
  let changed = false;
  let clearedPlotCount = 0;
  for (const plot of plots) {
    if (plot.ownerId !== player.id) continue;
    clearPlotAboveGround(plot);
    resetPlotToUnownedState(plot);
    addAccessLog(plot, player.name, reason);
    changed = true;
    clearedPlotCount++;
  }
  if (changed) savePlots(plots);
  playerPlotPresence.delete(player.id);
  teleportCooldowns.delete(player.id);
  lockedEntryWarnings.delete(player.id);
  const spawnLocation = getWorldSpawnTeleportLocation();
  player.teleport(spawnLocation, { dimension: world.getDimension("overworld") });
  ensurePlayerTools(player);
  return {
    data,
    clearedPlotCount
  };
}
function resetPlayerForFirstPrestige(player) {
  const { clearedPlotCount } = runUnifiedRebirthReset(player, "prestige 1 reset", false);
  player.sendMessage(
    `\xA75Prestige ${PRESTIGE_FIRST_LEVEL}/${PRESTIGE_TOTAL_LEVELS} unlocked! \xA7fYour reset is complete: \xA7cinventory cleared\xA7f, \xA7dender chest cleared\xA7f, \xA76${clearedPlotCount} plot(s) cleared and removed\xA7f, \xA72Money\xA7f reset to \xA720\xA7f, \xA7bskygen_mul\xA7f reset to \xA7b0\xA7f, and you were sent to world spawn.`
  );
}
function playFeatureLockedSound(player) {
  playSoundForPlayer(player, "mob.villager.no", { volume: 1.1, pitch: 0.55 });
}
function showPlotLockUpgradeRequired(player, onClose) {
  playFeatureLockedSound(player);
  const form = new MessageFormData().title("\xA7cPlot Lock Upgrade Required").body("\xA7cYou have not unlocked this feature! Go to upgrades and buy it!").button1("\xA7cOK").button2("\xA7cOK");
  form.show(player).then(() => {
    onClose?.();
  });
}
function getPlotHelpText(player) {
  const ownedPlot = getPrimaryOwnedPlot(loadPlots(), player.id);
  const settings = loadRaidSettings();
  const defenseSettings = loadDefenseSettings();
  return `\xA7fWelcome to \xA76Plot Manager\xA7f!

\xA76Menu Categories
\xA7f\u2022 \xA76Plot Management\xA7f handles locks, members, and owned plots.
\xA7f\u2022 \xA72Plot Shop / Buy & Sell\xA7f handles purchases, sales, and upgrades.
\xA7f\u2022 \xA74Raid Tools Shop\xA7f lets players buy and repair lockpicks.
\xA7f\u2022 \xA7bTravel & QoL\xA7f gives teleport, visit, safe unstuck, and tool refresh options.

\xA76Protection Tips
\xA7f\u2022 Locked-plot checks update fast to stop accidental step-ins.
\xA7f\u2022 Blocked players are moved toward a safer top surface when possible.
\xA7f\u2022 Plot protection covers the full world height: \xA7b${plotVerticalCoverageText()}\xA7f.
\xA7f\u2022 Ownership is limited to \xA76one plot at a time\xA7f${ownedPlot ? ` \xA78(current: \xA76${ownedPlot.id}\xA78)` : ""}.
\xA7f\u2022 Your money uses the \xA72Money\xA7f scoreboard: \xA72$${getBalance(player.id)}\xA7f.

\xA74Lockpick Raid System
\xA7f\u2022 Buy lockpicks (3 tiers) from the \xA74Raid Tools Shop\xA7f.
\xA7f\u2022 Night only: ${settings.nightOnly ? "\xA72On" : "\xA74Off"}\xA7f | Owner online: ${settings.requireOwnerOnline ? "\xA72On" : "\xA74Off"}\xA7f.
\xA7f\u2022 Movement cancel: ${settings.movementCancels ? "\xA72On" : "\xA74Off"}\xA7f | Player cooldown: \xA7e${settings.playerCooldownSeconds}s\xA7f.
\xA7f\u2022 Breach window: \xA74${settings.breachDurationSeconds}s\xA7f | Plot cooldown: \xA7e${settings.plotCooldownMinutes}m\xA7f.
\xA7f\u2022 \xA75Container Shield\xA7f upgrade blocks container access for 30s during raids.
\xA7f\u2022 Entry rule: \xA76${getEntryModeLabel(settings.entryMode)}\xA7f | Broadcasts: ${settings.broadcastOnBreach ? "\xA72On" : "\xA74Off"}\xA7f.

\xA75Plot Defense Upgrades
\xA7f\u2022 Lock Strength adds \xA7e+${defenseSettings.lockStrengthExtraSeconds[0]}/+${defenseSettings.lockStrengthExtraSeconds[1]}/+${defenseSettings.lockStrengthExtraSeconds[2]}s\xA7f and \xA7c-${defenseSettings.lockStrengthSuccessPenaltyPercent[0]}/-${defenseSettings.lockStrengthSuccessPenaltyPercent[1]}/-${defenseSettings.lockStrengthSuccessPenaltyPercent[2]}%\xA7f to lockpicks.
\xA7f\u2022 Alarm Upgrade buffs defenders for \xA7e${defenseSettings.alarmDurationsSeconds[0]}/${defenseSettings.alarmDurationsSeconds[1]}/${defenseSettings.alarmDurationsSeconds[2]}s\xA7f when lockpicking starts.${defenseSettings.alarmPulseOnTier3Breach ? ` Tier 3 also refreshes buffs for \xA7e${defenseSettings.alarmTier3BreachPulseSeconds}s\xA7f on breach.` : ""}
\xA7f\u2022 Reinforced Containers add \xA73${defenseSettings.reinforcedContainerDelaySeconds[0]}/${defenseSettings.reinforcedContainerDelaySeconds[1]}/${defenseSettings.reinforcedContainerDelaySeconds[2]}s\xA7f loot delay during raids.
\xA7f\u2022 Upkeep is \xA76${defenseSettings.upkeepPercentOfBalance}%\xA7f of your tracked balance every \xA7e${getUpkeepIntervalLabel(defenseSettings)}\xA7f while online.

\xA7f\u2022 Use the \xA71Help\xA7f button in the main menu any time to open this guide again.`;
}
function openPlotHelpMenu(player, onClose) {
  const form = new MessageFormData().title("\xA76Plot Manager Help").body(getPlotHelpText(player)).button1("\xA72Got It").button2("\xA71Open Plot Menu");
  form.show(player).then((res) => {
    if (res.selection === 1) {
      openMainMenu(player);
      return;
    }
    onClose?.();
  }).catch(() => {
    onClose?.();
  });
}
function showNewPlayerWelcome(player) {
  player.sendMessage("\xA76Welcome to Plotshop Star! \xA78Use your \xA76Plot Manager\xA78 tool in slot 1 to manage plots.");
  player.sendMessage("\xA78Need help? Open the Plot Manager and press the \xA71Help\xA78 button any time.");
  openPlotHelpMenu(player);
}
function isPlayerNearPlot(player, plot, range) {
  const minX = Math.min(plot.x1, plot.x2);
  const maxX = Math.max(plot.x1, plot.x2);
  const minZ = Math.min(plot.z1, plot.z2);
  const maxZ = Math.max(plot.z1, plot.z2);
  const closestX = Math.max(minX, Math.min(player.location.x, maxX));
  const closestZ = Math.max(minZ, Math.min(player.location.z, maxZ));
  const dx = player.location.x - closestX;
  const dz = player.location.z - closestZ;
  return dx * dx + dz * dz <= range * range;
}
function spawnPlotStatusParticle(dimension, effect, x, y, z) {
  try {
    dimension.runCommand(`particle ${effect} ${x.toFixed(2)} ${y.toFixed(2)} ${z.toFixed(2)}`);
  } catch {
  }
}
function getBlockTypeId(dimension, x, y, z) {
  try {
    return dimension.getBlock({ x, y, z })?.typeId ?? null;
  } catch {
    return null;
  }
}
function isAirLikeBlock(typeId) {
  return typeId === "minecraft:air" || typeId === "minecraft:cave_air" || typeId === "minecraft:void_air";
}
function isUnsafeFloorBlock(typeId) {
  if (!typeId || isAirLikeBlock(typeId)) return true;
  return typeId.includes("water") || typeId.includes("lava") || typeId.includes("fire") || typeId.includes("cactus") || typeId.includes("berry") || typeId.includes("powder_snow");
}
function findHighestSafeYAtColumn(dimension, x, z) {
  for (let y = PLOT_WORLD_MAX_Y - 1; y >= PLOT_WORLD_MIN_Y + 1; y--) {
    const floorBlock = getBlockTypeId(dimension, x, y - 1, z);
    const feetBlock = getBlockTypeId(dimension, x, y, z);
    const headBlock = getBlockTypeId(dimension, x, y + 1, z);
    if (isUnsafeFloorBlock(floorBlock)) continue;
    if (!isAirLikeBlock(feetBlock) || !isAirLikeBlock(headBlock)) continue;
    return y;
  }
  return null;
}
function buildColumnSearch(centerX, centerZ, radius, isValid) {
  const columns = [];
  const seen = /* @__PURE__ */ new Set();
  const addColumn = (x, z) => {
    const key = `${x}:${z}`;
    if (seen.has(key)) return;
    if (isValid && !isValid(x, z)) return;
    seen.add(key);
    columns.push({ x, z });
  };
  addColumn(centerX, centerZ);
  for (let ring = 1; ring <= radius; ring++) {
    for (let dx = -ring; dx <= ring; dx++) {
      for (let dz = -ring; dz <= ring; dz++) {
        if (Math.max(Math.abs(dx), Math.abs(dz)) !== ring) continue;
        addColumn(centerX + dx, centerZ + dz);
      }
    }
  }
  return columns;
}
function findSafeLocationForColumns(dimension, columns) {
  for (const column of columns) {
    const safeY = findHighestSafeYAtColumn(dimension, column.x, column.z);
    if (safeY === null) continue;
    return { x: column.x + 0.5, y: safeY, z: column.z + 0.5 };
  }
  return null;
}
function findSafeTeleportLocationInPlot(player, plot) {
  const minX = Math.min(plot.x1, plot.x2);
  const maxX = Math.max(plot.x1, plot.x2);
  const minZ = Math.min(plot.z1, plot.z2);
  const maxZ = Math.max(plot.z1, plot.z2);
  const centerX = Math.floor((minX + maxX) / 2);
  const centerZ = Math.floor((minZ + maxZ) / 2);
  const radius = Math.max(Math.ceil((maxX - minX) / 2), Math.ceil((maxZ - minZ) / 2));
  const columns = buildColumnSearch(centerX, centerZ, radius, (x, z) => x >= minX && x <= maxX && z >= minZ && z <= maxZ);
  const safeLocation = findSafeLocationForColumns(player.dimension, columns);
  if (safeLocation) return safeLocation;
  const center = plotCenter(plot);
  return {
    x: center.x + 0.5,
    y: Math.max(PLOT_WORLD_MIN_Y + 1, center.y),
    z: center.z + 0.5
  };
}
function findSafeEjectLocation(player, plot) {
  const minX = Math.min(plot.x1, plot.x2);
  const maxX = Math.max(plot.x1, plot.x2);
  const minZ = Math.min(plot.z1, plot.z2);
  const maxZ = Math.max(plot.z1, plot.z2);
  const playerX = Math.floor(player.location.x);
  const playerZ = Math.floor(player.location.z);
  const clampedX = clampNumber(playerX, minX, maxX);
  const clampedZ = clampNumber(playerZ, minZ, maxZ);
  const candidates = [];
  for (let offset = 1; offset <= SAFE_EJECT_SEARCH_DISTANCE; offset++) {
    candidates.push({ x: minX - offset, z: clampedZ });
    candidates.push({ x: maxX + offset, z: clampedZ });
    candidates.push({ x: clampedX, z: minZ - offset });
    candidates.push({ x: clampedX, z: maxZ + offset });
    candidates.push({ x: minX - offset, z: minZ - offset });
    candidates.push({ x: minX - offset, z: maxZ + offset });
    candidates.push({ x: maxX + offset, z: minZ - offset });
    candidates.push({ x: maxX + offset, z: maxZ + offset });
  }
  candidates.sort((a, b) => {
    const aDx = player.location.x - (a.x + 0.5);
    const aDz = player.location.z - (a.z + 0.5);
    const bDx = player.location.x - (b.x + 0.5);
    const bDz = player.location.z - (b.z + 0.5);
    return aDx * aDx + aDz * aDz - (bDx * bDx + bDz * bDz);
  });
  const directSafeLocation = findSafeLocationForColumns(player.dimension, candidates);
  if (directSafeLocation) return directSafeLocation;
  const fallbackColumns = buildColumnSearch(playerX, playerZ, SAFE_LOCATION_SEARCH_RADIUS + SAFE_EJECT_SEARCH_DISTANCE, (x, z) => {
    const withinExpandedBounds = x >= minX - SAFE_EJECT_SEARCH_DISTANCE && x <= maxX + SAFE_EJECT_SEARCH_DISTANCE && z >= minZ - SAFE_EJECT_SEARCH_DISTANCE && z <= maxZ + SAFE_EJECT_SEARCH_DISTANCE;
    return withinExpandedBounds && !isInsidePlot(plot, x, plotReferenceY(plot), z);
  });
  return findSafeLocationForColumns(player.dimension, fallbackColumns);
}
function isBorderBlock(typeId) {
  return !!typeId && typeId.includes(BORDER_BLOCK_KEYWORD);
}
function hasBorderBlockNearColumn(dimension, x, y, z) {
  const checks = [
    { x, y: y - 1, z },
    { x, y, z },
    { x, y: y + 1, z },
    { x: x + 1, y, z },
    { x: x - 1, y, z },
    { x, y, z: z + 1 },
    { x, y, z: z - 1 },
    { x: x + 1, y: y + 1, z },
    { x: x - 1, y: y + 1, z },
    { x, y: y + 1, z: z + 1 },
    { x, y: y + 1, z: z - 1 }
  ];
  return checks.some((loc) => isBorderBlock(getBlockTypeId(dimension, loc.x, loc.y, loc.z)));
}
function isPlotSideBlockedByBorderBlock(dimension, plot, side) {
  const { minX, maxX, minZ, maxZ } = getPlotBounds(plot);
  const yStart = Math.max(PLOT_WORLD_MIN_Y + 1, plotReferenceY(plot));
  const yEnd = Math.min(PLOT_WORLD_MAX_Y - 1, yStart + 4);
  const step = Math.max(1, Math.floor(Math.max(maxX - minX, maxZ - minZ) / 8));
  for (let y = yStart; y <= yEnd; y++) {
    if (side === "north" || side === "south") {
      const z = side === "north" ? minZ - 1 : maxZ + 1;
      for (let x = minX; x <= maxX; x += step) {
        if (isBorderBlock(getBlockTypeId(dimension, x, y, z))) return true;
      }
      if (isBorderBlock(getBlockTypeId(dimension, maxX, y, z))) return true;
    } else {
      const x = side === "west" ? minX - 1 : maxX + 1;
      for (let z = minZ; z <= maxZ; z += step) {
        if (isBorderBlock(getBlockTypeId(dimension, x, y, z))) return true;
      }
      if (isBorderBlock(getBlockTypeId(dimension, x, y, maxZ))) return true;
    }
  }
  return false;
}
function getNearestOutsideSide(plot, x, z) {
  const { minX, maxX, minZ, maxZ } = getPlotBounds(plot);
  const distances = [
    { side: "south", distance: Math.abs(z - (maxZ + 1)) },
    { side: "west", distance: Math.abs(x - (minX - 1)) },
    { side: "north", distance: Math.abs(z - (minZ - 1)) },
    { side: "east", distance: Math.abs(x - (maxX + 1)) }
  ];
  distances.sort((a, b) => a.distance - b.distance);
  return distances[0].side;
}
function buildColumnsForPlotSide(plot, side, targetX, targetZ, distance) {
  const { minX, maxX, minZ, maxZ } = getPlotBounds(plot);
  const columns = [];
  if (side === "north" || side === "south") {
    const z = side === "north" ? minZ - distance : maxZ + distance;
    for (let x = minX; x <= maxX; x++) columns.push({ x, z });
  } else {
    const x = side === "west" ? minX - distance : maxX + distance;
    for (let z = minZ; z <= maxZ; z++) columns.push({ x, z });
  }
  columns.sort((a, b) => {
    const adx = a.x + 0.5 - targetX;
    const adz = a.z + 0.5 - targetZ;
    const bdx = b.x + 0.5 - targetX;
    const bdz = b.z + 0.5 - targetZ;
    return adx * adx + adz * adz - (bdx * bdx + bdz * bdz);
  });
  return columns;
}
function isValidRaidExitColumn(dimension, plot, x, z, side) {
  if (isInsidePlot(plot, x, plotReferenceY(plot), z)) return false;
  if (side && isPlotSideBlockedByBorderBlock(dimension, plot, side)) return false;
  const safeY = findHighestSafeYAtColumn(dimension, x, z);
  if (safeY === null) return false;
  return !hasBorderBlockNearColumn(dimension, x, safeY, z);
}
function findNearestValidRaidExit(player, plot, preferred) {
  const dimension = player.dimension;
  if (preferred) {
    const px = Math.floor(preferred.x);
    const pz = Math.floor(preferred.z);
    const preferredSide = getNearestOutsideSide(plot, px, pz);
    const preferredColumns = buildColumnSearch(px, pz, 2, (x, z) => isValidRaidExitColumn(dimension, plot, x, z, preferredSide));
    const safePreferred = findSafeLocationForColumns(dimension, preferredColumns);
    if (safePreferred) return safePreferred;
  }
  const targetX = preferred?.x ?? player.location.x;
  const targetZ = preferred?.z ?? player.location.z;
  const sideOrder = ["south", "west", "north", "east"];
  if (preferred) {
    const preferredSide = getNearestOutsideSide(plot, Math.floor(preferred.x), Math.floor(preferred.z));
    sideOrder.sort((a, b) => (a === preferredSide ? -1 : 0) - (b === preferredSide ? -1 : 0));
  }
  for (const side of sideOrder) {
    if (isPlotSideBlockedByBorderBlock(dimension, plot, side)) continue;
    for (let distance = 1; distance <= SAFE_EJECT_SEARCH_DISTANCE + 4; distance++) {
      const columns = buildColumnsForPlotSide(plot, side, targetX, targetZ, distance).filter((column) => isValidRaidExitColumn(dimension, plot, column.x, column.z, side));
      const safe = findSafeLocationForColumns(dimension, columns);
      if (safe) return safe;
    }
  }
  const fallbackColumns = buildColumnSearch(Math.floor(targetX), Math.floor(targetZ), SAFE_LOCATION_SEARCH_RADIUS + SAFE_EJECT_SEARCH_DISTANCE + 6, (x, z) => {
    if (isInsidePlot(plot, x, plotReferenceY(plot), z)) return false;
    const side = getNearestOutsideSide(plot, x, z);
    return isValidRaidExitColumn(dimension, plot, x, z, side);
  });
  return findSafeLocationForColumns(dimension, fallbackColumns);
}
function getRaidEntryKey(playerId, plotId) {
  return `${playerId}|${plotId}`;
}
function rememberRaidEntryPoint(player, plot) {
  if (getPlayerRole(plot, player.id) !== null || !isRaidEntryAllowed(plot, player.id)) return;
  const key = getRaidEntryKey(player.id, plot.id);
  if (raidEntryPoints.has(key)) return;
  const lastOutside = playerLastOutsidePlotLocations.get(player.id);
  const fallback = findNearestValidRaidExit(player, plot, lastOutside);
  const entry = lastOutside ?? fallback;
  if (!entry) return;
  raidEntryPoints.set(key, {
    playerId: player.id,
    plotId: plot.id,
    x: entry.x,
    y: entry.y,
    z: entry.z
  });
}
function teleportRaiderOutAfterRaid(player, plot) {
  const key = getRaidEntryKey(player.id, plot.id);
  const entryPoint = raidEntryPoints.get(key);
  const destination = findNearestValidRaidExit(player, plot, entryPoint ?? void 0);
  raidEntryPoints.delete(key);
  if (!destination) return false;
  player.teleport(destination, { dimension: player.dimension });
  playerPlotPresence.set(player.id, null);
  player.sendMessage(`\xA72\u2714 Raid ended. You were moved out of \xA7e${plot.id}\xA72.`);
  return true;
}
function ejectNonMembersAfterRaid(plot) {
  let moved = 0;
  for (const player of world.getAllPlayers()) {
    if (getPlayerRole(plot, player.id) !== null) continue;
    if (!isPlayerInsidePlot(player, plot)) continue;
    if (teleportRaiderOutAfterRaid(player, plot)) moved++;
  }
  return moved;
}
function warnLockedPlotEntry(player) {
  const lastWarningTick = lockedEntryWarnings.get(player.id) ?? -LOCKED_ENTRY_MESSAGE_COOLDOWN_TICKS;
  if (system.currentTick - lastWarningTick < LOCKED_ENTRY_MESSAGE_COOLDOWN_TICKS) return;
  lockedEntryWarnings.set(player.id, system.currentTick);
  player.sendMessage("\xA7c\u26A0 This plot is locked! You cannot enter.");
}
function renderPlotStatusBarrier(dimension, plot) {
  const minX = Math.min(plot.x1, plot.x2);
  const maxX = Math.max(plot.x1, plot.x2);
  const minZ = Math.min(plot.z1, plot.z2);
  const maxZ = Math.max(plot.z1, plot.z2);
  const baseY = plotReferenceY(plot);
  const particleId = plot.locked ? LOCKED_PLOT_PARTICLE : UNLOCKED_PLOT_PARTICLE;
  const spacing = plot.locked ? LOCKED_PLOT_PARTICLE_SPACING : UNLOCKED_PLOT_PARTICLE_SPACING;
  const heights = plot.locked ? LOCKED_PLOT_PARTICLE_HEIGHTS : UNLOCKED_PLOT_PARTICLE_HEIGHTS;
  const positions = /* @__PURE__ */ new Set();
  const addPosition = (x, z) => {
    positions.add(`${x}:${z}`);
  };
  for (let x = minX; x <= maxX; x += spacing) {
    addPosition(x, minZ);
    addPosition(x, maxZ);
  }
  for (let z = minZ; z <= maxZ; z += spacing) {
    addPosition(minX, z);
    addPosition(maxX, z);
  }
  addPosition(minX, minZ);
  addPosition(minX, maxZ);
  addPosition(maxX, minZ);
  addPosition(maxX, maxZ);
  for (const pos of positions) {
    const [xStr, zStr] = pos.split(":");
    const x = Number(xStr) + 0.5;
    const z = Number(zStr) + 0.5;
    for (const height of heights) {
      spawnPlotStatusParticle(dimension, particleId, x, baseY + height, z);
    }
  }
}
function getMaxMembers(plot) {
  return BASE_MEMBER_LIMIT + plot.memberSlotUpgrade;
}
function getPlayerRole(plot, playerId) {
  if (plot.ownerId === playerId) return "owner";
  const member = plot.members.find((m) => m.playerId === playerId);
  if (!member) return null;
  // expiresAt is stored as Date.now() ms timestamp (0 or null = permanent)
  if (member.expiresAt !== null && member.expiresAt !== 0 && Date.now() >= member.expiresAt) return null;
  return member.role;
}
function canBuild(plot, playerId) {
  const role = getPlayerRole(plot, playerId);
  return role === "owner" || role === "coowner" || role === "trusted";
}
function canInteract(plot, playerId) {
  const role = getPlayerRole(plot, playerId);
  return role === "owner" || role === "coowner" || role === "trusted";
}
function canManage(plot, playerId) {
  const role = getPlayerRole(plot, playerId);
  return role === "owner" || role === "coowner";
}
function canEnter(plot, playerId) {
  if (!plot.locked) return true;
  if (isRaidEntryAllowed(plot, playerId)) return true;
  const role = getPlayerRole(plot, playerId);
  return role !== null;
}
function addAccessLog(plot, playerName, action) {
  plot.accessLog.push({ playerName, action, tick: system.currentTick });
  if (plot.accessLog.length > MAX_ACCESS_LOG_ENTRIES) {
    plot.accessLog = plot.accessLog.slice(-MAX_ACCESS_LOG_ENTRIES);
  }
}
function cleanExpiredMembers(plot) {
  const now = Date.now();
  plot.members = plot.members.filter((m) => m.expiresAt === null || m.expiresAt === 0 || now < m.expiresAt);
}
function getLockpickTier(itemId) {
  return LOCKPICK_TIERS.find((t) => t.itemId === itemId) ?? null;
}
function isLockpickItem(itemId) {
  return LOCKPICK_TIERS.some((t) => t.itemId === itemId);
}
function isNightTime() {
  const overworld = world.getDimension("overworld");
  try {
    const timeOfDay = world.getTimeOfDay?.() ?? overworld.runCommand("time query daytime")?.statusMessage;
    if (typeof timeOfDay === "number") {
      return timeOfDay >= 13e3 && timeOfDay <= 23e3;
    }
  } catch {
  }
  try {
    const result = overworld.runCommand("time query daytime");
    const match = result?.statusMessage?.match?.(/(\d+)/);
    if (match) {
      const t = parseInt(match[1], 10);
      return t >= 13e3 && t <= 23e3;
    }
  } catch {
  }
  return false;
}
function isOwnerOnline(plot) {
  if (!plot.ownerId) return false;
  return world.getAllPlayers().some((p) => p.id === plot.ownerId);
}
function isPlotBreached(plot) {
  return plot.breachedUntil > 0 && system.currentTick < plot.breachedUntil;
}
function isPlotContainerShielded(plot) {
  return plot.containerShieldUntil > 0 && system.currentTick < plot.containerShieldUntil;
}
function isPlotOnRaidCooldown(plot) {
  const settings = loadRaidSettings();
  if (!settings.reRaidProtection) return false;
  const cooldownTicks = getRaidPlotCooldownTicks(settings);
  return cooldownTicks > 0 && plot.lastRaidedTick > 0 && system.currentTick - plot.lastRaidedTick < cooldownTicks;
}
function isPlayerOnLockpickCooldown(playerId) {
  const cd = playerLockpickCooldowns.get(playerId);
  if (cd === void 0) return false;
  if (system.currentTick >= cd) {
    playerLockpickCooldowns.delete(playerId);
    return false;
  }
  return true;
}
function getPlayerLockpickCooldownRemaining(playerId) {
  const cd = playerLockpickCooldowns.get(playerId);
  if (cd === void 0) return 0;
  return Math.max(0, Math.ceil((cd - system.currentTick) / 20));
}
function getPlotRaidCooldownRemaining(plot) {
  if (!isPlotOnRaidCooldown(plot)) return 0;
  const cooldownTicks = getRaidPlotCooldownTicks(loadRaidSettings());
  return Math.max(0, Math.ceil((plot.lastRaidedTick + cooldownTicks - system.currentTick) / 20));
}
function isGlobalRaidCooldownActive(settings) {
  const cooldownTicks = getRaidGlobalCooldownTicks(settings);
  return cooldownTicks > 0 && lastGlobalRaidTick > 0 && system.currentTick - lastGlobalRaidTick < cooldownTicks;
}
function getGlobalRaidCooldownRemaining(settings) {
  if (!isGlobalRaidCooldownActive(settings)) return 0;
  return Math.max(0, Math.ceil((lastGlobalRaidTick + getRaidGlobalCooldownTicks(settings) - system.currentTick) / 20));
}
function damageHeldLockpick(player) {
  const equip = player.getComponent("minecraft:equippable");
  if (!equip) return false;
  const mainhand = equip.getEquipment(EquipmentSlot.Mainhand);
  if (!mainhand || !isLockpickItem(mainhand.typeId)) return false;
  const durComp = mainhand.getComponent("minecraft:durability");
  if (!durComp) return false;
  const newDamage = (durComp.damage ?? 0) + 1;
  if (newDamage >= durComp.maxDurability) {
    equip.setEquipment(EquipmentSlot.Mainhand, void 0);
    player.sendMessage("\xA7c\u26A0 Your lockpick broke!");
    return true;
  }
  durComp.damage = newDamage;
  equip.setEquipment(EquipmentSlot.Mainhand, mainhand);
  return false;
}
function repairHeldLockpick(player) {
  const equip = player.getComponent("minecraft:equippable");
  if (!equip) return false;
  const mainhand = equip.getEquipment(EquipmentSlot.Mainhand);
  if (!mainhand || !isLockpickItem(mainhand.typeId)) return false;
  const durability = mainhand.getComponent("minecraft:durability");
  if (!durability) return false;
  durability.damage = 0;
  equip.setEquipment(EquipmentSlot.Mainhand, mainhand);
  return true;
}
function applyLockpickFailPenalty(player, settings) {
  if (settings.failPenaltyMode === "break_item" || settings.failPenaltyMode === "both") {
    damageHeldLockpick(player);
  }
  if (settings.failPenaltyMode === "cooldown" || settings.failPenaltyMode === "both") {
    playerLockpickCooldowns.set(player.id, system.currentTick + getRaidPlayerCooldownTicks(settings));
  }
}
function getHeldLockpickTier(player) {
  const equip = player.getComponent("minecraft:equippable");
  if (!equip) return null;
  const mainhand = equip.getEquipment(EquipmentSlot.Mainhand);
  if (!mainhand) return null;
  return getLockpickTier(mainhand.typeId);
}
function cancelLockpickSession(playerId, reason) {
  const session = activeLockpicks.get(playerId);
  if (!session) return;
  activeLockpicks.delete(playerId);
  const player = world.getAllPlayers().find((p) => p.id === playerId);
  if (player?.isValid) {
    player.sendMessage(`\xA7c\u26A0 Lockpicking cancelled: ${reason}`);
    playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.lockpick_fail", { volume: 0.8, pitch: 0.7 });
  }
}
function startLockpickSession(player, plot, tierConfig) {
  const settings = loadRaidSettings();
  const defenseSettings = loadDefenseSettings();
  const upkeepStates = loadDefenseUpkeepStates();
  const lockStrengthBonusSeconds = getLockStrengthTimeBonusSeconds(plot, defenseSettings, upkeepStates);
  const durationTicks = (getRaidTierPickTimeSeconds(settings, tierConfig.tier) + lockStrengthBonusSeconds) * 20;
  const session = {
    playerId: player.id,
    playerName: player.name,
    plotId: plot.id,
    tier: tierConfig.tier,
    startTick: system.currentTick,
    durationTicks,
    startX: player.location.x,
    startY: player.location.y,
    startZ: player.location.z,
    lastProgressTick: system.currentTick
  };
  activeLockpicks.set(player.id, session);
  player.sendMessage(`\xA76\u26A1 Lockpicking plot \xA7e${plot.id}\xA76... ${settings.movementCancels ? "Stay still" : "Keep the tool in hand"} for \xA7e${Math.ceil(durationTicks / 20)}s\xA76!`);
  if (settings.ownerAlertEnabled) {
    player.sendMessage(`\xA7c\u26A0 The owner has been alerted!`);
  }
  if (lockStrengthBonusSeconds > 0) {
    player.sendMessage(`\xA78Lock Strength active: \xA7c+${lockStrengthBonusSeconds}s\xA78 lockpick time.`);
  }
  playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.lockpick_attempt", { volume: 0.8, pitch: 1 });
  if (settings.ownerAlertEnabled && plot.ownerId) {
    const owner = world.getAllPlayers().find((p) => p.id === plot.ownerId);
    if (owner?.isValid) {
      owner.sendMessage(`\xA7c\u26A0 ${formatRaidMessage(settings.ownerAlertTemplate, plot, player.name)}`);
      playSoundForPlayer(owner, "mob.villager.no", { volume: 1.2, pitch: 0.5 });
    }
  }
  applyAlarmUpgradePulse(plot, "lockpick_start", player.name, defenseSettings, upkeepStates);
}
function completeLockpickSuccess(player, plot, tierConfig) {
  activeLockpicks.delete(player.id);
  const settings = loadRaidSettings();
  const defenseSettings = loadDefenseSettings();
  const upkeepStates = loadDefenseUpkeepStates();
  const raidDuration = clampNumber(settings.breachDurationSeconds, 30, 180) * 20;
  const plots = loadPlots();
  const target = plots.find((p) => p.id === plot.id);
  if (!target) return;
  target.breachedUntil = system.currentTick + raidDuration;
  target.breachedBy = player.name;
  target.breachedById = player.id;
  target.lastRaidedTick = system.currentTick;
  if (target.hasContainerShieldUpgrade) {
    target.containerShieldUntil = system.currentTick + CONTAINER_SHIELD_DURATION_TICKS;
  }
  addAccessLog(target, player.name, `breached (tier ${tierConfig.tier})`);
  savePlots(plots);
  playerLockpickCooldowns.set(player.id, system.currentTick + getRaidPlayerCooldownTicks(settings));
  lastGlobalRaidTick = system.currentTick;
  incrementPlayerRaidUsage(player.id);
  damageHeldLockpick(player);
  const raidSeconds = Math.ceil(raidDuration / 20);
  player.sendMessage(`\xA7a\u2714 Lockpick successful! Plot \xA7e${plot.id}\xA7a is breached for \xA7e${raidSeconds}s\xA7a!`);
  playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.lockpick_success", { volume: 1, pitch: 1.2 });
  if (settings.broadcastOnBreach) {
    const message = `\xA74\u2694 ${formatRaidMessage(settings.broadcastTemplate, target, player.name)} \xA78(${raidSeconds}s)`;
    for (const p of world.getAllPlayers()) {
      p.sendMessage(message);
    }
  }
  if (settings.ownerAlertEnabled && target.ownerId) {
    const owner = world.getAllPlayers().find((p) => p.id === target.ownerId);
    if (owner?.isValid) {
      owner.sendMessage(`\xA7c\u26A0 Your plot \xA7e${plot.id}\xA7c has been BREACHED by \xA7e${player.name}\xA7c! Defend it!`);
      if (target.hasContainerShieldUpgrade) {
        owner.sendMessage(`\xA76Container Shield active for \xA7e30 seconds\xA76!`);
      }
    }
  }
  applyAlarmUpgradePulse(target, "breach", player.name, defenseSettings, upkeepStates);
}
function completeLockpickFailure(player, plot, tierConfig) {
  activeLockpicks.delete(player.id);
  const settings = loadRaidSettings();
  applyLockpickFailPenalty(player, settings);
  player.sendMessage(`\xA7c\u2718 Lockpick failed! Penalty: \xA7e${getFailPenaltyLabel(settings.failPenaltyMode)}\xA7c.`);
  playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.lockpick_fail", { volume: 1, pitch: 0.6 });
  const plots = loadPlots();
  const target = plots.find((p) => p.id === plot.id);
  if (target) {
    addAccessLog(target, player.name, `failed lockpick (tier ${tierConfig.tier})`);
    savePlots(plots);
  }
}
function attemptLockpick(player) {
  const settings = loadRaidSettings();
  if (activeLockpicks.has(player.id)) {
    player.sendMessage("\xA7c\u26A0 You are already lockpicking!");
    return;
  }
  const tierConfig = getHeldLockpickTier(player);
  if (!tierConfig) {
    player.sendMessage("\xA7c\u26A0 You must hold a lockpick to use it!");
    return;
  }
  if (isPlayerOnLockpickCooldown(player.id)) {
    const remaining = getPlayerLockpickCooldownRemaining(player.id);
    player.sendMessage(`\xA7c\u26A0 Lockpick on cooldown! Wait \xA7e${remaining}s\xA7c.`);
    return;
  }
  if (isGlobalRaidCooldownActive(settings)) {
    player.sendMessage(`\xA7c\u26A0 Global raid cooldown active! Wait \xA7e${getGlobalRaidCooldownRemaining(settings)}s\xA7c.`);
    return;
  }
  if (settings.afkDetection && isPlayerAfk(player, settings)) {
    player.sendMessage("\xA7c\u26A0 AFK detection blocked this raid. Move around before using a lockpick.");
    return;
  }
  if (settings.maxRaidsPerPlayer > 0) {
    const usage = getPlayerRaidUsage(player.id);
    if (usage.count >= settings.maxRaidsPerPlayer) {
      player.sendMessage(`\xA7c\u26A0 You reached the max raids per player limit (\xA7e${settings.maxRaidsPerPlayer}\xA7c) for this world day.`);
      return;
    }
  }
  if (settings.nightOnly && !isNightTime()) {
    player.sendMessage("\xA7c\u26A0 Lockpicks can only be used at night!");
    return;
  }
  const plots = loadPlots();
  const fx = Math.floor(player.location.x);
  const fy = Math.floor(player.location.y);
  const fz = Math.floor(player.location.z);
  let nearestPlot = null;
  let nearestDist = Infinity;
  for (const p of plots) {
    if (!p.locked) continue;
    if (!p.ownerId) continue;
    if (isPlayerNearPlot(player, p, 5)) {
      const center = plotCenter(p);
      const dx = player.location.x - center.x;
      const dz = player.location.z - center.z;
      const dist = dx * dx + dz * dz;
      if (dist < nearestDist) {
        nearestDist = dist;
        nearestPlot = p;
      }
    }
  }
  if (!nearestPlot) {
    player.sendMessage("\xA7c\u26A0 No locked plots nearby! Move closer to a locked plot boundary.");
    return;
  }
  if (settings.requireOwnerOnline && !isOwnerOnline(nearestPlot)) {
    player.sendMessage("\xA7c\u26A0 The plot owner must be online to use a lockpick!");
    return;
  }
  const role = getPlayerRole(nearestPlot, player.id);
  if (role !== null) {
    player.sendMessage("\xA7c\u26A0 You cannot lockpick a plot you have access to!");
    return;
  }
  if (isPlotOnRaidCooldown(nearestPlot)) {
    const remaining = getPlotRaidCooldownRemaining(nearestPlot);
    player.sendMessage(`\xA7c\u26A0 This plot cannot be raided for another \xA7e${Math.ceil(remaining / 60)}m ${remaining % 60}s\xA7c.`);
    return;
  }
  if (isPlotBreached(nearestPlot)) {
    player.sendMessage("\xA7c\u26A0 This plot is already breached!");
    return;
  }
  startLockpickSession(player, nearestPlot, tierConfig);
}
system.runInterval(() => {
  if (activeLockpicks.size === 0) return;
  for (const [playerId, session] of activeLockpicks) {
    const player = world.getAllPlayers().find((p) => p.id === playerId);
    if (!player || !player.isValid) {
      activeLockpicks.delete(playerId);
      continue;
    }
    const heldTier = getHeldLockpickTier(player);
    if (!heldTier) {
      cancelLockpickSession(playerId, "You must keep the lockpick in your main hand!");
      continue;
    }
    const dx = player.location.x - session.startX;
    const dy = player.location.y - session.startY;
    const dz = player.location.z - session.startZ;
    const distSq = dx * dx + dy * dy + dz * dz;
    const settings = loadRaidSettings();
    if (settings.movementCancels && distSq > LOCKPICK_MOVEMENT_TOLERANCE * LOCKPICK_MOVEMENT_TOLERANCE) {
      cancelLockpickSession(playerId, "You moved! Stay still while lockpicking.");
      continue;
    }
    if (isInCombat(player)) {
      cancelLockpickSession(playerId, "You took damage!");
      continue;
    }
    const elapsed = system.currentTick - session.startTick;
    const progressInterval = 5 * 20;
    if (system.currentTick - session.lastProgressTick >= progressInterval) {
      session.lastProgressTick = system.currentTick;
      const remaining = Math.max(0, Math.ceil((session.durationTicks - elapsed) / 20));
      const percent = Math.min(100, Math.floor(elapsed / session.durationTicks * 100));
      player.sendMessage(`\xA76\u26A1 Lockpicking... \xA7e${percent}%\xA76 (\xA7e${remaining}s\xA76 remaining)`);
      try {
        playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.lockpick_attempt", { volume: 0.5, pitch: 1 + percent / 200 });
      } catch {
      }
    }
    if (elapsed >= session.durationTicks) {
      const plots = loadPlots();
      const targetPlot = plots.find((p) => p.id === session.plotId);
      if (!targetPlot || !targetPlot.locked) {
        cancelLockpickSession(playerId, "The plot is no longer locked!");
        continue;
      }
      const tierConfig = LOCKPICK_TIERS.find((t) => t.tier === session.tier);
      if (!tierConfig) {
        activeLockpicks.delete(playerId);
        continue;
      }
      const roll = Math.random();
      const defenseSettings = loadDefenseSettings();
      const upkeepStates = loadDefenseUpkeepStates();
      const successPenalty = getLockStrengthSuccessPenalty(targetPlot, defenseSettings, upkeepStates);
      const successChance = clampNumber(getRaidTierSuccessPercent(settings, tierConfig.tier) - successPenalty, 1, 100) / 100;
      if (roll < successChance) {
        completeLockpickSuccess(player, targetPlot, tierConfig);
      } else {
        completeLockpickFailure(player, targetPlot, tierConfig);
      }
    }
  }
}, LOCKPICK_CHECK_INTERVAL);
system.runInterval(() => {
  const plots = loadPlots();
  let changed = false;
  for (const p of plots) {
    if (p.breachedUntil > 0 && system.currentTick >= p.breachedUntil) {
      const ejectedCount = ejectNonMembersAfterRaid(p);
      p.breachedUntil = 0;
      p.breachedBy = null;
      p.breachedById = null;
      p.locked = true;
      addAccessLog(p, "System", "breach expired \u2014 plot relocked");
      if (ejectedCount > 0) addAccessLog(p, "System", `teleported ${ejectedCount} raider(s) out after raid`);
      changed = true;
      for (const player of world.getAllPlayers()) {
        player.sendMessage(`\xA72\u2714 Plot \xA7e${p.id}\xA72 raid window has ended. ${ejectedCount} raider(s) moved out. Plot is secured again.`);
      }
    }
    if (p.containerShieldUntil > 0 && system.currentTick >= p.containerShieldUntil) {
      p.containerShieldUntil = 0;
      changed = true;
    }
  }
  if (changed) savePlots(plots);
}, 20);
world.afterEvents.entityHurt.subscribe((event) => {
  if (event.hurtEntity instanceof Player) {
    const session = activeLockpicks.get(event.hurtEntity.id);
    if (session) {
      cancelLockpickSession(event.hurtEntity.id, "You took damage!");
    }
  }
});
world.beforeEvents.playerBreakBlock.subscribe((event) => {
  const player = event.player;
  if (isAdmin(player)) return;
  const raidSettings = loadRaidSettings();
  const plots = loadPlots();
  const loc = event.block.location;
  const plot = getPlotAtLocation(plots, loc.x, loc.y, loc.z);
  if (!plot) return;
  if (isRaidEntryAllowed(plot, player.id) && getPlayerRole(plot, player.id) === null) {
    if (raidSettings.keepCoreBlocksProtected && isProtectedRaidCoreBlock(event.block.typeId)) {
      event.cancel = true;
      system.run(() => player.sendMessage("\xA7c\u26A0 Core raid protection is enabled for this block."));
      return;
    }
    if (!raidSettings.blockBreakingDuringRaid) {
      event.cancel = true;
      system.run(() => player.sendMessage("\xA7c\u26A0 Block breaking is disabled during raids!"));
      return;
    }
    return;
  }
  if (plot.locked && getPlayerRole(plot, player.id) === null) {
    event.cancel = true;
    system.run(() => player.sendMessage("\xA7c\u26A0 This plot is protected!"));
    return;
  }
  if (!canBuild(plot, player.id)) {
    event.cancel = true;
    system.run(() => player.sendMessage("\xA7c\u26A0 You don't have build permission here!"));
  }
});
world.afterEvents.playerPlaceBlock.subscribe((event) => {
  const player = event.player;
  if (isAdmin(player)) return;
  const raidSettings = loadRaidSettings();
  const plots = loadPlots();
  const loc = event.block.location;
  const plot = getPlotAtLocation(plots, loc.x, loc.y, loc.z);
  if (!plot) return;
  let blocked = false;
  if (isRaidEntryAllowed(plot, player.id) && getPlayerRole(plot, player.id) === null) {
    if (raidSettings.keepCoreBlocksProtected && isProtectedRaidCoreBlock(event.block.typeId)) {
      blocked = true;
      player.sendMessage("\xA7c\u26A0 Core raid protection is enabled for this block.");
    } else if (!raidSettings.blockBreakingDuringRaid) {
      blocked = true;
      player.sendMessage("\xA7c\u26A0 Block placement is disabled during raids!");
    }
  } else if (plot.locked && getPlayerRole(plot, player.id) === null) {
    blocked = true;
    player.sendMessage("\xA7c\u26A0 This plot is protected!");
  } else if (!canBuild(plot, player.id)) {
    blocked = true;
    player.sendMessage("\xA7c\u26A0 You don't have build permission here!");
  }
  if (blocked) {
    try {
      const dim = player.dimension;
      dim.runCommand(`setblock ${loc.x} ${loc.y} ${loc.z} air destroy`);
    } catch {
    }
  }
});
world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
  const player = event.player;
  if (isAdmin(player)) return;
  const raidSettings = loadRaidSettings();
  const plots = loadPlots();
  const loc = event.block.location;
  const plot = getPlotAtLocation(plots, loc.x, loc.y, loc.z);
  if (!plot) return;
  const blockId = event.block.typeId;
  const isContainer = blockId.includes("chest") || blockId.includes("barrel") || blockId.includes("furnace") || blockId.includes("smoker") || blockId.includes("blast_furnace") || blockId.includes("hopper") || blockId.includes("dropper") || blockId.includes("dispenser") || blockId.includes("shulker") || blockId.includes("brewing");
  const isRedstone = blockId.includes("lever") || blockId.includes("button") || blockId.includes("repeater") || blockId.includes("comparator") || blockId.includes("daylight") || blockId.includes("pressure_plate") || blockId.includes("tripwire");
  if (isRaidEntryAllowed(plot, player.id) && getPlayerRole(plot, player.id) === null) {
    if (isContainer && !raidSettings.allowContainerAccessDuringRaid) {
      event.cancel = true;
      system.run(() => player.sendMessage("\xA7c\u26A0 Container access is disabled during raids!"));
      return;
    }
    if (isContainer && isPlotContainerShielded(plot)) {
      event.cancel = true;
      const shieldRemaining = Math.max(0, Math.ceil((plot.containerShieldUntil - system.currentTick) / 20));
      system.run(() => player.sendMessage(`\xA7c\u26A0 Containers are shielded for \xA7e${shieldRemaining}s\xA7c!`));
      return;
    }
    if (isContainer) {
      const defenseSettings = loadDefenseSettings();
      const upkeepStates = loadDefenseUpkeepStates();
      const delaySeconds = getReinforcedContainerDelaySeconds(plot, defenseSettings, upkeepStates);
      if (delaySeconds > 0) {
        const blockKey = `${loc.x}:${loc.y}:${loc.z}`;
        const pendingKey = getContainerDelayKey(player.id, plot.id, blockKey);
        const existing = pendingContainerOpenDelays.get(pendingKey);
        if (existing && system.currentTick >= existing.readyTick) {
          pendingContainerOpenDelays.delete(pendingKey);
          system.run(() => player.sendMessage(`\xA7a\u2714 Reinforced container delay cleared. Open it now!`));
          return;
        }
        event.cancel = true;
        if (!existing) {
          pendingContainerOpenDelays.set(pendingKey, {
            playerId: player.id,
            plotId: plot.id,
            blockKey,
            readyTick: system.currentTick + Math.round(delaySeconds * 20)
          });
          system.run(() => player.sendMessage(`\xA76Reinforced Container: hold pressure for \xA7e${delaySeconds.toFixed(delaySeconds % 1 === 0 ? 0 : 1)}s\xA76, then interact again.`));
        } else {
          const remainingSeconds = Math.max(0, Math.ceil((existing.readyTick - system.currentTick) / 20));
          system.run(() => player.sendMessage(`\xA76Reinforced Container: \xA7e${remainingSeconds}s\xA76 remaining before it opens.`));
        }
        return;
      }
    }
    return;
  }
  if (plot.locked && getPlayerRole(plot, player.id) === null) {
    event.cancel = true;
    system.run(() => player.sendMessage("\xA7c\u26A0 This plot is locked!"));
    return;
  }
  if (isContainer && !canInteract(plot, player.id)) {
    event.cancel = true;
    system.run(() => player.sendMessage("\xA7c\u26A0 You can't access containers here!"));
    return;
  }
  if (isRedstone && !canInteract(plot, player.id)) {
    event.cancel = true;
    system.run(() => player.sendMessage("\xA7c\u26A0 You can't use redstone here!"));
    return;
  }
  if (!canInteract(plot, player.id)) {
    event.cancel = true;
    system.run(() => player.sendMessage("\xA7c\u26A0 You don't have interaction permission here!"));
  }
});
world.beforeEvents.playerInteractWithEntity.subscribe((event) => {
  const player = event.player;
  if (isAdmin(player)) return;
  const plots = loadPlots();
  const loc = event.target.location;
  const plot = getPlotAtLocation(plots, Math.floor(loc.x), Math.floor(loc.y), Math.floor(loc.z));
  if (!plot) return;
  if (isRaidEntryAllowed(plot, player.id) && getPlayerRole(plot, player.id) === null) {
    return;
  }
  if (plot.locked && getPlayerRole(plot, player.id) === null) {
    event.cancel = true;
    system.run(() => player.sendMessage("\xA7c\u26A0 This plot is locked!"));
    return;
  }
  if (!canInteract(plot, player.id)) {
    event.cancel = true;
    system.run(() => player.sendMessage("\xA7c\u26A0 You can't interact with entities here!"));
  }
});
system.runInterval(() => {
  const plots = loadPlots();
  for (const player of world.getAllPlayers()) {
    if (isAdmin(player)) continue;
    const loc = player.location;
    const fx = Math.floor(loc.x);
    const fy = Math.floor(loc.y);
    const fz = Math.floor(loc.z);
    const currentPlot = getPlotAtLocation(plots, fx, fy, fz);
    const prevPlotId = playerPlotPresence.get(player.id) ?? null;
    const currentPlotId = currentPlot?.id ?? null;
    if (!currentPlot) {
      playerLastOutsidePlotLocations.set(player.id, { x: loc.x, y: loc.y, z: loc.z });
    }
    if (currentPlotId !== prevPlotId) {
      if (currentPlot) {
        if (!canEnter(currentPlot, player.id)) {
          const safeEjectLocation = findSafeEjectLocation(player, currentPlot);
          if (safeEjectLocation) {
            player.teleport(safeEjectLocation, { dimension: player.dimension });
          } else {
            const center = plotCenter(currentPlot);
            const dx = loc.x - center.x;
            const dz = loc.z - center.z;
            const dist = Math.sqrt(dx * dx + dz * dz);
            const pushX = dist > 0 ? dx / dist * 3 : 3;
            const pushZ = dist > 0 ? dz / dist * 3 : 3;
            player.teleport({
              x: loc.x + pushX,
              y: loc.y,
              z: loc.z + pushZ
            }, { dimension: player.dimension });
          }
          if (prevPlotId) {
            const exitPlots = loadPlots();
            const previousPlot = exitPlots.find((p) => p.id === prevPlotId);
            if (previousPlot) {
              addAccessLog(previousPlot, player.name, "exit");
              savePlots(exitPlots);
            }
          }
          playerPlotPresence.set(player.id, null);
          warnLockedPlotEntry(player);
          continue;
        }
        rememberRaidEntryPoint(player, currentPlot);
        const mPlots = loadPlots();
        const mPlot = mPlots.find((p) => p.id === currentPlot.id);
        if (mPlot) {
          addAccessLog(mPlot, player.name, "enter");
          savePlots(mPlots);
        }
        player.sendMessage(`\xA77Entering plot \xA7e${currentPlot.id}\xA77${currentPlot.ownerName ? ` (${currentPlot.ownerName})` : ""}`);
      }
      if (prevPlotId) {
        const mPlots = loadPlots();
        const mPlot = mPlots.find((p) => p.id === prevPlotId);
        if (mPlot) {
          addAccessLog(mPlot, player.name, "exit");
          savePlots(mPlots);
        }
        player.sendMessage(`\xA77Leaving plot \xA7e${prevPlotId}`);
      }
      playerPlotPresence.set(player.id, currentPlotId);
    }
  }
}, BOUNDARY_CHECK_INTERVAL);
world.afterEvents.playerLeave.subscribe((event) => {
  const playerId = event.playerId;
  const plots = loadPlots();
  let changed = false;
  for (const p of plots) {
    if (p.ownerId === playerId && !p.locked) {
      p.locked = true;
      addAccessLog(p, event.playerName, "auto-lock (logout)");
      changed = true;
    }
  }
  if (changed) savePlots(plots);
  combatTimestamps.delete(playerId);
  teleportCooldowns.delete(playerId);
  menuUseTimestamps.delete(playerId);
  playerPlotPresence.delete(playerId);
  lockedEntryWarnings.delete(playerId);
  pendingCreations.delete(playerId);
  pendingUnlocks.delete(playerId);
  activeLockpicks.delete(playerId);
  playerLockpickCooldowns.delete(playerId);
  lastKnownPlayerLocations.delete(playerId);
  playerLastActivityTicks.delete(playerId);
  playerLastOutsidePlotLocations.delete(playerId);
  for (const key of [...raidEntryPoints.keys()]) {
    if (key.startsWith(`${playerId}|`)) raidEntryPoints.delete(key);
  }
});
world.afterEvents.playerSpawn.subscribe((event) => {
  const player = event.player;
  system.runTimeout(() => {
    if (!player.isValid) return;
    ensurePlayerTools(player);
    warnLegacyMultiPlotOwnership(player);
    if (!player.hasTag(WELCOME_TAG)) {
      player.addTag(WELCOME_TAG);
      showNewPlayerWelcome(player);
    }
    const plots = loadPlots();
    let changed = false;
    for (const p of plots) {
      if (p.ownerId === player.id) {
        p.lastOwnerActivity = system.currentTick;
        changed = true;
      }
    }
    if (changed) savePlots(plots);
  }, 1);
  system.runTimeout(() => {
    if (!player.isValid) return;
    const plots = loadPlots();
    let changed = false;
    for (const p of plots) {
      if (p.ownerId === player.id && p.locked) {
        p.locked = false;
        addAccessLog(p, player.name, "auto-unlock (login)");
        changed = true;
      }
    }
    if (changed) {
      savePlots(plots);
      player.sendMessage("\xA7a\u2714 Your plots have been unlocked.");
    }
  }, DELAYED_UNLOCK_TICKS);
});
system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    const previous = lastKnownPlayerLocations.get(player.id);
    const current = {
      x: Math.floor(player.location.x * 10) / 10,
      y: Math.floor(player.location.y * 10) / 10,
      z: Math.floor(player.location.z * 10) / 10
    };
    if (!previous || previous.x !== current.x || previous.y !== current.y || previous.z !== current.z) {
      playerLastActivityTicks.set(player.id, system.currentTick);
      lastKnownPlayerLocations.set(player.id, current);
    } else if (!playerLastActivityTicks.has(player.id)) {
      playerLastActivityTicks.set(player.id, system.currentTick);
    }
  }
}, 20);
system.runInterval(() => {
  const plots = loadPlots();
  let changed = false;
  for (const p of plots) {
    const beforeLen = p.members.length;
    cleanExpiredMembers(p);
    if (p.members.length !== beforeLen) changed = true;
    if (p.ownerId && p.lastOwnerActivity > 0 && p.autoResetDays > 0) {
      const inactiveTicks = system.currentTick - p.lastOwnerActivity;
      const thresholdTicks = p.autoResetDays * 20 * 60 * 60 * 24;
      if (inactiveTicks >= thresholdTicks) {
        p.ownerId = null;
        p.ownerName = null;
        p.locked = false;
        p.members = [];
        p.hasProtectionUpgrade = false;
        p.hasContainerShieldUpgrade = false;
        p.memberSlotUpgrade = 0;
        p.lockStrengthTier = 0;
        p.alarmUpgradeTier = 0;
        p.reinforcedContainerTier = 0;
        addAccessLog(p, "System", "auto-reset (inactive)");
        changed = true;
      }
    }
  }
  if (changed) savePlots(plots);
}, 20 * 60 * 5);
system.runInterval(() => {
  const settings = loadDefenseSettings();
  const plots = loadPlots();
  const upkeepStates = loadDefenseUpkeepStates();
  let changed = false;
  const ownersWithDefense = /* @__PURE__ */ new Set();
  for (const plot of plots) {
    if (plot.ownerId && plotHasAnyDefenseUpgrade(plot)) {
      ownersWithDefense.add(plot.ownerId);
    }
  }
  for (const [playerId] of Object.entries(upkeepStates)) {
    if (!ownersWithDefense.has(playerId)) {
      delete upkeepStates[playerId];
      changed = true;
    }
  }
  const chargeInterval = Math.max(20, Math.round(settings.upkeepChargeIntervalTicks));
  for (const player of world.getAllPlayers()) {
    if (!ownersWithDefense.has(player.id)) continue;
    const existingState = upkeepStates[player.id];
    const state = existingState ?? {
      accruedOnlineTicks: 0,
      upgradesDisabled: false,
      lastChargeAmount: 0,
      chargeBaseBalance: getBalance(player.id)
    };
    const beforeState = JSON.stringify(state);
    state.chargeBaseBalance = Math.max(state.chargeBaseBalance, getBalance(player.id));
    state.accruedOnlineTicks += DEFENSE_UPKEEP_CHECK_INTERVAL_TICKS;
    while (state.accruedOnlineTicks >= chargeInterval) {
      state.accruedOnlineTicks -= chargeInterval;
      const chargeAmount = getDefenseUpkeepChargeAmount(player.id, settings, state.chargeBaseBalance);
      state.lastChargeAmount = chargeAmount;
      if (deductBalance(player.id, chargeAmount)) {
        const wasDisabled = state.upgradesDisabled;
        state.upgradesDisabled = false;
        player.sendMessage(
          chargeAmount > 0 ? `\xA76Defense upkeep paid: \xA72$${chargeAmount}\xA76. ${wasDisabled ? "Upgrades reactivated." : "Defenses remain active."}` : `\xA76Defense upkeep check passed. ${wasDisabled ? "Upgrades reactivated." : "No tax due this cycle."}`
        );
      } else {
        state.upgradesDisabled = true;
        player.sendMessage(`\xA7cDefense upkeep unpaid: need \xA7e$${chargeAmount}\xA7c. All defense upgrades are disabled until the next successful payment.`);
      }
      state.chargeBaseBalance = getBalance(player.id);
      changed = true;
    }
    upkeepStates[player.id] = state;
    if (!existingState || JSON.stringify(state) !== beforeState) {
      changed = true;
    }
  }
  if (changed) saveDefenseUpkeepStates(upkeepStates);
  for (const [key, pending] of pendingContainerOpenDelays) {
    if (system.currentTick - pending.readyTick > 100) {
      pendingContainerOpenDelays.delete(key);
    }
  }
}, DEFENSE_UPKEEP_CHECK_INTERVAL_TICKS);
function openSkygenEconomyMenu(player) {
  const data = loadEconomyData(player.id);
  const settings = loadEconomySettings();
  const multiplier = getEconomyMultiplier(data);
  const rebirthBonus = getEconomyRebirthBonus(data, settings);
  const form = new ActionFormData().title("Economy Menu").body(
    `\xA72Money: $${formatMoney(getBalance(player.id))}
\xA7bMultiplier: ${formatMultiplier(multiplier)}
\xA7dRebirth level: ${data.rebirths}
\xA76Current sell bonus: ${formatMultiplier(rebirthBonus)}
\xA78Final Earned = Base Value \xD7 Multiplier \xD7 Rebirth Bonus`
  );
  form.button("\xA72Sell All");
  form.button("\xA76Prices");
  form.button("\xA7bUpgrades");
  form.button("\xA7dRebirths");
  form.button("\xA7eStats");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    switch (res.selection) {
      case 0:
        attemptSellAll(player);
        break;
      case 1:
        openPricesMenu(player, 0);
        break;
      case 2:
        openMultiplierUpgradesMenu(player);
        break;
      case 3:
        openRebirthMenu(player);
        break;
      case 4:
        openEconomyStatsMenu(player);
        break;
      case 5:
        openEconomyCategory(player);
        break;
      default:
        openEconomyCategory(player);
        break;
    }
  });
}
function attemptSellAll(player) {
  const settings = loadEconomySettings();
  if (!canStartEconomyTransaction(player, "sell", "sell_all")) {
    player.sendMessage("\xA7cSell All is on cooldown. Please wait a moment.");
    return;
  }
  try {
    const result = runSellAllRemoval(player, settings);
    if (!result) {
      player.sendMessage("\xA7cSell All cancelled. Inventory data was missing or item removal failed.");
      return;
    }
    if (result.finalEarned <= 0) {
      const blockedLines = summarizeBlockedSellCounts(result.blockedCounts ?? /* @__PURE__ */ new Map());
      if (blockedLines.length > 0) {
        player.sendMessage(`\xA7cNo items could be sold right now. \xA77${blockedLines[0]}`);
      } else {
        player.sendMessage("\xA7cNo sellable Skygen items found in your inventory.");
      }
      openSkygenEconomyMenu(player);
      return;
    }
    rewardMoney(player, result.finalEarned);
    const data = loadEconomyData(player.id);
    const multiplier = getEconomyMultiplier(data);
    const rebirthBonus = getEconomyRebirthBonus(data, settings);
    player.sendMessage(
      `\xA72Sold items for: $${formatMoney(result.baseValue)}
\xA7bMultiplier: ${formatMultiplier(multiplier)}
\xA7dRebirth Bonus: ${formatMultiplier(rebirthBonus)}
\xA76Total Earned: $${formatMoney(result.finalEarned)}`
    );
    player.sendMessage(`\xA78${getSoldItemSummary(result.soldCounts, settings)}`);
    const blockedLines = summarizeBlockedSellCounts(result.blockedCounts ?? /* @__PURE__ */ new Map());
    for (const line of blockedLines.slice(0, 4)) {
      player.sendMessage(`\xA7cSkipped: \xA77${line}`);
    }
    playSoundForPlayer(player, settings.soundPurchase, { volume: 0.8, pitch: 1.2 });
  } finally {
    finishEconomyTransaction(player, "sell_all");
  }
}
function openPricesMenu(player, categoryIndex) {
  const settings = loadEconomySettings();
  const category = ECONOMY_CATEGORY_ORDER[categoryIndex] ?? ECONOMY_CATEGORY_ORDER[0];
  const items = settings.sellableItems.filter((item) => item.category === category && item.price > 0);
  let body = `\xA7fCategory: \xA76${category}
\xA7fUses the same price list as \xA72Sell All\xA7f.

`;
  body += items.length > 0 ? items.map((item) => `\xA7f${item.name}: \xA72$${formatMoney(item.price)}`).join("\n") : "\xA78No items in this category.";
  const form = new ActionFormData().title("\xA76Prices").body(body);
  form.button("\xA77\u25C0 Previous Category");
  form.button("\xA77Next Category \u25B6");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === 0) openPricesMenu(player, (categoryIndex - 1 + ECONOMY_CATEGORY_ORDER.length) % ECONOMY_CATEGORY_ORDER.length);
    else if (res.selection === 1) openPricesMenu(player, (categoryIndex + 1) % ECONOMY_CATEGORY_ORDER.length);
    else openSkygenEconomyMenu(player);
  });
}
function openMultiplierUpgradesMenu(player) {
  const data = loadEconomyData(player.id);
  const settings = loadEconomySettings();
  const currentMultiplier = getEconomyMultiplier(data);
  const nextLevel = data.multiplierLevel + 1;
  const maxed = nextLevel > ECONOMY_MULTIPLIER_MAX_LEVEL;
  const nextMultiplier = getEconomyMultiplier(nextLevel);
  const cost = maxed ? 0 : settings.multiplierCosts[nextLevel - 1];
  const form = new MessageFormData().title("\xA7bUpgrades").body(
    `\xA7fCurrent Multiplier: \xA7b${formatMultiplier(currentMultiplier)}
\xA7fMax Multiplier: \xA7b2.50x
\xA7fBalance: \xA72$${formatMoney(getBalance(player.id))}

` + (maxed ? "\xA72Your multiplier is maxed." : `\xA7fNext Upgrade: \xA7b${formatMultiplier(nextMultiplier)}
\xA7fCost: \xA72$${formatMoney(cost)}
\xA78Upgrades must be bought in order (+0.10x each).`)
  ).button1(maxed ? "\xA78Back" : "\xA72Buy Upgrade").button2("\xA78Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection !== 0 || maxed) {
      openSkygenEconomyMenu(player);
      return;
    }
    const freshData = loadEconomyData(player.id);
    if (freshData.multiplierLevel !== data.multiplierLevel) {
      openMultiplierUpgradesMenu(player);
      return;
    }
    const freshNextLevel = freshData.multiplierLevel + 1;
    const freshCost = settings.multiplierCosts[freshNextLevel - 1];
    if (!spendMoney(player, freshCost, "multiplier_upgrade", settings)) {
      openMultiplierUpgradesMenu(player);
      return;
    }
    freshData.multiplierLevel = freshNextLevel;
    saveEconomyData(player.id, freshData);
    syncEconomyScoreboards(player);
    player.sendMessage(`\xA7a${economyMessage(settings.messagePurchaseTemplate, { item: formatMultiplier(getEconomyMultiplier(freshData)), cost: formatMoney(freshCost) })}`);
    playSoundForPlayer(player, settings.soundPurchase, { volume: 1, pitch: 1.2 });
    openMultiplierUpgradesMenu(player);
  });
}
function openRebirthMenu(player) {
  const settings = loadEconomySettings();
  const data = loadEconomyData(player.id);
  const balance = getBalance(player.id);
  const atMaxRebirth = data.rebirths >= ECONOMY_MAX_REBIRTHS;
  const hasRequiredMultiplier = data.multiplierLevel >= ECONOMY_REBIRTH_REQUIRED_MULTIPLIER_LEVEL;
  const ownsPlot = getPrimaryOwnedPlot(loadPlots(), player.id) !== void 0;
  const canRebirth = !atMaxRebirth && balance >= settings.rebirthMoneyRequired && hasRequiredMultiplier && (!settings.rebirthRequiresPlot || ownsPlot);
  const form = new MessageFormData().title("\xA7dRebirths").body(
    `\xA7fRebirth Level: \xA7d${data.rebirths}/\xA7f${ECONOMY_MAX_REBIRTHS}
\xA7fPermanent Sell Bonus: \xA7d${formatMultiplier(getEconomyRebirthBonus(data, settings))}
\xA7fEach Rebirth Adds: \xA7d+${formatMultiplier(settings.rebirthBonusPerLevel)}

\xA7fMoney Required: \xA72$${formatMoney(settings.rebirthMoneyRequired)}
\xA7fMultiplier Required: \xA7b2.50x \xA78(${hasRequiredMultiplier ? "met" : "not met"})
\xA7fPlot Required: ${settings.rebirthRequiresPlot ? ownsPlot ? "\xA72Owned" : "\xA74Must own a plot" : "\xA78Off"}
\xA7fCap Status: ${atMaxRebirth ? "\xA74Max rebirth reached" : "\xA72Can still progress"}

\xA7cWarning: rebirth fully clears your inventory, ender chest, money, owned plots, and multiplier.
\xA7cPlots are wiped from the floor upward except the protected plot-base blocks you asked to keep.
\xA7cYou will be teleported to spawn after the reset.`
  ).button1(canRebirth ? "\xA7dRebirth" : atMaxRebirth ? "\xA74Max Rebirth" : "\xA78Requirements Missing").button2("\xA78Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection !== 0) {
      openSkygenEconomyMenu(player);
      return;
    }
    openRebirthConfirmMenu(player);
  });
}
function openRebirthConfirmMenu(player) {
  const form = new MessageFormData().title("\xA7cFinal Rebirth Warning").body(
    `\xA7cThis rebirth is destructive.
\xA7fIt will:
\xA77- clear your inventory
\xA77- clear your ender chest
\xA77- set your money to $0
\xA77- reset your multiplier to 1.00x
\xA77- wipe your owned plots from the floor and above
\xA77- remove ownership/upgrades and send you to spawn

\xA7eProtected plot-base blocks remain in place.`
  ).button1("\xA7cConfirm Rebirth").button2("\xA78Cancel");
  form.show(player).then((res) => {
    if (res.canceled || res.selection !== 0) {
      openRebirthMenu(player);
      return;
    }
    attemptRebirth(player);
  });
}
function attemptRebirth(player) {
  const settings = loadEconomySettings();
  const data = loadEconomyData(player.id);
  const balance = getBalance(player.id);
  if (data.rebirths >= ECONOMY_MAX_REBIRTHS) {
    player.sendMessage(`\xA7cYou are already at the max rebirth of \xA7d${ECONOMY_MAX_REBIRTHS}\xA7c.`);
    openRebirthMenu(player);
    return;
  }
  if (data.multiplierLevel < ECONOMY_REBIRTH_REQUIRED_MULTIPLIER_LEVEL) {
    player.sendMessage("\xA7cYou need the 2.50x multiplier before rebirthing.");
    openRebirthMenu(player);
    return;
  }
  if (settings.rebirthRequiresPlot && !getPrimaryOwnedPlot(loadPlots(), player.id)) {
    player.sendMessage("\xA7cYou must own a plot before rebirthing.");
    openRebirthMenu(player);
    return;
  }
  if (balance < settings.rebirthMoneyRequired) {
    showNeedMoreMoney(player, settings.rebirthMoneyRequired, settings);
    openRebirthMenu(player);
    return;
  }
  if (!canStartEconomyTransaction(player, "purchase", "rebirth")) {
    player.sendMessage("\xA7cRebirth is already processing. Please wait.");
    return;
  }
  try {
    if (getBalance(player.id) < settings.rebirthMoneyRequired) {
      showNeedMoreMoney(player, settings.rebirthMoneyRequired, settings);
      return;
    }
    const result = runUnifiedRebirthReset(player, "rebirth reset", true);
    player.sendMessage(`\xA7dRebirth complete! \xA7fLevel: \xA7d${result.data.rebirths}\xA7f | Permanent Sell Bonus: \xA7d${formatMultiplier(getEconomyRebirthBonus(result.data, settings))}\xA7f | \xA76${result.clearedPlotCount} plot(s)\xA7f reset, inventory cleared, ender chest cleared, and multiplier reset to \xA7b1.00x\xA7f.`);
    playSoundForPlayer(player, settings.soundPurchase, { volume: 1, pitch: 1.35 });
  } finally {
    finishEconomyTransaction(player, "rebirth");
  }
  openSkygenEconomyMenu(player);
}
function openEconomyStatsMenu(player) {
  const data = loadEconomyData(player.id);
  const settings = loadEconomySettings();
  const form = new MessageFormData().title("\xA7eStats").body(
    `\xA72Money: $${formatMoney(getBalance(player.id))}
\xA7bMultiplier Level: ${data.multiplierLevel}/${ECONOMY_MULTIPLIER_MAX_LEVEL}
\xA7bCurrent Multiplier: ${formatMultiplier(getEconomyMultiplier(data))}
\xA7dRebirth Count: ${data.rebirths}
\xA7dRebirth Bonus: ${formatMultiplier(getEconomyRebirthBonus(data, settings))}
\xA76Total Earned: $${formatMoney(data.totalEarned)}
\xA7cTotal Spent: $${formatMoney(data.totalSpent)}`
  ).button1("\xA78Back").button2("\xA78Back");
  form.show(player).then(() => openSkygenEconomyMenu(player));
}
function openMainMenu(player) {
  const isPlayerAdmin = isAdmin(player);
  const isGuiAdmin = isEconomyAdmin(player);
  const form = new ActionFormData().title("\xA76PlotShop").body(
    `\xA7fBalance: \xA72$${getBalance(player.id)}\xA7f
\xA7fChoose a clear category. Gameplay settings stay admin-owned; player settings are cosmetic only.`
  );
  form.button("\xA74Raiding");
  form.button("\xA75Defense Upgrades");
  form.button("\xA72Skygen Economy");
  form.button("\xA76Plot Shop / Buy & Sell");
  form.button("\xA71Settings");
  if (isPlayerAdmin) form.button("\xA74[Admin] Manage Plots");
  if (isGuiAdmin) form.button("\xA72[Admin] Economy Config");
  form.button("\xA78Exit");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    const actions = [
      () => openRaidingCategory(player),
      () => openDefenseUpgradesCategory(player),
      () => openSkygenEconomyMenu(player),
      () => openEconomyCategory(player),
      () => openSettingsMenu(player)
    ];
    if (isPlayerAdmin) actions.push(() => openAdminMenu(player));
    if (isGuiAdmin) actions.push(() => openAdminEconomySettings(player));
    const action = actions[res.selection];
    action?.();
  });
}
function openRaidingCategory(player) {
  const settings = loadRaidSettings();
  const form = new ActionFormData().title("\xA74Raiding").body(
    `\xA7fRaid tools and active raid info.
\xA7fWindow: \xA7e${settings.breachDurationSeconds}s\xA7f | Cooldown: \xA7e${settings.playerCooldownSeconds}s\xA7f
\xA7fEntry: \xA76${getEntryModeLabel(settings.entryMode)}\xA7f`
  );
  form.button("\xA74Raid Tools Shop");
  form.button("\xA76Raid Rules");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    switch (res.selection) {
      case 0:
        openLockpickShop(player);
        break;
      case 1:
        openPlotHelpMenu(player, () => openRaidingCategory(player));
        break;
      default:
        openMainMenu(player);
        break;
    }
  });
}
function openDefenseUpgradesCategory(player) {
  const form = new ActionFormData().title("\xA75Defense Upgrades").body("\xA7fLock, unlock, manage members, and buy defenses for your plot.");
  form.button("\xA75Upgrade Defenses");
  form.button("\xA74Lock Plot");
  form.button("\xA72Unlock Plot");
  form.button("\xA73Members");
  form.button("\xA76My Plot");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    switch (res.selection) {
      case 0:
        openUpgradesMenu(player);
        break;
      case 1:
        openLockMenu(player, true);
        break;
      case 2:
        openLockMenu(player, false);
        break;
      case 3:
        openMemberManagementMenu(player);
        break;
      case 4:
        openMyPlotMenu(player);
        break;
      default:
        openMainMenu(player);
        break;
    }
  });
}
function openEconomyCategory(player) {
  const form = new ActionFormData().title("\xA76Plot Shop / Buy & Sell").body(`\xA7fPlot costs and rewards use the economy balance.
\xA7fBalance: \xA72$${getBalance(player.id)}\xA7f`);
  form.button("\xA72Skygen Economy");
  form.button("\xA76Buy Plot");
  form.button("\xA74Sell Plot");
  form.button("\xA71Teleport");
  form.button("\xA71Visit Plots");
  form.button("\xA76Current Plot Info");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    switch (res.selection) {
      case 0:
        openSkygenEconomyMenu(player);
        break;
      case 1:
        openBuyMenu(player, 0);
        break;
      case 2:
        openSellMenu(player);
        break;
      case 3:
        openTeleportMenu(player);
        break;
      case 4:
        openVisitMenu(player, 0);
        break;
      case 5:
        openCurrentPlotInfo(player);
        break;
      default:
        openMainMenu(player);
        break;
    }
  });
}
function openSettingsMenu(player) {
  const soundsEnabled = arePersonalSoundsEnabled(player);
  const visualsEnabled = arePersonalVisualsEnabled(player);
  const form = new ActionFormData().title("\xA71Settings").body(
    `\xA7fPersonal cosmetic options only. These do not change raid, economy, plot, or server rules.

\xA7fSounds: ${soundsEnabled ? "\xA72On" : "\xA74Off"}\xA7f
\xA7fVisual Hints: ${visualsEnabled ? "\xA72On" : "\xA74Off"}\xA7f`
  );
  form.button(soundsEnabled ? "\xA74Disable Sounds" : "\xA72Enable Sounds");
  form.button(visualsEnabled ? "\xA74Hide Visual Hints" : "\xA72Show Visual Hints");
  form.button("\xA72Safe Unstuck");
  form.button("\xA73Refresh Tools");
  form.button("\xA71Help");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    switch (res.selection) {
      case 0:
        setPlayerBooleanPreference(player, PLAYER_SOUNDS_KEY, !soundsEnabled);
        player.sendMessage(`\xA7aPersonal sounds ${!soundsEnabled ? "enabled" : "disabled"}.`);
        openSettingsMenu(player);
        break;
      case 1:
        setPlayerBooleanPreference(player, PLAYER_VISUALS_KEY, !visualsEnabled);
        player.sendMessage(`\xA7aPersonal visual hints ${!visualsEnabled ? "shown" : "hidden"}.`);
        openSettingsMenu(player);
        break;
      case 2:
        safeUnstuckPlayer(player, openSettingsMenu);
        break;
      case 3:
        ensurePlayerTools(player);
        player.sendMessage("\xA7a\u2714 Your Plot Manager tools were refreshed.");
        openSettingsMenu(player);
        break;
      case 4:
        openPlotHelpMenu(player, () => openSettingsMenu(player));
        break;
      default:
        openMainMenu(player);
        break;
    }
  });
}
function openPlotShopCategory(player) {
  openEconomyCategory(player);
}
function openLockpickShop(player) {
  const settings = loadRaidSettings();
  const balance = getBalance(player.id);
  const repairInfo = settings.repairEnabled ? getHeldLockpickRepairCost(player, settings) : null;
  const ctokenBalance = getObjectiveBalance(player.id, CTOKEN_OBJECTIVE_ID, CTOKEN_OBJECTIVE_ID);
  let body = `\xA7fBalance: \xA72$${balance}\xA7f`;
  if (settings.useCTokensForTier2 || settings.useCTokensForTier3) {
    body += `
\xA7fCTokens: \xA7b${ctokenBalance}\xA7f`;
  }
  body += `

\xA7fCompact raid tools shop. Pick a tier to buy it.`;
  if (repairInfo) {
    body += `
\xA76Held Repair: ${getRaidTierDisplayName(repairInfo.tierConfig.tier)} \xA78for \xA72$${formatCompactCurrency(repairInfo.cost)}`;
  }
  const form = new ActionFormData().title("\xA74Raid Tools Shop").body(body);
  for (const tier of LOCKPICK_TIERS) {
    const [line1, line2, line3] = getRaidTierSummaryLines(settings, tier.tier);
    form.button(`${line1}
${line2}
${line3}`);
  }
  if (settings.repairEnabled) {
    form.button(repairInfo ? `Repair Held Tool
${getRaidTierDisplayName(repairInfo.tierConfig.tier)}
$${formatCompactCurrency(repairInfo.cost)}` : "Repair Held Tool\nHold damaged lockpick\nUnavailable");
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    const repairButtonIndex = settings.repairEnabled ? LOCKPICK_TIERS.length : -1;
    const backButtonIndex = settings.repairEnabled ? LOCKPICK_TIERS.length + 1 : LOCKPICK_TIERS.length;
    if (res.selection === backButtonIndex) {
      openMainMenu(player);
      return;
    }
    if (settings.repairEnabled && res.selection === repairButtonIndex) {
      attemptLockpickRepair(player);
      return;
    }
    if (res.selection >= 0 && res.selection < LOCKPICK_TIERS.length) {
      const tier = LOCKPICK_TIERS[res.selection];
      confirmLockpickPurchase(player, tier);
    }
  });
}
function confirmLockpickPurchase(player, tier) {
  const settings = loadRaidSettings();
  const balance = getBalance(player.id);
  const moneyCost = getRaidTierMoneyCost(settings, tier.tier);
  const ctokenCost = getRaidTierCTokenCost(settings, tier.tier);
  const ctokenBalance = getObjectiveBalance(player.id, CTOKEN_OBJECTIVE_ID, CTOKEN_OBJECTIVE_ID);
  const canAfford = balance >= moneyCost && ctokenBalance >= ctokenCost;
  const tierName = getRaidTierDisplayName(tier.tier);
  const form = new MessageFormData().title("\xA74Confirm Raid Tool Purchase").body(
    `\xA7fBuy ${tierName}\xA7f?

\xA7fCost: \xA72$${moneyCost}${ctokenCost > 0 ? ` \xA7f+ \xA7b${ctokenCost} CTokens` : ""}
\xA7fBalance: \xA72$${balance}
` + (ctokenCost > 0 ? `\xA7fCTokens: \xA7b${ctokenBalance}
` : "") + `\xA7fSuccess: \xA7e${getRaidTierSuccessPercent(settings, tier.tier)}%
\xA7fPick Time: \xA7e${getRaidTierPickTimeSeconds(settings, tier.tier)}s
\xA7fCooldown: \xA7e${settings.playerCooldownSeconds}s

` + (canAfford ? `\xA72After Purchase: $${balance - moneyCost}` : `\xA74You cannot afford this!`)
  ).button1("\xA72Buy").button2("\xA78Cancel");
  form.show(player).then((res) => {
    if (res.canceled || res.selection !== 0) {
      openLockpickShop(player);
      return;
    }
    if (!spendMoney(player, moneyCost, `lockpick:${tier.tier}`, loadEconomySettings())) {
      openLockpickShop(player);
      return;
    }
    if (ctokenCost > 0 && !deductObjectiveBalance(player.id, CTOKEN_OBJECTIVE_ID, ctokenCost, CTOKEN_OBJECTIVE_ID)) {
      refundSpentMoney(player, moneyCost);
      player.sendMessage("\xA7c\u26A0 You do not have enough CTokens!");
      openLockpickShop(player);
      return;
    }
    const container = getInventoryContainer(player);
    if (!container) {
      player.sendMessage("\xA7c\u26A0 Inventory error.");
      return;
    }
    const lockpickItem = new ItemStack(tier.itemId, 1);
    const emptySlot = findEmptySlot(container, []);
    if (emptySlot === -1) {
      player.sendMessage("\xA7c\u26A0 Inventory full! Make room first.");
      refundSpentMoney(player, moneyCost);
      if (ctokenCost > 0) addObjectiveBalance(player.id, CTOKEN_OBJECTIVE_ID, ctokenCost, CTOKEN_OBJECTIVE_ID);
      openLockpickShop(player);
      return;
    }
    container.setItem(emptySlot, lockpickItem);
    player.sendMessage(`\xA7a\u2714 Purchased ${tierName}\xA7a! Right-click near a locked plot to use it.`);
    playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.plotshop_purchase", { volume: 1, pitch: 1 });
    openLockpickShop(player);
  });
}
function attemptLockpickRepair(player) {
  const settings = loadRaidSettings();
  if (!settings.repairEnabled) {
    player.sendMessage("\xA7c\u26A0 Repairs are disabled by admins.");
    openLockpickShop(player);
    return;
  }
  const repairInfo = getHeldLockpickRepairCost(player, settings);
  if (!repairInfo) {
    player.sendMessage("\xA7c\u26A0 Hold a damaged lockpick in your main hand to repair it.");
    openLockpickShop(player);
    return;
  }
  const form = new MessageFormData().title("\xA76Repair Raid Tool").body(
    `\xA7fRepair ${getRaidTierDisplayName(repairInfo.tierConfig.tier)}\xA7f?
\xA7fRepair Cost: \xA72$${repairInfo.cost}
\xA7fBalance: \xA72$${getBalance(player.id)}`
  ).button1("\xA72Repair").button2("\xA78Cancel");
  form.show(player).then((res) => {
    if (res.canceled || res.selection !== 0) {
      openLockpickShop(player);
      return;
    }
    if (!spendMoney(player, repairInfo.cost, `lockpick_repair:${repairInfo.tierConfig.tier}`, loadEconomySettings())) {
      openLockpickShop(player);
      return;
    }
    if (!repairHeldLockpick(player)) {
      refundSpentMoney(player, repairInfo.cost);
      player.sendMessage("\xA7c\u26A0 Repair failed. Hold the damaged lockpick again.");
      openLockpickShop(player);
      return;
    }
    player.sendMessage(`\xA7a\u2714 Repaired ${getRaidTierDisplayName(repairInfo.tierConfig.tier)}\xA7a.`);
    playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.plotshop_purchase", { volume: 1, pitch: 1.1 });
    openLockpickShop(player);
  });
}
function openQualityOfLifeMenu(player) {
  const form = new ActionFormData().title("\xA7bTravel & QoL").body("\xA7fQuick travel, plot info, safe unstuck help, and utility options.");
  form.button("\xA71Teleport to Plot");
  form.button("\xA71Visit Plots");
  form.button("\xA76Current Plot Info");
  form.button("\xA72Safe Unstuck");
  form.button("\xA73Refresh Tools");
  form.button("\xA71Help");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    switch (res.selection) {
      case 0:
        openTeleportMenu(player);
        break;
      case 1:
        openVisitMenu(player, 0);
        break;
      case 2:
        openCurrentPlotInfo(player);
        break;
      case 3:
        safeUnstuckPlayer(player);
        break;
      case 4:
        ensurePlayerTools(player);
        player.sendMessage("\xA7a\u2714 Your Plot Manager tools were refreshed.");
        openQualityOfLifeMenu(player);
        break;
      case 5:
        openPlotHelpMenu(player, () => openQualityOfLifeMenu(player));
        break;
      default:
        openMainMenu(player);
        break;
    }
  });
}
function openBuyMenu(player, page) {
  const allPlots = loadPlots();
  const ownedPlot = getPrimaryOwnedPlot(allPlots, player.id);
  if (ownedPlot) {
    showOnePlotLimitMessage(player, ownedPlot, () => openPlotShopCategory(player));
    return;
  }
  const available = allPlots.filter((p) => p.ownerId === null);
  if (available.length === 0) {
    const form2 = new MessageFormData().title("\xA76Buy Plot").body("\xA74No plots are currently available for purchase.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openMainMenu(player));
    return;
  }
  const totalPages = Math.ceil(available.length / PAGE_SIZE);
  const start = page * PAGE_SIZE;
  const pageItems = available.slice(start, start + PAGE_SIZE);
  const form = new ActionFormData().title(`\xA76Buy Plot \xA78(Page ${page + 1}/${totalPages})`).body(`\xA7fYour Balance: \xA72$${getBalance(player.id)}`);
  for (const p of pageItems) {
    form.button(`\xA76${getPlotMenuLabel(p)}
\xA78${plotSize(p)} \u2014 \xA72$${p.price}`);
  }
  if (page > 0) form.button("\xA77\u25C0 Previous");
  if (page < totalPages - 1) form.button("\xA77Next \u25B6");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    let idx = res.selection;
    if (idx < pageItems.length) {
      openBuyConfirm(player, pageItems[idx], page);
      return;
    }
    idx -= pageItems.length;
    const hasPrev = page > 0 ? 1 : 0;
    if (page > 0 && idx === 0) openBuyMenu(player, page - 1);
    else if (page < totalPages - 1 && idx === hasPrev) openBuyMenu(player, page + 1);
    else openMainMenu(player);
  });
}
function openBuyConfirm(player, plot, returnPage) {
  const existingOwnedPlot = getPrimaryOwnedPlot(loadPlots(), player.id);
  if (existingOwnedPlot) {
    showOnePlotLimitMessage(player, existingOwnedPlot, () => openBuyMenu(player, returnPage));
    return;
  }
  const balance = getBalance(player.id);
  const canAfford = balance >= plot.price;
  const form = new MessageFormData().title("\xA76Confirm Purchase").body(
    `\xA7fPlot: \xA76${getPlotMenuLabel(plot)}
\xA7fSize: \xA71${plotSize(plot)}
\xA7fPrice: \xA72$${plot.price}
\xA7fYour Balance: \xA72$${balance}
` + (canAfford ? `\xA72After Purchase: $${balance - plot.price}` : `\xA74You cannot afford this plot!`)
  ).button1("\xA72Confirm").button2("\xA78Cancel");
  form.show(player).then((res) => {
    if (res.canceled || res.selection !== 0) {
      openBuyMenu(player, returnPage);
      return;
    }
    const plots = loadPlots();
    const target = plots.find((p) => p.id === plot.id);
    if (!target) {
      player.sendMessage("\xA7cPlot no longer exists.");
      openBuyMenu(player, returnPage);
      return;
    }
    if (target.ownerId !== null) {
      player.sendMessage("\xA7cThat plot was just purchased by someone else!");
      openBuyMenu(player, returnPage);
      return;
    }
    if (!canPlayerReceiveOwnership(plots, player.id)) {
      showOnePlotLimitMessage(player, getPrimaryOwnedPlot(plots, player.id), () => openBuyMenu(player, returnPage));
      return;
    }
    const economySettings = loadEconomySettings();
    if (economySettings.plotBuyPricesEnabled && !spendMoney(player, target.price, `buy_plot:${target.id}`, economySettings)) {
      openBuyMenu(player, returnPage);
      return;
    }
    target.ownerId = player.id;
    target.ownerName = player.name;
    target.locked = false;
    target.lastOwnerActivity = system.currentTick;
    addAccessLog(target, player.name, "purchased");
    savePlots(plots);
    player.sendMessage(`\xA7a\u2714 You purchased plot \xA7e${target.id}\xA7a for \xA7e$${target.price}\xA7a!`);
    playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.plotshop_purchase", { volume: 1, pitch: 1 });
  });
}
function openSellMenu(player) {
  const plots = loadPlots();
  const owned = plots.filter((p) => p.ownerId === player.id);
  if (owned.length === 0) {
    const form2 = new MessageFormData().title("\xA74Sell Plot").body("\xA78You don't own any plots to sell.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openMainMenu(player));
    return;
  }
  const form = new ActionFormData().title("\xA74Sell Plot").body("\xA78Select a plot to sell. You will receive \xA7250%\xA78 of the original price.");
  for (const p of owned) {
    const refund = Math.floor(p.price * 0.5);
    form.button(`\xA76${getPlotMenuLabel(p)}
\xA78${plotSize(p)} \u2014 Refund: \xA72$${refund}`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === owned.length) {
      openMainMenu(player);
      return;
    }
    openSellConfirm(player, owned[res.selection]);
  });
}
function openSellConfirm(player, plot) {
  const refund = Math.floor(plot.price * 0.5);
  const form = new MessageFormData().title("\xA74Confirm Sale").body(
    `\xA7fSell plot \xA76${plot.id}\xA7f?
\xA7fSize: \xA71${plotSize(plot)}
\xA7fRefund: \xA72$${refund}

\xA74This cannot be undone!`
  ).button1("\xA74Sell").button2("\xA78Cancel");
  form.show(player).then((res) => {
    if (res.canceled || res.selection !== 0) {
      openSellMenu(player);
      return;
    }
    const plots = loadPlots();
    const target = plots.find((p) => p.id === plot.id);
    if (!target || target.ownerId !== player.id) {
      player.sendMessage("\xA7cPlot not found or not owned by you.");
      return;
    }
    target.ownerId = null;
    target.ownerName = null;
    target.locked = false;
    target.members = [];
    target.hasProtectionUpgrade = false;
    target.hasContainerShieldUpgrade = false;
    target.memberSlotUpgrade = 0;
    target.lockStrengthTier = 0;
    target.alarmUpgradeTier = 0;
    target.reinforcedContainerTier = 0;
    target.breachedUntil = 0;
    target.breachedBy = null;
    target.breachedById = null;
    target.containerShieldUntil = 0;
    addAccessLog(target, player.name, "sold");
    savePlots(plots);
    rewardMoney(player, refund);
    player.sendMessage(`\xA7a\u2714 Sold plot \xA7e${target.id}\xA7a. Refund: \xA7e$${refund}\xA7a. New balance: \xA7e$${getBalance(player.id)}`);
  });
}
function openMyPlotMenu(player) {
  const plots = loadPlots();
  const owned = getOwnedPlotsForPlayer(plots, player.id);
  if (owned.length === 0) {
    const form2 = new MessageFormData().title("\xA76My Plot").body("\xA78You don't own any plots yet.\n\xA78Use \xA76Buy Plot\xA78 to get started!").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openMainMenu(player));
    return;
  }
  if (owned.length === 1) {
    openPlotDetail(player, owned[0]);
    return;
  }
  const form = new ActionFormData().title("\xA76My Plot").body(
    `\xA7cLegacy notice: ownership is now limited to one plot at a time.
\xA7fYou currently have \xA76${owned.length}\xA7f plots. Sell or transfer extras to get back to the limit.`
  );
  for (const p of owned) {
    const status = p.locked ? "\xA74Locked" : "\xA72Unlocked";
    const pub = p.isPublic ? "\xA72Public" : "\xA78Private";
    form.button(`\xA76${getPlotMenuLabel(p)} ${status} ${pub}
\xA78${plotSize(p)} @ (${p.x1},${p.z1})`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === owned.length) {
      openMainMenu(player);
      return;
    }
    openPlotDetail(player, owned[res.selection]);
  });
}
function openPlotDetail(player, plot) {
  const plots = loadPlots();
  const freshPlot = plots.find((p) => p.id === plot.id) ?? plot;
  const defenseSettings = loadDefenseSettings();
  const upkeepStates = loadDefenseUpkeepStates();
  const status = freshPlot.locked ? "\xA74Locked" : "\xA72Unlocked";
  const lockLabel = freshPlot.locked ? "\xA72Unlock" : "\xA74Lock";
  const publicLabel = freshPlot.isPublic ? "\xA78Make Private" : "\xA72Make Public";
  const memberCount = freshPlot.members.length;
  const maxMembers = getMaxMembers(freshPlot);
  const breached = isPlotBreached(freshPlot);
  const breachTime = breached ? Math.ceil((freshPlot.breachedUntil - system.currentTick) / 20) : 0;
  const raidCd = isPlotOnRaidCooldown(freshPlot) ? getPlotRaidCooldownRemaining(freshPlot) : 0;
  let bodyText = `\xA7fPlot: \xA76${getPlotMenuLabel(freshPlot)}
\xA7fFootprint: \xA78(${freshPlot.x1}, ${freshPlot.z1}) to (${freshPlot.x2}, ${freshPlot.z2})
\xA7fProtected Y: \xA71${plotVerticalCoverageText()}
\xA7fSize: \xA71${plotSize(freshPlot)}
\xA7fStatus: ${status}
\xA7fPublic: ${freshPlot.isPublic ? "\xA72Yes" : "\xA74No"}
\xA7fMembers: \xA73${memberCount}/${maxMembers}
\xA7fProtection Upgrade: ${freshPlot.hasProtectionUpgrade ? "\xA72Yes" : "\xA74No"}
\xA7fContainer Shield: ${freshPlot.hasContainerShieldUpgrade ? "\xA72Yes" : "\xA74No"}
\xA7fDefense Status: ${getDefenseStatusLabel(freshPlot, upkeepStates)}
` + getDefenseUpgradeSummary(freshPlot, defenseSettings, upkeepStates);
  if (breached) {
    bodyText += `

\xA7c\u2694 BREACHED by \xA7e${freshPlot.breachedBy}\xA7c! \xA7e${breachTime}s\xA7c remaining`;
    if (isPlotContainerShielded(freshPlot)) {
      const shieldTime = Math.ceil((freshPlot.containerShieldUntil - system.currentTick) / 20);
      bodyText += `
\xA76Container Shield active: \xA7e${shieldTime}s\xA76 remaining`;
    }
  } else if (raidCd > 0) {
    bodyText += `
\xA78Raid cooldown: \xA7e${Math.ceil(raidCd / 60)}m ${raidCd % 60}s`;
  }
  const form = new ActionFormData().title(`\xA76${getPlotMenuLabel(freshPlot)}`).body(bodyText);
  form.button("\xA71Teleport");
  form.button(`${lockLabel} Plot`);
  form.button(publicLabel);
  form.button("\xA73Manage Members");
  form.button("\xA71View Access Log");
  form.button("\xA75Transfer Ownership");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    switch (res.selection) {
      case 0:
        teleportToPlot(player, freshPlot);
        break;
      case 1:
        toggleLockFromDetail(player, freshPlot);
        break;
      case 2:
        togglePublic(player, freshPlot);
        break;
      case 3:
        openPlotMemberMenu(player, freshPlot);
        break;
      case 4:
        openAccessLog(player, freshPlot);
        break;
      case 5:
        openTransferMenu(player, freshPlot);
        break;
      default:
        openMyPlotMenu(player);
        break;
    }
  });
}
function togglePublic(player, plot) {
  const plots = loadPlots();
  const target = plots.find((p) => p.id === plot.id);
  if (!target || target.ownerId !== player.id) {
    player.sendMessage("\xA7cPlot not found.");
    openMyPlotMenu(player);
    return;
  }
  target.isPublic = !target.isPublic;
  addAccessLog(target, player.name, target.isPublic ? "set public" : "set private");
  savePlots(plots);
  player.sendMessage(`\xA7a\u2714 Plot \xA7e${target.id}\xA7a is now ${target.isPublic ? "\xA7apublic" : "\xA77private"}\xA7a.`);
  openPlotDetail(player, target);
}
function openTransferMenu(player, plot) {
  const onlinePlayers = world.getAllPlayers().filter((p) => p.id !== player.id);
  if (onlinePlayers.length === 0) {
    const form2 = new MessageFormData().title("\xA75Transfer Ownership").body("\xA77No other players are online to transfer to.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openPlotDetail(player, plot));
    return;
  }
  const form = new ActionFormData().title("\xA75Transfer Ownership").body(`\xA77Transfer plot \xA7e${plot.id}\xA77 to another player.
\xA7cThis cannot be undone!`);
  for (const p of onlinePlayers) {
    form.button(`\xA7f${p.name}`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === onlinePlayers.length) {
      openPlotDetail(player, plot);
      return;
    }
    const targetPlayer = onlinePlayers[res.selection];
    openTransferConfirm(player, plot, targetPlayer);
  });
}
function openTransferConfirm(player, plot, targetPlayer) {
  const form = new MessageFormData().title("\xA75Confirm Transfer").body(
    `\xA7fTransfer plot \xA7e${plot.id}\xA7f to \xA7e${targetPlayer.name}\xA7f?

\xA7cThis will remove your ownership permanently!`
  ).button1("\xA75Transfer").button2("\xA78Cancel");
  form.show(player).then((res) => {
    if (res.canceled || res.selection !== 0) {
      openPlotDetail(player, plot);
      return;
    }
    const plots = loadPlots();
    const target = plots.find((p) => p.id === plot.id);
    if (!target || target.ownerId !== player.id) {
      player.sendMessage("\xA7cPlot not found or not owned by you.");
      return;
    }
    if (!canPlayerReceiveOwnership(plots, targetPlayer.id, target.id)) {
      player.sendMessage(`\xA7c${targetPlayer.name} already owns a plot. Players can only own one plot at a time.`);
      openPlotDetail(player, target);
      return;
    }
    target.ownerId = targetPlayer.id;
    target.ownerName = targetPlayer.name;
    target.members = target.members.filter((m) => m.playerId !== targetPlayer.id);
    addAccessLog(target, player.name, `transferred to ${targetPlayer.name}`);
    savePlots(plots);
    player.sendMessage(`\xA7a\u2714 Plot \xA7e${target.id}\xA7a transferred to \xA7e${targetPlayer.name}\xA7a.`);
    targetPlayer.sendMessage(`\xA7a\u2714 You received plot \xA7e${target.id}\xA7a from \xA7e${player.name}\xA7a!`);
  });
}
function openAccessLog(player, plot) {
  const recentLogs = plot.accessLog.slice(-20).reverse();
  let body = `\xA77Recent activity for plot \xA7e${plot.id}\xA77:

`;
  if (recentLogs.length === 0) {
    body += "\xA78No activity recorded.";
  } else {
    for (const entry of recentLogs) {
      body += `\xA7f${entry.playerName} \xA77- ${entry.action}
`;
    }
  }
  const form = new MessageFormData().title("\xA79Access Log").body(body).button1("\xA78Back").button2("\xA78Back");
  form.show(player).then(() => openPlotDetail(player, plot));
}
function openTeleportMenu(player) {
  const plots = loadPlots();
  const owned = getOwnedPlotsForPlayer(plots, player.id);
  if (owned.length === 0) {
    const form2 = new MessageFormData().title("\xA71Teleport").body("\xA78You don't own any plots to teleport to.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openMainMenu(player));
    return;
  }
  const form = new ActionFormData().title("\xA71Teleport to Plot").body("\xA78Select a plot to teleport to:");
  for (const p of owned) {
    form.button(`\xA76${getPlotMenuLabel(p)}
\xA78${plotSize(p)}`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === owned.length) {
      openMainMenu(player);
      return;
    }
    teleportToPlot(player, owned[res.selection]);
  });
}
function openVisitMenu(player, page) {
  const plots = loadPlots();
  const visitable = plots.filter((p) => p.ownerId !== null && p.ownerId !== player.id && p.isPublic && !p.locked);
  if (visitable.length === 0) {
    const form2 = new MessageFormData().title("\xA71Visit Plots").body("\xA78No public plots are available to visit right now.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openMainMenu(player));
    return;
  }
  const totalPages = Math.ceil(visitable.length / PAGE_SIZE);
  const start = page * PAGE_SIZE;
  const pageItems = visitable.slice(start, start + PAGE_SIZE);
  const form = new ActionFormData().title(`\xA71Visit Plots \xA78(${page + 1}/${totalPages})`).body("\xA78Visit other players' public plots:");
  for (const p of pageItems) {
    form.button(`\xA76${getPlotMenuLabel(p)}
\xA78Owner: \xA7f${p.ownerName ?? "Unknown"}`);
  }
  if (page > 0) form.button("\xA77\u25C0 Previous");
  if (page < totalPages - 1) form.button("\xA77Next \u25B6");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    let idx = res.selection;
    if (idx < pageItems.length) {
      teleportToPlot(player, pageItems[idx]);
      return;
    }
    idx -= pageItems.length;
    const hasPrev = page > 0 ? 1 : 0;
    if (page > 0 && idx === 0) openVisitMenu(player, page - 1);
    else if (page < totalPages - 1 && idx === hasPrev) openVisitMenu(player, page + 1);
    else openMainMenu(player);
  });
}
function teleportToPlot(player, plot) {
  const lastTp = teleportCooldowns.get(player.id);
  if (lastTp !== void 0 && system.currentTick - lastTp < TELEPORT_COOLDOWN_TICKS) {
    const remaining = Math.ceil((TELEPORT_COOLDOWN_TICKS - (system.currentTick - lastTp)) / 20);
    player.sendMessage(`\xA7cTeleport on cooldown! Wait \xA7e${remaining}s\xA7c.`);
    return;
  }
  teleportCooldowns.set(player.id, system.currentTick);
  const safeLocation = findSafeTeleportLocationInPlot(player, plot);
  player.sendMessage("\xA7eTeleporting in \xA763\xA7e seconds...");
  playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.plotshop_purchase", { volume: 0.5, pitch: 1.5 });
  system.runTimeout(() => {
    if (!player.isValid) return;
    player.teleport(safeLocation, { dimension: player.dimension });
    player.sendMessage(`\xA7a\u2714 Teleported to plot \xA7e${plot.id}\xA7a!`);
  }, 60);
}
function findSafeSurfaceNearPlayer(player) {
  const playerX = Math.floor(player.location.x);
  const playerZ = Math.floor(player.location.z);
  const columns = buildColumnSearch(playerX, playerZ, SAFE_LOCATION_SEARCH_RADIUS);
  return findSafeLocationForColumns(player.dimension, columns);
}
function safeUnstuckPlayer(player, returnMenu = openQualityOfLifeMenu) {
  const plots = loadPlots();
  const currentPlot = getPlotAtLocation(plots, Math.floor(player.location.x), Math.floor(player.location.y), Math.floor(player.location.z));
  let destination = null;
  let reason = "\xA7a\u2714 Moved you to a safe surface.";
  if (currentPlot && canEnter(currentPlot, player.id)) {
    destination = findSafeTeleportLocationInPlot(player, currentPlot);
    reason = `\xA7a\u2714 Moved you to a safe spot on plot \xA7e${currentPlot.id}\xA7a.`;
  }
  if (!destination) {
    const ownedPlot = plots.find((p) => p.ownerId === player.id);
    if (ownedPlot) {
      destination = findSafeTeleportLocationInPlot(player, ownedPlot);
      reason = `\xA7a\u2714 Moved you to a safe spot on your plot \xA7e${ownedPlot.id}\xA7a.`;
    }
  }
  if (!destination) {
    destination = findSafeSurfaceNearPlayer(player);
  }
  if (!destination) {
    player.sendMessage("\xA7cCouldn't find a safe surface nearby.");
    returnMenu(player);
    return;
  }
  player.teleport(destination, { dimension: player.dimension });
  player.sendMessage(reason);
  returnMenu(player);
}
function openCurrentPlotInfo(player) {
  const plots = loadPlots();
  const currentPlot = getPlotAtLocation(plots, Math.floor(player.location.x), Math.floor(player.location.y), Math.floor(player.location.z));
  if (!currentPlot) {
    const form2 = new MessageFormData().title("\xA76Current Plot Info").body("\xA7fYou are not standing inside a plot right now.\n\xA7fUse \xA71Teleport to Plot\xA7f or \xA71Visit Plots\xA7f from the QoL menu for quick travel.").button1("\xA78Back").button2("\xA7bQoL Menu");
    form2.show(player).then((res) => {
      if (res.selection === 1) openQualityOfLifeMenu(player);
      else openMainMenu(player);
    });
    return;
  }
  const role = getPlayerRole(currentPlot, player.id) ?? "outsider";
  const form = new MessageFormData().title(`\xA76Current Plot: ${currentPlot.id}`).body(
    `\xA7fPlot: \xA76${getPlotMenuLabel(currentPlot)}
\xA7fOwner: \xA76${currentPlot.ownerName ?? "Unowned"}
\xA7fStatus: ${currentPlot.locked ? "\xA74Locked" : "\xA72Unlocked"}
\xA7fPublic: ${currentPlot.isPublic ? "\xA72Yes" : "\xA74No"}
\xA7fYour Role: ${role === "owner" ? "\xA76Owner" : role === "coowner" ? "\xA76Co-Owner" : role === "trusted" ? "\xA72Trusted" : role === "visitor" ? "\xA71Visitor" : "\xA77Outsider"}
\xA7fSize: \xA71${plotSize(currentPlot)}
\xA7fProtected Height: \xA7b${plotVerticalCoverageText()}`
  ).button1("\xA78Back").button2("\xA72Safe Spot");
  form.show(player).then((res) => {
    if (res.selection === 1) {
      const destination = findSafeTeleportLocationInPlot(player, currentPlot);
      player.teleport(destination, { dimension: player.dimension });
      player.sendMessage(`\xA7a\u2714 Moved you to a safe spot on plot \xA7e${currentPlot.id}\xA7a.`);
      return;
    }
    openQualityOfLifeMenu(player);
  });
}
function openLockMenu(player, locking) {
  const plots = loadPlots();
  const owned = getOwnedPlotsForPlayer(plots, player.id);
  const eligible = owned.filter((p) => locking ? !p.locked : p.locked);
  const action = locking ? "\xA74Lock" : "\xA72Unlock";
  if (eligible.length === 0) {
    const msg = locking ? "\xA77You have no unlocked plots to lock." : "\xA77You have no locked plots to unlock.";
    const form2 = new MessageFormData().title(`${action} Plot`).body(msg).button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openMainMenu(player));
    return;
  }
  if (locking && isInCombat(player)) {
    player.sendMessage("\xA7c\u26A0 You cannot lock a plot while in combat!");
    return;
  }
  const form = new ActionFormData().title(`${action} Plot`).body(`\xA78Select a plot to ${locking ? "lock" : "unlock"}.
\xA78Plots marked \xA74Upgrade Required\xA78 need the Plot Lock Upgrade while you are away from them.`);
  for (const p of eligible) {
    const requiresUpgrade = !canUsePlotLockFeature(player, p);
    form.button(`\xA76${p.id}
${requiresUpgrade ? "\xA74Upgrade Required" : `\xA78${plotSize(p)}`}`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === eligible.length) {
      openMainMenu(player);
      return;
    }
    const selectedPlot = eligible[res.selection];
    if (!canUsePlotLockFeature(player, selectedPlot)) {
      showPlotLockUpgradeRequired(player, () => openLockMenu(player, locking));
      return;
    }
    confirmLock(player, selectedPlot, locking);
  });
}
function confirmLock(player, plot, locking) {
  if (!canUsePlotLockFeature(player, plot)) {
    showPlotLockUpgradeRequired(player);
    return;
  }
  if (locking && isInCombat(player)) {
    player.sendMessage("\xA7c\u26A0 You cannot lock a plot while in combat!");
    return;
  }
  const action = locking ? "Lock" : "Unlock";
  const form = new MessageFormData().title(`\xA7${locking ? "4" : "2"}${action} Plot`).body(`\xA7f${action} plot \xA76${plot.id}\xA7f?`).button1(`\xA7${locking ? "4" : "2"}${action}`).button2("\xA78Cancel");
  form.show(player).then((res) => {
    if (res.canceled || res.selection !== 0) return;
    const plots = loadPlots();
    const target = plots.find((p) => p.id === plot.id);
    if (!target || target.ownerId !== player.id) {
      player.sendMessage("\xA7cPlot not found or not owned by you.");
      return;
    }
    if (locking && isInCombat(player)) {
      player.sendMessage("\xA7c\u26A0 You cannot lock a plot while in combat!");
      return;
    }
    target.locked = locking;
    addAccessLog(target, player.name, locking ? "lock" : "unlock");
    savePlots(plots);
    const lockStatus = locking ? "\xA76locked" : "\xA7aunlocked";
    player.sendMessage(`\xA7a\u2714 Plot \xA7e${target.id}\xA7a has been ${lockStatus}\xA7a.`);
    playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.plotshop_lock", { volume: 1, pitch: locking ? 0.8 : 1.2 });
  });
}
function toggleLockFromDetail(player, plot) {
  if (!canUsePlotLockFeature(player, plot)) {
    showPlotLockUpgradeRequired(player, () => openPlotDetail(player, plot));
    return;
  }
  if (!plot.locked && isInCombat(player)) {
    player.sendMessage("\xA7c\u26A0 You cannot lock a plot while in combat!");
    openPlotDetail(player, plot);
    return;
  }
  confirmLock(player, plot, !plot.locked);
}
function openMemberManagementMenu(player) {
  const plots = loadPlots();
  const owned = getOwnedPlotsForPlayer(plots, player.id);
  if (owned.length === 0) {
    const form2 = new MessageFormData().title("\xA73Members").body("\xA78You don't own any plots.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openMainMenu(player));
    return;
  }
  if (owned.length === 1) {
    openPlotMemberMenu(player, owned[0]);
    return;
  }
  const form = new ActionFormData().title("\xA73Manage Members").body("\xA78Select a plot to manage members:");
  for (const p of owned) {
    form.button(`\xA76${p.id}
\xA78${p.members.length}/${getMaxMembers(p)} members`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === owned.length) {
      openMainMenu(player);
      return;
    }
    openPlotMemberMenu(player, owned[res.selection]);
  });
}
function openPlotMemberMenu(player, plot) {
  cleanExpiredMembers(plot);
  const maxMembers = getMaxMembers(plot);
  let body = `\xA70Plot: \xA76${plot.id}\xA70 \u2014 Members: \xA73${plot.members.length}/${maxMembers}

`;
  if (plot.members.length === 0) {
    body += "\xA78No members added yet.";
  } else {
    for (const m of plot.members) {
      const roleColor = m.role === "coowner" ? "\xA76" : m.role === "trusted" ? "\xA72" : "\xA78";
      const expiry = m.expiresAt !== null ? " \xA78(temp)" : "";
      body += `${roleColor}${m.playerName} \xA77- ${m.role}${expiry}
`;
    }
  }
  const form = new ActionFormData().title(`\xA73Members: ${plot.id}`).body(body);
  form.button("\xA72Add Member");
  form.button("\xA74Remove Member");
  form.button("\xA71Add Temp Access");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    switch (res.selection) {
      case 0:
        openAddMemberMenu(player, plot);
        break;
      case 1:
        openRemoveMemberMenu(player, plot);
        break;
      case 2:
        openAddTempMemberMenu(player, plot);
        break;
      default:
        openPlotDetail(player, plot);
        break;
    }
  });
}
function openAddMemberMenu(player, plot) {
  cleanExpiredMembers(plot);
  const maxMembers = getMaxMembers(plot);
  if (plot.members.length >= maxMembers) {
    player.sendMessage(`\xA7c\u26A0 Member limit reached (${maxMembers}). Upgrade slots or remove a member.`);
    openPlotMemberMenu(player, plot);
    return;
  }
  const onlinePlayers = world.getAllPlayers().filter(
    (p) => p.id !== player.id && !plot.members.some((m) => m.playerId === p.id)
  );
  if (onlinePlayers.length === 0) {
    const form2 = new MessageFormData().title("\xA72Add Member").body("\xA78No eligible online players found.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openPlotMemberMenu(player, plot));
    return;
  }
  const form = new ActionFormData().title("\xA72Add Member").body("\xA78Select a player to add:");
  for (const p of onlinePlayers) {
    form.button(`\xA70${p.name}`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === onlinePlayers.length) {
      openPlotMemberMenu(player, plot);
      return;
    }
    const selectedPlayer = onlinePlayers[res.selection];
    openSelectRoleMenu(player, plot, selectedPlayer, null);
  });
}
function openSelectRoleMenu(player, plot, targetPlayer, expiryTicks) {
  const form = new ActionFormData().title(`\xA72Role for ${targetPlayer.name}`).body(`\xA78Choose a role for \xA76${targetPlayer.name}\xA78:`);
  form.button("\xA76Co-Owner\n\xA77Full permissions");
  form.button("\xA72Trusted\n\xA78Build & interact");
  form.button("\xA71Visitor\n\xA78Enter only");
  form.button("\xA78\u21A9 Cancel");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0 || res.selection === 3) {
      openPlotMemberMenu(player, plot);
      return;
    }
    const roleMap = ["coowner", "trusted", "visitor"];
    const role = roleMap[res.selection];
    const plots = loadPlots();
    const target = plots.find((p) => p.id === plot.id);
    if (!target || !canManage(target, player.id)) {
      player.sendMessage("\xA7cPlot not found or no permission.");
      return;
    }
    cleanExpiredMembers(target);
    if (target.members.length >= getMaxMembers(target)) {
      player.sendMessage("\xA7c\u26A0 Member limit reached!");
      return;
    }
    target.members = target.members.filter((m) => m.playerId !== targetPlayer.id);
    target.members.push({
      playerId: targetPlayer.id,
      playerName: targetPlayer.name,
      role,
      addedAt: system.currentTick,
      expiresAt: expiryTicks
    });
    addAccessLog(target, player.name, `added ${targetPlayer.name} as ${role}`);
    savePlots(plots);
    player.sendMessage(`\xA7a\u2714 Added \xA7e${targetPlayer.name}\xA7a as \xA7e${role}\xA7a to plot \xA7e${target.id}\xA7a.`);
    targetPlayer.sendMessage(`\xA7a\u2714 You were added to plot \xA7e${target.id}\xA7a as \xA7e${role}\xA7a by \xA7e${player.name}\xA7a.`);
    openPlotMemberMenu(player, target);
  });
}
function openAddTempMemberMenu(player, plot) {
  cleanExpiredMembers(plot);
  const maxMembers = getMaxMembers(plot);
  if (plot.members.length >= maxMembers) {
    player.sendMessage(`\xA7c\u26A0 Member limit reached (${maxMembers}).`);
    openPlotMemberMenu(player, plot);
    return;
  }
  const onlinePlayers = world.getAllPlayers().filter(
    (p) => p.id !== player.id && !plot.members.some((m) => m.playerId === p.id)
  );
  if (onlinePlayers.length === 0) {
    const form2 = new MessageFormData().title("\xA71Temporary Access").body("\xA78No eligible online players found.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openPlotMemberMenu(player, plot));
    return;
  }
  const form = new ActionFormData().title("\xA71Temporary Access").body("\xA78Select a player for temporary access:");
  for (const p of onlinePlayers) {
    form.button(`\xA70${p.name}`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === onlinePlayers.length) {
      openPlotMemberMenu(player, plot);
      return;
    }
    const selectedPlayer = onlinePlayers[res.selection];
    openTempDurationMenu(player, plot, selectedPlayer);
  });
}
function openTempDurationMenu(player, plot, targetPlayer) {
  const form = new ActionFormData().title("\xA71Access Duration").body(`\xA78How long should \xA76${targetPlayer.name}\xA78 have access?`);
  form.button("\xA70\xA7l15 Minutes");
  form.button("\xA701 Hour");
  form.button("\xA706 Hours");
  form.button("\xA7024 Hours");
  form.button("\xA78\u21A9 Cancel");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0 || res.selection === 4) {
      openPlotMemberMenu(player, plot);
      return;
    }
    const durationsMs = [
      15 * 60 * 1000,
      // 15 min
      60 * 60 * 1000,
      // 1 hour
      6 * 60 * 60 * 1000,
      // 6 hours
      24 * 60 * 60 * 1000
      // 24 hours
    ];
    const expiryTimestamp = Date.now() + durationsMs[res.selection];
    openSelectRoleMenu(player, plot, targetPlayer, expiryTimestamp);
  });
}
function openRemoveMemberMenu(player, plot) {
  cleanExpiredMembers(plot);
  if (plot.members.length === 0) {
    const form2 = new MessageFormData().title("\xA74Remove Member").body("\xA78No members to remove.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openPlotMemberMenu(player, plot));
    return;
  }
  const form = new ActionFormData().title("\xA74Remove Member").body("\xA78Select a member to remove:");
  for (const m of plot.members) {
    const roleColor = m.role === "coowner" ? "\xA76" : m.role === "trusted" ? "\xA72" : "\xA71";
    form.button(`${roleColor}${m.playerName}
\xA78${m.role}`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === plot.members.length) {
      openPlotMemberMenu(player, plot);
      return;
    }
    const memberToRemove = plot.members[res.selection];
    const plots = loadPlots();
    const target = plots.find((p) => p.id === plot.id);
    if (!target || !canManage(target, player.id)) {
      player.sendMessage("\xA7cPlot not found or no permission.");
      return;
    }
    target.members = target.members.filter((m) => m.playerId !== memberToRemove.playerId);
    addAccessLog(target, player.name, `removed ${memberToRemove.playerName}`);
    savePlots(plots);
    player.sendMessage(`\xA7a\u2714 Removed \xA7e${memberToRemove.playerName}\xA7a from plot \xA7e${target.id}\xA7a.`);
    const removedPlayer = world.getAllPlayers().find((p) => p.id === memberToRemove.playerId);
    if (removedPlayer) {
      removedPlayer.sendMessage(`\xA7c\u26A0 You were removed from plot \xA7e${target.id}\xA7c by \xA7e${player.name}\xA7c.`);
    }
    openPlotMemberMenu(player, target);
  });
}
var PROTECTION_UPGRADE_COST = 500;
var MEMBER_SLOT_UPGRADE_COST = 200;
function purchaseDefenseUpgradeTier(player, plot, type) {
  const settings = loadDefenseSettings();
  const plots = loadPlots();
  const target = plots.find((candidate) => candidate.id === plot.id);
  if (!target || target.ownerId !== player.id) {
    player.sendMessage("\xA7cPlot not found.");
    return;
  }
  const currentTier = type === "lock" ? target.lockStrengthTier : type === "alarm" ? target.alarmUpgradeTier : target.reinforcedContainerTier;
  const nextTier = currentTier + 1;
  if (nextTier > 3) {
    player.sendMessage(`\xA7c${getDefenseTierName(type)} is already max tier.`);
    openPlotUpgradeMenu(player, target);
    return;
  }
  if (nextTier === 3 && !canUpgradeDefenseTypeToTier3(target, currentTier, settings)) {
    player.sendMessage(`\xA7cGlobal defense limit reached: only \xA7e${settings.maxTier3UpgradeTypes}\xA7c upgrade types can be Tier 3. This one is capped at Tier 2.`);
    openPlotUpgradeMenu(player, target);
    return;
  }
  const cost = getDefenseTierCost(type, nextTier, player.id, settings);
  if (!spendMoney(player, cost, `defense:${type}:${target.id}`, loadEconomySettings())) {
    openPlotUpgradeMenu(player, target);
    return;
  }
  if (type === "lock") target.lockStrengthTier = nextTier;
  if (type === "alarm") target.alarmUpgradeTier = nextTier;
  if (type === "containers") target.reinforcedContainerTier = nextTier;
  addAccessLog(target, player.name, `upgraded ${getDefenseTierName(type).toLowerCase()} to tier ${nextTier}`);
  savePlots(plots);
  player.sendMessage(`\xA7a\u2714 ${getDefenseTierName(type)} upgraded to \xA7eTier ${nextTier}\xA7a for \xA7e$${cost}\xA7a.`);
  playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.plotshop_purchase", { volume: 1, pitch: 1.2 });
  openPlotUpgradeMenu(player, target);
}
function openUpgradesMenu(player) {
  const plots = loadPlots();
  const owned = getOwnedPlotsForPlayer(plots, player.id);
  if (owned.length === 0) {
    const form2 = new MessageFormData().title("\xA75Upgrades").body("\xA78You don't own any plots to upgrade.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openMainMenu(player));
    return;
  }
  if (owned.length === 1) {
    openPlotUpgradeMenu(player, owned[0]);
    return;
  }
  const form = new ActionFormData().title("\xA75Upgrades").body("\xA78Select a plot to upgrade:");
  for (const p of owned) {
    form.button(`\xA76${getPlotMenuLabel(p)}
\xA78${plotSize(p)}`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === owned.length) {
      openMainMenu(player);
      return;
    }
    openPlotUpgradeMenu(player, owned[res.selection]);
  });
}
function openPlotUpgradeMenu(player, plot) {
  const balance = getBalance(player.id);
  const maxMembers = getMaxMembers(plot);
  const defenseSettings = loadDefenseSettings();
  const upkeepStates = loadDefenseUpkeepStates();
  const upkeepProgress = plot.ownerId ? getDefenseUpkeepProgress(plot.ownerId, defenseSettings, upkeepStates) : { current: 0, total: 1 };
  const defenseActive = areDefenseUpgradesActiveForPlot(plot, upkeepStates);
  const tier3Count = getDefenseUpgradeTier3Count(plot);
  const nextLockTier = Math.min(3, plot.lockStrengthTier + 1);
  const nextAlarmTier = Math.min(3, plot.alarmUpgradeTier + 1);
  const nextContainerTier = Math.min(3, plot.reinforcedContainerTier + 1);
  let body = `\xA7fPlot: \xA76${plot.id}\xA7f
\xA7fBalance: \xA72$${balance}\xA7f
`;
  body += `\xA7fDefense Status: ${getDefenseStatusLabel(plot, upkeepStates)}\xA7f
`;
  if (plotHasAnyDefenseUpgrade(plot) && plot.ownerId) {
    body += `\xA7fUpkeep: \xA76${defenseSettings.upkeepPercentOfBalance}%\xA7f of balance every \xA7e${getUpkeepIntervalLabel(defenseSettings)}\xA7f`;
    if (defenseSettings.upkeepCapEnabled) {
      body += ` \xA78(cap \xA72$${formatCompactCurrency(defenseSettings.upkeepDailyCap)}\xA78)`;
    }
    body += `
\xA7fProgress: \xA7e${Math.floor(upkeepProgress.current / upkeepProgress.total * 100)}%\xA7f to next charge`;
    body += `
\xA7fLast Charge: \xA72$${getDefenseUpkeepState(plot.ownerId, upkeepStates).lastChargeAmount}`;
  }
  body += `

${getDefenseUpgradeSummary(plot, defenseSettings, upkeepStates)}
`;
  body += `
\xA7fTier 3 Types: \xA7e${tier3Count}/${defenseSettings.maxTier3UpgradeTypes}`;
  body += `
\xA78Third defense type is capped at Tier 2 when the Tier 3 limit is full.`;
  body += `

\xA7fPlot Lock Upgrade: ${plot.hasProtectionUpgrade ? "\xA72\u2714 Owned" : `\xA74\u2718 Not owned \xA78(\xA72$${PROTECTION_UPGRADE_COST}\xA78)`}`;
  body += `
\xA78  \u21B3 Remote lock/unlock when away`;
  body += `
\xA7fContainer Shield: ${plot.hasContainerShieldUpgrade ? "\xA72\u2714 Owned" : `\xA74\u2718 Not owned \xA78(\xA72$${CONTAINER_SHIELD_UPGRADE_COST}\xA78)`}`;
  body += `
\xA78  \u21B3 Blocks container access for 30s when raided`;
  body += `
\xA7fMember Slots: \xA73${maxMembers}\xA78 (base 5 + ${plot.memberSlotUpgrade} upgrades)`;
  body += `
\xA78  \u21B3 Next upgrade: \xA72$${MEMBER_SLOT_UPGRADE_COST}\xA78 (+1 slot)`;
  const form = new ActionFormData().title(`\xA75Upgrades: ${plot.id}`).body(body);
  const buttonActions = [];
  if (plot.lockStrengthTier < 3) {
    form.button(`\xA76Lock Strength \u2192 Tier ${nextLockTier}
\xA78+${defenseSettings.lockStrengthExtraSeconds[nextLockTier - 1]}s | -${defenseSettings.lockStrengthSuccessPenaltyPercent[nextLockTier - 1]}%
\xA72$${formatCompactCurrency(getDefenseTierCost("lock", nextLockTier, player.id, defenseSettings))}`);
    buttonActions.push(() => purchaseDefenseUpgradeTier(player, plot, "lock"));
  }
  if (plot.alarmUpgradeTier < 3) {
    form.button(`\xA7cAlarm Upgrade \u2192 Tier ${nextAlarmTier}
\xA78${getAlarmTierDurationSeconds(nextAlarmTier, defenseSettings)}s pulse${nextAlarmTier >= 2 ? " + strength" : ""}
\xA72$${formatCompactCurrency(getDefenseTierCost("alarm", nextAlarmTier, player.id, defenseSettings))}`);
    buttonActions.push(() => purchaseDefenseUpgradeTier(player, plot, "alarm"));
  }
  if (plot.reinforcedContainerTier < 3) {
    form.button(`\xA73Reinforced Containers \u2192 Tier ${nextContainerTier}
\xA78${defenseSettings.reinforcedContainerDelaySeconds[nextContainerTier - 1]}s open delay
\xA72$${formatCompactCurrency(getDefenseTierCost("containers", nextContainerTier, player.id, defenseSettings))}`);
    buttonActions.push(() => purchaseDefenseUpgradeTier(player, plot, "containers"));
  }
  if (!plot.hasProtectionUpgrade) {
    form.button(`\xA75Plot Lock Upgrade
\xA78Remote lock/unlock
\xA72$${PROTECTION_UPGRADE_COST}`);
    buttonActions.push(() => {
      const plots = loadPlots();
      const target = plots.find((p) => p.id === plot.id);
      if (!target || target.ownerId !== player.id || target.hasProtectionUpgrade) {
        player.sendMessage("\xA7cPlot not found or upgrade already owned.");
        openPlotUpgradeMenu(player, plot);
        return;
      }
      if (!spendMoney(player, PROTECTION_UPGRADE_COST, `plot_lock_upgrade:${plot.id}`, loadEconomySettings())) {
        openPlotUpgradeMenu(player, plot);
        return;
      }
      target.hasProtectionUpgrade = true;
      addAccessLog(target, player.name, "purchased protection upgrade");
      savePlots(plots);
      player.sendMessage("\xA7a\u2714 Plot Lock Upgrade purchased! You can now lock and unlock plots remotely.");
      playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.plotshop_purchase", { volume: 1, pitch: 1.2 });
      openPlotUpgradeMenu(player, target);
    });
  }
  if (!plot.hasContainerShieldUpgrade) {
    form.button(`\xA75Container Shield
\xA78Blocks containers for 30s
\xA72$${CONTAINER_SHIELD_UPGRADE_COST}`);
    buttonActions.push(() => {
      const plots = loadPlots();
      const target = plots.find((p) => p.id === plot.id);
      if (!target || target.ownerId !== player.id || target.hasContainerShieldUpgrade) {
        player.sendMessage("\xA7cPlot not found or upgrade already owned.");
        openPlotUpgradeMenu(player, plot);
        return;
      }
      if (!spendMoney(player, CONTAINER_SHIELD_UPGRADE_COST, `container_shield:${plot.id}`, loadEconomySettings())) {
        openPlotUpgradeMenu(player, plot);
        return;
      }
      target.hasContainerShieldUpgrade = true;
      addAccessLog(target, player.name, "purchased container shield upgrade");
      savePlots(plots);
      player.sendMessage("\xA7a\u2714 Container Shield purchased! Containers will be blocked for 30s during raids.");
      playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.plotshop_purchase", { volume: 1, pitch: 1.2 });
      openPlotUpgradeMenu(player, target);
    });
  }
  form.button(`\xA73Member Slot +1
\xA78Raise member cap
\xA72$${MEMBER_SLOT_UPGRADE_COST}`);
  buttonActions.push(() => {
    const plots = loadPlots();
    const target = plots.find((p) => p.id === plot.id);
    if (!target || target.ownerId !== player.id) {
      player.sendMessage("\xA7cPlot not found.");
      openPlotUpgradeMenu(player, plot);
      return;
    }
    if (!spendMoney(player, MEMBER_SLOT_UPGRADE_COST, `member_slot:${plot.id}`, loadEconomySettings())) {
      openPlotUpgradeMenu(player, plot);
      return;
    }
    target.memberSlotUpgrade++;
    addAccessLog(target, player.name, `upgraded member slots to ${getMaxMembers(target)}`);
    savePlots(plots);
    player.sendMessage(`\xA7a\u2714 Member slot upgraded! Now \xA7e${getMaxMembers(target)}\xA7a max members.`);
    playSoundForPlayer(player, "com.plotshop_star_td3uf2sh.plotshop_purchase", { volume: 1, pitch: 1.2 });
    openPlotUpgradeMenu(player, target);
  });
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection < buttonActions.length) {
      buttonActions[res.selection]();
    } else {
      openMainMenu(player);
    }
  });
}
function assertEconomyAdmin(player) {
  if (isEconomyAdmin(player)) return true;
  player.sendMessage("\xA7cNo permission. Economy settings require the guiadmin tag.");
  return false;
}
function canCommitEconomyAdminEdit(player) {
  const lastEditTick = economyAdminEditCooldowns.get(player.id) ?? -ECONOMY_PURCHASE_COOLDOWN_TICKS;
  if (system.currentTick - lastEditTick < ECONOMY_PURCHASE_COOLDOWN_TICKS) {
    player.sendMessage("\xA7cPlease wait a moment before editing economy settings again.");
    return false;
  }
  economyAdminEditCooldowns.set(player.id, system.currentTick);
  return true;
}
function openAdminEconomySettings(player) {
  if (!assertEconomyAdmin(player)) return;
  const settings = loadEconomySettings();
  const form = new ActionFormData().title("\xA72Economy Settings").body(
    `\xA7fLive central config. No code edits needed.

\xA7fSell Values: \xA76${settings.sellableItems.length} fixed-order blocks\xA7f | Global x\xA7b${settings.sellGlobalMultiplier.toFixed(2)}
\xA7fMultiplier: \xA7bmax ${getConfiguredMultiplierMaxLevel(settings)}\xA7f, step \xA7b${getConfiguredMultiplierStep(settings).toFixed(2)}x\xA7f, \xA7e${settings.multiplierScalingMode}
\xA7fTax: \xA7c${settings.sellTaxPercent}% sell\xA7f, \xA7c${settings.auctionTaxPercent}% auction\xA7f | Boost: ${settings.economyBoostEnabled ? `\xA7aON x${settings.economyBoostMultiplier}` : "\xA77OFF"}
\xA7fRaid Entry: \xA72$${formatMoney(settings.raidEntryCost)}\xA7f | Plot Upkeep: \xA72$${formatMoney(settings.plotUpkeepCost)}`
  );
  form.button("\xA76Sell Prices");
  form.button("\xA7bMultipliers");
  form.button("\xA7aShops");
  form.button("\xA74Raid Tools");
  form.button("\xA7cTaxes and Limits");
  form.button("\xA7dPresets / Boost");
  form.button("\xA7eMessages");
  form.button("\xA73Sounds");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    switch (res.selection) {
      case 0:
        queueFormOpen(player, openAdminSellableItemsSettings);
        break;
      case 1:
        queueFormOpen(player, openAdminMultiplierCostSettings);
        break;
      case 2:
        queueFormOpen(player, openAdminShopSettings);
        break;
      case 3:
        queueFormOpen(player, openAdminCentralRaidEconomySettings);
        break;
      case 4:
        queueFormOpen(player, openAdminTaxesAndLimitsSettings);
        break;
      case 5:
        queueFormOpen(player, openAdminEconomyPresetsSettings);
        break;
      case 6:
        queueFormOpen(player, openAdminEconomyMessagesSettings);
        break;
      case 7:
        queueFormOpen(player, openAdminEconomySoundsSettings);
        break;
      default:
        queueFormOpen(player, openAdminMenu);
        break;
    }
  });
}
function serializeSellableItemsForAdmin(settings) {
  return settings.sellableItems.map((item) => `${item.itemId}|${item.name}|${item.category}|${item.price}`).join("; ");
}
function serializeSellableItemsMultiline(settings) {
  return settings.sellableItems.map((item) => `${item.itemId}|${item.price}|${item.name}|${item.category}`).join("\n");
}
function parseSellableItemsFromAdmin(value, fallback) {
  const parsed = [];
  for (const entry of value.split(/[\n;]+/)) {
    const parts = entry.trim().split("|");
    if (parts.length < 4) continue;
    const item = normalizeSellableItem({ itemId: parts[0], name: parts[1], category: parts[2], price: Number(parts[3]) });
    if (item) parsed.push(item);
  }
  return parsed.length > 0 ? parsed : fallback;
}
function parseSimpleSellableAppendList(value) {
  const parsed = [];
  for (const entry of value.split(/[\n;]+/)) {
    const parts = entry.trim().split("|").map((part) => part.trim());
    if (parts.length < 2) continue;
    const itemId = parts[0];
    const price = Number(parts[1]);
    const name = parts[2] || itemId.split(":")[1] || itemId;
    const category = parts[3] || "Generator Drops";
    const item = normalizeSellableItem({ itemId, price, name, category });
    if (item) parsed.push(item);
  }
  return parsed;
}
function openAdminSellableItemsSettings(player) {
  if (!assertEconomyAdmin(player)) return;
  const settings = loadEconomySettings();
  const defaultSettings = createDefaultEconomySettings();
  const mergedDefaultSellables = mergeSellablesWithSkygenCatalog(
    defaultSettings.sellableItems,
    defaultSettings.skygenCatalogVersion
  );
  defaultSettings.sellableItems = mergedDefaultSellables.items;
  defaultSettings.skygenCatalogVersion = mergedDefaultSellables.skygenCatalogVersion;
  const previewMultiplier = getConfiguredMultiplierForLevel(getObjectiveBalance(player.id, SKYGEN_MULTIPLIER_OBJECTIVE_ID, "Multiplier"), settings);
  const currentList = settings.sellableItems.map((item, index) => `${index + 1}. ${item.itemId} Base: $${item.price} x ${previewMultiplier.toFixed(2)} = $${calculateEffectiveSellValue(item.price, previewMultiplier, settings)}`).join("\n");
  const form = new ModalFormData().title("\xA76Sell Prices").textField("Current sell list (one per line: id|price|name|category)", "minecraft:diamond|80|Diamond|Rare Items", { defaultValue: serializeSellableItemsMultiline(settings) }).textField("Add new blocks quickly (one per line: id|price|optional name|optional category)", "minecraft:emerald|95|Emerald|Rare Items", { defaultValue: "" }).textField("Global multiplier for all blocks", `${settings.sellGlobalMultiplier}`, { defaultValue: `${settings.sellGlobalMultiplier}` }).toggle("Reset to exact default Skygen block list", { defaultValue: false }).textField("Current order preview", currentList, { defaultValue: currentList });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminEconomySettings(player);
      return;
    }
    if (!canCommitEconomyAdminEdit(player)) {
      openAdminEconomySettings(player);
      return;
    }
    if (Boolean(res.formValues[3])) {
      settings.sellableItems = defaultSettings.sellableItems;
      settings.skygenCatalogVersion = defaultSettings.skygenCatalogVersion;
    } else {
      const parsedBaseList = parseSimpleSellableAppendList(String(res.formValues[0] ?? ""));
      settings.sellableItems = (parsedBaseList.length > 0 ? parsedBaseList : settings.sellableItems).map((item) => ({ ...item, price: clampEconomyPrice(item.price, settings) }));
      const appendedItems = parseSimpleSellableAppendList(String(res.formValues[1] ?? ""));
      for (const item of appendedItems) {
        const existingIndex = settings.sellableItems.findIndex((entry) => entry.itemId === item.itemId);
        const normalized = { ...item, price: clampEconomyPrice(item.price, settings) };
        if (existingIndex >= 0) settings.sellableItems[existingIndex] = normalized;
        else settings.sellableItems.push(normalized);
      }
      settings.skygenCatalogVersion = Math.max(settings.skygenCatalogVersion ?? 0, defaultSettings.skygenCatalogVersion ?? 0);
    }
    settings.sellGlobalMultiplier = Math.max(0, parsePositiveNumber(String(res.formValues[2]), settings.sellGlobalMultiplier));
    saveEconomySettings(settings);
    player.sendMessage(`\xA7a\u2714 Sell prices updated instantly. Items: \xA7e${settings.sellableItems.length}\xA7a, global x\xA7b${settings.sellGlobalMultiplier.toFixed(2)}`);
    openAdminEconomySettings(player);
  });
}
function openAdminMultiplierCostSettings(player) {
  if (!assertEconomyAdmin(player)) return;
  const settings = loadEconomySettings();
  const scalingModes = ["fixed", "percentage"];
  const form = new ModalFormData().title("\xA7bMultipliers").textField("Comma-separated costs per level", "100000,450000,...", { defaultValue: settings.multiplierCosts.join(",") }).textField("Max multiplier level", `${settings.multiplierMaxLevel}`, { defaultValue: `${settings.multiplierMaxLevel}` }).textField("Increment size per level (0.10 or 0.05)", `${settings.multiplierIncrement}`, { defaultValue: `${settings.multiplierIncrement}` }).dropdown("Scaling mode", ["Fixed values", "Percentage growth"], { defaultValueIndex: scalingModes.indexOf(settings.multiplierScalingMode) }).textField("Growth percent when percentage mode is used", `${settings.multiplierGrowthPercent}`, { defaultValue: `${settings.multiplierGrowthPercent}` });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminEconomySettings(player);
      return;
    }
    if (!canCommitEconomyAdminEdit(player)) {
      openAdminEconomySettings(player);
      return;
    }
    const values = String(res.formValues[0] ?? "").split(",").map((v) => Math.max(0, Math.floor(Number(v.trim())))).filter((v) => Number.isFinite(v));
    if (values.length < 1) {
      player.sendMessage("\xA7cEnter at least one multiplier cost.");
      openAdminMultiplierCostSettings(player);
      return;
    }
    while (values.length < ECONOMY_MULTIPLIER_MAX_LEVEL) values.push(values[values.length - 1]);
    settings.multiplierCosts = values.slice(0, ECONOMY_MULTIPLIER_MAX_LEVEL);
    settings.multiplierMaxLevel = getConfiguredMultiplierMaxLevel({ ...settings, multiplierMaxLevel: Number(res.formValues[1]) });
    settings.multiplierIncrement = Math.max(0.01, parsePositiveNumber(String(res.formValues[2]), settings.multiplierIncrement));
    settings.multiplierScalingMode = scalingModes[Number(res.formValues[3])] ?? settings.multiplierScalingMode;
    settings.multiplierGrowthPercent = clampNumber(parsePositiveNumber(String(res.formValues[4]), settings.multiplierGrowthPercent), 0, 1e3);
    saveEconomySettings(settings);
    player.sendMessage(`\xA7a\u2714 Multiplier config updated. Max \xA7e${settings.multiplierMaxLevel}\xA7a, step \xA7b${settings.multiplierIncrement.toFixed(2)}x\xA7a.`);
    openAdminEconomySettings(player);
  });
}
function openAdminShopSettings(player) {
  if (!assertEconomyAdmin(player)) return;
  const settings = loadEconomySettings();
  const form = new ModalFormData().title("\xA7aShops").textField("Shop buy/sell list: id|name|category|buyPrice; add/remove by editing entries", "minecraft:diamond|Diamond|Rare Items|80", { defaultValue: serializeSellableItemsForAdmin({ ...settings, sellableItems: settings.shopItems.length > 0 ? settings.shopItems : settings.sellableItems }) }).textField("Bulk price multiplier for entered shop items", "1.00", { defaultValue: "1" }).dropdown("Category pricing focus", ECONOMY_CATEGORY_ORDER, { defaultValueIndex: 0 });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminEconomySettings(player);
      return;
    }
    if (!canCommitEconomyAdminEdit(player)) {
      openAdminEconomySettings(player);
      return;
    }
    const bulk = Math.max(0, parsePositiveNumber(String(res.formValues[1]), 1));
    settings.shopItems = parseSellableItemsFromAdmin(String(res.formValues[0] ?? ""), settings.shopItems).map((item) => ({ ...item, price: clampEconomyPrice(item.price * bulk, settings) }));
    saveEconomySettings(settings);
    player.sendMessage(`\xA7a\u2714 Shop price controls updated. Items: \xA7e${settings.shopItems.length}`);
    openAdminEconomySettings(player);
  });
}
function openAdminCentralRaidEconomySettings(player) {
  if (!assertEconomyAdmin(player)) return;
  const settings = loadEconomySettings();
  const raidSettings = loadRaidSettings();
  const form = new ModalFormData().title("\xA74Raid Tools").textField("Lockpick costs T1,T2,T3", "100000,500000,2000000", { defaultValue: raidSettings.toolCosts.join(",") }).textField("Success rates T1,T2,T3 (%)", "40,60,80", { defaultValue: raidSettings.baseSuccessRates.join(",") }).textField("Player cooldown seconds", `${raidSettings.playerCooldownSeconds}`, { defaultValue: `${raidSettings.playerCooldownSeconds}` }).textField("Raid entry cost", `${settings.raidEntryCost}`, { defaultValue: `${settings.raidEntryCost}` }).textField("Raid rewards placeholder", "Future reward pool", { defaultValue: "0" }).toggle("Future CTokens cost for T2", { defaultValue: raidSettings.useCTokensForTier2 }).toggle("Future CTokens cost for T3", { defaultValue: raidSettings.useCTokensForTier3 });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminEconomySettings(player);
      return;
    }
    if (!canCommitEconomyAdminEdit(player)) {
      openAdminEconomySettings(player);
      return;
    }
    const costs = String(res.formValues[0] ?? "").split(",").map((v) => Math.max(0, Math.floor(Number(v.trim()))));
    const rates = String(res.formValues[1] ?? "").split(",").map((v) => clampNumber(Number(v.trim()), 0, 100));
    if (costs.length === 3 && costs.every(Number.isFinite)) raidSettings.toolCosts = [costs[0], costs[1], costs[2]];
    if (rates.length === 3 && rates.every(Number.isFinite)) raidSettings.baseSuccessRates = [rates[0], rates[1], rates[2]];
    raidSettings.playerCooldownSeconds = Math.max(0, parsePositiveInteger(String(res.formValues[2]), raidSettings.playerCooldownSeconds));
    settings.raidEntryCost = Math.max(0, parsePositiveInteger(String(res.formValues[3]), settings.raidEntryCost));
    raidSettings.useCTokensForTier2 = Boolean(res.formValues[5]);
    raidSettings.useCTokensForTier3 = Boolean(res.formValues[6]);
    saveRaidSettings(raidSettings);
    saveEconomySettings(settings);
    player.sendMessage("\xA7a\u2714 Raid economy settings updated.");
    openAdminEconomySettings(player);
  });
}
function openAdminTaxesAndLimitsSettings(player) {
  if (!assertEconomyAdmin(player)) return;
  const settings = loadEconomySettings();
  const form = new ModalFormData().title("\xA7cTaxes and Limits").textField("Sell tax percentage", `${settings.sellTaxPercent}`, { defaultValue: `${settings.sellTaxPercent}` }).textField("Auction tax percentage", `${settings.auctionTaxPercent}`, { defaultValue: `${settings.auctionTaxPercent}` }).textField("Raid entry cost", `${settings.raidEntryCost}`, { defaultValue: `${settings.raidEntryCost}` }).textField("Plot upkeep cost", `${settings.plotUpkeepCost}`, { defaultValue: `${settings.plotUpkeepCost}` }).textField("Minimum sell price cap", `${settings.minPriceCap}`, { defaultValue: `${settings.minPriceCap}` }).textField("Maximum sell price cap", `${settings.maxPriceCap}`, { defaultValue: `${settings.maxPriceCap}` });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminEconomySettings(player);
      return;
    }
    if (!canCommitEconomyAdminEdit(player)) {
      openAdminEconomySettings(player);
      return;
    }
    settings.sellTaxPercent = clampNumber(parsePositiveNumber(String(res.formValues[0]), settings.sellTaxPercent), 0, 100);
    settings.auctionTaxPercent = clampNumber(parsePositiveNumber(String(res.formValues[1]), settings.auctionTaxPercent), 0, 100);
    settings.raidEntryCost = Math.max(0, parsePositiveInteger(String(res.formValues[2]), settings.raidEntryCost));
    settings.plotUpkeepCost = Math.max(0, parsePositiveInteger(String(res.formValues[3]), settings.plotUpkeepCost));
    settings.minPriceCap = Math.max(0, parsePositiveInteger(String(res.formValues[4]), settings.minPriceCap));
    settings.maxPriceCap = Math.max(settings.minPriceCap, parsePositiveInteger(String(res.formValues[5]), settings.maxPriceCap));
    saveEconomySettings(settings);
    player.sendMessage("\xA7a\u2714 Taxes and safety limits updated.");
    openAdminEconomySettings(player);
  });
}
function openAdminEconomyPresetsSettings(player) {
  if (!assertEconomyAdmin(player)) return;
  const settings = loadEconomySettings();
  const presets = ["Keep current", "Default", "High grind", "Fast economy"];
  const form = new ModalFormData().title("\xA7dPresets / Boost").dropdown("Switch setup instantly", presets, { defaultValueIndex: 0 }).toggle("Economy boost enabled", { defaultValue: settings.economyBoostEnabled }).textField("Economy boost multiplier", `${settings.economyBoostMultiplier}`, { defaultValue: `${settings.economyBoostMultiplier}` });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminEconomySettings(player);
      return;
    }
    if (!canCommitEconomyAdminEdit(player)) {
      openAdminEconomySettings(player);
      return;
    }
    const presetIndex = Number(res.formValues[0]);
    let nextSettings = settings;
    if (presetIndex === 1) nextSettings = createPresetEconomySettings("default");
    if (presetIndex === 2) nextSettings = createPresetEconomySettings("high_grind");
    if (presetIndex === 3) nextSettings = createPresetEconomySettings("fast_economy");
    nextSettings.economyBoostEnabled = Boolean(res.formValues[1]);
    nextSettings.economyBoostMultiplier = Math.max(0, parsePositiveNumber(String(res.formValues[2]), nextSettings.economyBoostMultiplier));
    saveEconomySettings(nextSettings);
    player.sendMessage(`\xA7a\u2714 Economy preset/boost updated: \xA7e${presets[presetIndex] ?? "Keep current"}`);
    openAdminEconomySettings(player);
  });
}
function openAdminEconomyMessagesSettings(player) {
  if (!assertEconomyAdmin(player)) return;
  const settings = loadEconomySettings();
  const form = new ModalFormData().title("\xA7eEconomy Messages").textField("Sell message template", "Sold items for: ${earned}", { defaultValue: settings.messageSellTemplate }).textField("Purchase message template", "Upgrade purchased: {item} Cost: ${cost}", { defaultValue: settings.messagePurchaseTemplate }).textField("Need more money template", "You need ${missing} more to buy this.", { defaultValue: settings.messageNeedMoreTemplate });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminEconomySettings(player);
      return;
    }
    settings.messageSellTemplate = String(res.formValues[0] ?? settings.messageSellTemplate);
    settings.messagePurchaseTemplate = String(res.formValues[1] ?? settings.messagePurchaseTemplate);
    settings.messageNeedMoreTemplate = String(res.formValues[2] ?? settings.messageNeedMoreTemplate);
    saveEconomySettings(settings);
    player.sendMessage("\xA7a\u2714 Economy messages updated.");
    openAdminEconomySettings(player);
  });
}
function openAdminEconomySoundsSettings(player) {
  if (!assertEconomyAdmin(player)) return;
  const settings = loadEconomySettings();
  const form = new ModalFormData().title("\xA73Economy Sounds").textField("Purchase/reward sound id", settings.soundPurchase, { defaultValue: settings.soundPurchase }).textField("Error sound id", settings.soundError, { defaultValue: settings.soundError });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminEconomySettings(player);
      return;
    }
    settings.soundPurchase = String(res.formValues[0] ?? settings.soundPurchase).trim() || settings.soundPurchase;
    settings.soundError = String(res.formValues[1] ?? settings.soundError).trim() || settings.soundError;
    saveEconomySettings(settings);
    player.sendMessage("\xA7a\u2714 Economy sounds updated.");
    openAdminEconomySettings(player);
  });
}
function openAdminMenu(player) {
  if (!isAdmin(player)) {
    player.sendMessage("\xA7cYou need the plotadmin tag to manage plots.");
    return;
  }
  const form = new ActionFormData().title("\xA74Admin: PlotShop").body("\xA7fManage all plots on this server.");
  form.button("\xA72Create Plot");
  form.button("\xA72Bulk Create");
  form.button("\xA7cDelete Plot");
  form.button("\xA76Edit Plot");
  form.button("\xA7dAssign Owner");
  form.button("\xA77Reset Plot");
  form.button("\xA7bView All Plots");
  form.button("\xA75Defense Settings");
  form.button("\xA74Raid Settings");
  form.button("\xA7bOrganize Plot Numbers");
  if (isEconomyAdmin(player)) form.button("\xA72Economy Settings");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    switch (res.selection) {
      case 0:
        queueFormOpen(player, openAdminCreateStep1);
        break;
      case 1:
        queueFormOpen(player, openBulkCreateMenu);
        break;
      case 2:
        queueFormOpen(player, openAdminDeleteMenu);
        break;
      case 3:
        queueFormOpen(player, openAdminEditMenu);
        break;
      case 4:
        queueFormOpen(player, openAdminAssignOwner);
        break;
      case 5:
        queueFormOpen(player, openAdminResetMenu);
        break;
      case 6:
        system.run(() => openAdminViewPlots(player, 0));
        break;
      case 7:
        queueFormOpen(player, openAdminDefenseSettings);
        break;
      case 8:
        queueFormOpen(player, openAdminRaidSettings);
        break;
      case 9:
        queueFormOpen(player, openAdminOrganizePlotsConfirm);
        break;
      case 10:
        if (isEconomyAdmin(player)) queueFormOpen(player, openAdminEconomySettings);
        else queueFormOpen(player, openMainMenu);
        break;
      default:
        queueFormOpen(player, openMainMenu);
        break;
    }
  });
}
function openAdminOrganizePlotsConfirm(player) {
  const plots = loadPlots();
  const form = new MessageFormData().title("\xA7bOrganize Plot Numbers").body(
    `\xA7fRenumber \xA7e${plots.length}\xA7f plots in clean layout order.

\xA7fSide A: \xA7ePlots 1-12
\xA7fSide B: \xA7ePlots 13-24
\xA7fSide C: \xA7ePlots 25-36
\xA7fSide D: \xA7ePlots 37-48

\xA78Ownership, upgrades, prices, members, and logs stay on the same physical plots.`
  ).button1("\xA7bOrganize").button2("\xA78Cancel");
  form.show(player).then((res) => {
    if (res.canceled || res.selection !== 0) {
      openAdminMenu(player);
      return;
    }
    const freshPlots = loadPlots();
    const changed = standardizePlotNumbering(freshPlots);
    savePlots(freshPlots);
    world.setDynamicProperty(PLOT_LAYOUT_VERSION_KEY, CURRENT_PLOT_LAYOUT_VERSION);
    player.sendMessage(changed ? "\xA7a\u2714 Plots renumbered into Side A-D order." : "\xA7a\u2714 Plot numbering was already organized.");
    openAdminViewPlots(player, 0);
  });
}
function openAdminDefenseSettings(player) {
  if (!isAdmin(player)) {
    player.sendMessage("\xA7cNo permission");
    return;
  }
  const settings = loadDefenseSettings();
  const form = new ActionFormData().title("\xA75Defense Settings").body(
    `\xA7fConfigure scalable plot defense upgrades and upkeep.

\xA7fLock Strength: \xA7e+${settings.lockStrengthExtraSeconds[0]}/${settings.lockStrengthExtraSeconds[1]}/${settings.lockStrengthExtraSeconds[2]}s\xA7f | \xA7c-${settings.lockStrengthSuccessPenaltyPercent[0]}/${settings.lockStrengthSuccessPenaltyPercent[1]}/${settings.lockStrengthSuccessPenaltyPercent[2]}%
\xA7fAlarm Duration: \xA7e${settings.alarmDurationsSeconds[0]}/${settings.alarmDurationsSeconds[1]}/${settings.alarmDurationsSeconds[2]}s
\xA7fContainer Delay: \xA7e${settings.reinforcedContainerDelaySeconds[0]}/${settings.reinforcedContainerDelaySeconds[1]}/${settings.reinforcedContainerDelaySeconds[2]}s
\xA7fUpkeep: \xA76${settings.upkeepPercentOfBalance}%\xA7f every \xA7e${getUpkeepIntervalLabel(settings)}\xA7f${settings.upkeepCapEnabled ? ` \xA78(cap \xA72$${formatCompactCurrency(settings.upkeepDailyCap)}\xA78)` : ""}
\xA7fTier 3 Limit: \xA7e${settings.maxTier3UpgradeTypes}\xA7f | Extra Plot Cost Scale: \xA7e${settings.extraPlotCostScalePercent}%`
  );
  form.button("\xA76Lock Strength");
  form.button("\xA7cAlarm Basics");
  form.button("\xA7dAlarm Effects");
  form.button("\xA73Reinforced Containers");
  form.button("\xA7eUpkeep & Limits");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    switch (res.selection) {
      case 0:
        queueFormOpen(player, openAdminDefenseLockStrengthSettings);
        break;
      case 1:
        queueFormOpen(player, openAdminDefenseAlarmBasicSettings);
        break;
      case 2:
        queueFormOpen(player, openAdminDefenseAlarmEffectSettings);
        break;
      case 3:
        queueFormOpen(player, openAdminDefenseContainerSettings);
        break;
      case 4:
        queueFormOpen(player, openAdminDefenseUpkeepSettings);
        break;
      default:
        queueFormOpen(player, openAdminMenu);
        break;
    }
  });
}
function openAdminDefenseLockStrengthSettings(player) {
  const settings = loadDefenseSettings();
  const form = new ModalFormData().title("\xA76Lock Strength Settings").textField("Tier 1 cost", `${settings.lockStrengthCosts[0]}`, { defaultValue: `${settings.lockStrengthCosts[0]}` }).textField("Tier 2 cost", `${settings.lockStrengthCosts[1]}`, { defaultValue: `${settings.lockStrengthCosts[1]}` }).textField("Tier 3 cost", `${settings.lockStrengthCosts[2]}`, { defaultValue: `${settings.lockStrengthCosts[2]}` }).textField("Tier 1 extra lockpick time (seconds)", `${settings.lockStrengthExtraSeconds[0]}`, { defaultValue: `${settings.lockStrengthExtraSeconds[0]}` }).textField("Tier 2 extra lockpick time (seconds)", `${settings.lockStrengthExtraSeconds[1]}`, { defaultValue: `${settings.lockStrengthExtraSeconds[1]}` }).textField("Tier 3 extra lockpick time (seconds)", `${settings.lockStrengthExtraSeconds[2]}`, { defaultValue: `${settings.lockStrengthExtraSeconds[2]}` }).textField("Tier 1 success penalty (%)", `${settings.lockStrengthSuccessPenaltyPercent[0]}`, { defaultValue: `${settings.lockStrengthSuccessPenaltyPercent[0]}` }).textField("Tier 2 success penalty (%)", `${settings.lockStrengthSuccessPenaltyPercent[1]}`, { defaultValue: `${settings.lockStrengthSuccessPenaltyPercent[1]}` }).textField("Tier 3 success penalty (%)", `${settings.lockStrengthSuccessPenaltyPercent[2]}`, { defaultValue: `${settings.lockStrengthSuccessPenaltyPercent[2]}` });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminDefenseSettings(player);
      return;
    }
    settings.lockStrengthCosts = [
      Math.max(0, parsePositiveInteger(String(res.formValues[0]), settings.lockStrengthCosts[0])),
      Math.max(0, parsePositiveInteger(String(res.formValues[1]), settings.lockStrengthCosts[1])),
      Math.max(0, parsePositiveInteger(String(res.formValues[2]), settings.lockStrengthCosts[2]))
    ];
    settings.lockStrengthExtraSeconds = [
      Math.max(0, parsePositiveNumber(String(res.formValues[3]), settings.lockStrengthExtraSeconds[0])),
      Math.max(0, parsePositiveNumber(String(res.formValues[4]), settings.lockStrengthExtraSeconds[1])),
      Math.max(0, parsePositiveNumber(String(res.formValues[5]), settings.lockStrengthExtraSeconds[2]))
    ];
    settings.lockStrengthSuccessPenaltyPercent = [
      clampNumber(parsePositiveNumber(String(res.formValues[6]), settings.lockStrengthSuccessPenaltyPercent[0]), 0, 100),
      clampNumber(parsePositiveNumber(String(res.formValues[7]), settings.lockStrengthSuccessPenaltyPercent[1]), 0, 100),
      clampNumber(parsePositiveNumber(String(res.formValues[8]), settings.lockStrengthSuccessPenaltyPercent[2]), 0, 100)
    ];
    saveDefenseSettings(settings);
    player.sendMessage("\xA7a\u2714 Lock Strength settings updated.");
    openAdminDefenseSettings(player);
  });
}
function openAdminDefenseAlarmBasicSettings(player) {
  const settings = loadDefenseSettings();
  const form = new ModalFormData().title("\xA7cAlarm Basic Settings").textField("Tier 1 cost", `${settings.alarmCosts[0]}`, { defaultValue: `${settings.alarmCosts[0]}` }).textField("Tier 2 cost", `${settings.alarmCosts[1]}`, { defaultValue: `${settings.alarmCosts[1]}` }).textField("Tier 3 cost", `${settings.alarmCosts[2]}`, { defaultValue: `${settings.alarmCosts[2]}` }).textField("Tier 1 pulse duration (seconds)", `${settings.alarmDurationsSeconds[0]}`, { defaultValue: `${settings.alarmDurationsSeconds[0]}` }).textField("Tier 2 pulse duration (seconds)", `${settings.alarmDurationsSeconds[1]}`, { defaultValue: `${settings.alarmDurationsSeconds[1]}` }).textField("Tier 3 pulse duration (seconds)", `${settings.alarmDurationsSeconds[2]}`, { defaultValue: `${settings.alarmDurationsSeconds[2]}` }).toggle("Pulse on lockpick start", { defaultValue: settings.alarmPulseOnLockpickStart }).toggle("Extra Tier 3 breach pulse", { defaultValue: settings.alarmPulseOnTier3Breach }).textField("Tier 3 breach pulse duration (seconds)", `${settings.alarmTier3BreachPulseSeconds}`, { defaultValue: `${settings.alarmTier3BreachPulseSeconds}` });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminDefenseSettings(player);
      return;
    }
    settings.alarmCosts = [
      Math.max(0, parsePositiveInteger(String(res.formValues[0]), settings.alarmCosts[0])),
      Math.max(0, parsePositiveInteger(String(res.formValues[1]), settings.alarmCosts[1])),
      Math.max(0, parsePositiveInteger(String(res.formValues[2]), settings.alarmCosts[2]))
    ];
    settings.alarmDurationsSeconds = [
      Math.max(1, parsePositiveNumber(String(res.formValues[3]), settings.alarmDurationsSeconds[0])),
      Math.max(1, parsePositiveNumber(String(res.formValues[4]), settings.alarmDurationsSeconds[1])),
      Math.max(1, parsePositiveNumber(String(res.formValues[5]), settings.alarmDurationsSeconds[2]))
    ];
    settings.alarmPulseOnLockpickStart = Boolean(res.formValues[6]);
    settings.alarmPulseOnTier3Breach = Boolean(res.formValues[7]);
    settings.alarmTier3BreachPulseSeconds = Math.max(1, parsePositiveNumber(String(res.formValues[8]), settings.alarmTier3BreachPulseSeconds));
    saveDefenseSettings(settings);
    player.sendMessage("\xA7a\u2714 Alarm basic settings updated.");
    openAdminDefenseSettings(player);
  });
}
function openAdminDefenseAlarmEffectSettings(player) {
  const settings = loadDefenseSettings();
  const form = new ModalFormData().title("\xA7dAlarm Effect Slots").textField("Tier 1 effect slot 1 id", settings.alarmEffect1Ids[0], { defaultValue: settings.alarmEffect1Ids[0] }).textField("Tier 1 effect slot 1 amplifier", `${settings.alarmEffect1Amplifiers[0]}`, { defaultValue: `${settings.alarmEffect1Amplifiers[0]}` }).textField("Tier 1 effect slot 2 id", settings.alarmEffect2Ids[0], { defaultValue: settings.alarmEffect2Ids[0] }).textField("Tier 1 effect slot 2 amplifier", `${settings.alarmEffect2Amplifiers[0]}`, { defaultValue: `${settings.alarmEffect2Amplifiers[0]}` }).textField("Tier 1 effect slot 3 id (blank to disable)", settings.alarmEffect3Ids[0], { defaultValue: settings.alarmEffect3Ids[0] }).textField("Tier 1 effect slot 3 amplifier", `${settings.alarmEffect3Amplifiers[0]}`, { defaultValue: `${settings.alarmEffect3Amplifiers[0]}` }).textField("Tier 2 effect slot 1 id", settings.alarmEffect1Ids[1], { defaultValue: settings.alarmEffect1Ids[1] }).textField("Tier 2 effect slot 1 amplifier", `${settings.alarmEffect1Amplifiers[1]}`, { defaultValue: `${settings.alarmEffect1Amplifiers[1]}` }).textField("Tier 2 effect slot 2 id", settings.alarmEffect2Ids[1], { defaultValue: settings.alarmEffect2Ids[1] }).textField("Tier 2 effect slot 2 amplifier", `${settings.alarmEffect2Amplifiers[1]}`, { defaultValue: `${settings.alarmEffect2Amplifiers[1]}` }).textField("Tier 2 effect slot 3 id", settings.alarmEffect3Ids[1], { defaultValue: settings.alarmEffect3Ids[1] }).textField("Tier 2 effect slot 3 amplifier", `${settings.alarmEffect3Amplifiers[1]}`, { defaultValue: `${settings.alarmEffect3Amplifiers[1]}` }).textField("Tier 3 effect slot 1 id", settings.alarmEffect1Ids[2], { defaultValue: settings.alarmEffect1Ids[2] }).textField("Tier 3 effect slot 1 amplifier", `${settings.alarmEffect1Amplifiers[2]}`, { defaultValue: `${settings.alarmEffect1Amplifiers[2]}` }).textField("Tier 3 effect slot 2 id", settings.alarmEffect2Ids[2], { defaultValue: settings.alarmEffect2Ids[2] }).textField("Tier 3 effect slot 2 amplifier", `${settings.alarmEffect2Amplifiers[2]}`, { defaultValue: `${settings.alarmEffect2Amplifiers[2]}` }).textField("Tier 3 effect slot 3 id", settings.alarmEffect3Ids[2], { defaultValue: settings.alarmEffect3Ids[2] }).textField("Tier 3 effect slot 3 amplifier", `${settings.alarmEffect3Amplifiers[2]}`, { defaultValue: `${settings.alarmEffect3Amplifiers[2]}` });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminDefenseSettings(player);
      return;
    }
    settings.alarmEffect1Ids = [
      String(res.formValues[0] ?? settings.alarmEffect1Ids[0]).trim(),
      String(res.formValues[6] ?? settings.alarmEffect1Ids[1]).trim(),
      String(res.formValues[12] ?? settings.alarmEffect1Ids[2]).trim()
    ];
    settings.alarmEffect1Amplifiers = [
      Math.max(0, parsePositiveInteger(String(res.formValues[1]), settings.alarmEffect1Amplifiers[0])),
      Math.max(0, parsePositiveInteger(String(res.formValues[7]), settings.alarmEffect1Amplifiers[1])),
      Math.max(0, parsePositiveInteger(String(res.formValues[13]), settings.alarmEffect1Amplifiers[2]))
    ];
    settings.alarmEffect2Ids = [
      String(res.formValues[2] ?? settings.alarmEffect2Ids[0]).trim(),
      String(res.formValues[8] ?? settings.alarmEffect2Ids[1]).trim(),
      String(res.formValues[14] ?? settings.alarmEffect2Ids[2]).trim()
    ];
    settings.alarmEffect2Amplifiers = [
      Math.max(0, parsePositiveInteger(String(res.formValues[3]), settings.alarmEffect2Amplifiers[0])),
      Math.max(0, parsePositiveInteger(String(res.formValues[9]), settings.alarmEffect2Amplifiers[1])),
      Math.max(0, parsePositiveInteger(String(res.formValues[15]), settings.alarmEffect2Amplifiers[2]))
    ];
    settings.alarmEffect3Ids = [
      String(res.formValues[4] ?? settings.alarmEffect3Ids[0]).trim(),
      String(res.formValues[10] ?? settings.alarmEffect3Ids[1]).trim(),
      String(res.formValues[16] ?? settings.alarmEffect3Ids[2]).trim()
    ];
    settings.alarmEffect3Amplifiers = [
      Math.max(0, parsePositiveInteger(String(res.formValues[5]), settings.alarmEffect3Amplifiers[0])),
      Math.max(0, parsePositiveInteger(String(res.formValues[11]), settings.alarmEffect3Amplifiers[1])),
      Math.max(0, parsePositiveInteger(String(res.formValues[17]), settings.alarmEffect3Amplifiers[2]))
    ];
    saveDefenseSettings(settings);
    player.sendMessage("\xA7a\u2714 Alarm effect slots updated.");
    openAdminDefenseSettings(player);
  });
}
function openAdminDefenseContainerSettings(player) {
  const settings = loadDefenseSettings();
  const form = new ModalFormData().title("\xA73Reinforced Container Settings").textField("Tier 1 cost", `${settings.reinforcedContainerCosts[0]}`, { defaultValue: `${settings.reinforcedContainerCosts[0]}` }).textField("Tier 2 cost", `${settings.reinforcedContainerCosts[1]}`, { defaultValue: `${settings.reinforcedContainerCosts[1]}` }).textField("Tier 3 cost", `${settings.reinforcedContainerCosts[2]}`, { defaultValue: `${settings.reinforcedContainerCosts[2]}` }).textField("Tier 1 open delay (seconds)", `${settings.reinforcedContainerDelaySeconds[0]}`, { defaultValue: `${settings.reinforcedContainerDelaySeconds[0]}` }).textField("Tier 2 open delay (seconds)", `${settings.reinforcedContainerDelaySeconds[1]}`, { defaultValue: `${settings.reinforcedContainerDelaySeconds[1]}` }).textField("Tier 3 open delay (seconds)", `${settings.reinforcedContainerDelaySeconds[2]}`, { defaultValue: `${settings.reinforcedContainerDelaySeconds[2]}` });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminDefenseSettings(player);
      return;
    }
    settings.reinforcedContainerCosts = [
      Math.max(0, parsePositiveInteger(String(res.formValues[0]), settings.reinforcedContainerCosts[0])),
      Math.max(0, parsePositiveInteger(String(res.formValues[1]), settings.reinforcedContainerCosts[1])),
      Math.max(0, parsePositiveInteger(String(res.formValues[2]), settings.reinforcedContainerCosts[2]))
    ];
    settings.reinforcedContainerDelaySeconds = [
      Math.max(0, parsePositiveNumber(String(res.formValues[3]), settings.reinforcedContainerDelaySeconds[0])),
      Math.max(0, parsePositiveNumber(String(res.formValues[4]), settings.reinforcedContainerDelaySeconds[1])),
      Math.max(0, parsePositiveNumber(String(res.formValues[5]), settings.reinforcedContainerDelaySeconds[2]))
    ];
    saveDefenseSettings(settings);
    player.sendMessage("\xA7a\u2714 Reinforced container settings updated.");
    openAdminDefenseSettings(player);
  });
}
function openAdminDefenseUpkeepSettings(player) {
  const settings = loadDefenseSettings();
  const form = new ModalFormData().title("\xA7eDefense Upkeep & Limits").textField("Max upgrade types at Tier 3", `${settings.maxTier3UpgradeTypes}`, { defaultValue: `${settings.maxTier3UpgradeTypes}` }).textField("Extra plot cost scaling per owned plot (%)", `${settings.extraPlotCostScalePercent}`, { defaultValue: `${settings.extraPlotCostScalePercent}` }).textField("Upkeep percent of balance per charge", `${settings.upkeepPercentOfBalance}`, { defaultValue: `${settings.upkeepPercentOfBalance}` }).toggle("Enable daily cap", { defaultValue: settings.upkeepCapEnabled }).textField("Upkeep cap amount", `${settings.upkeepDailyCap}`, { defaultValue: `${settings.upkeepDailyCap}` }).textField("Upkeep charge interval (ticks)", `${settings.upkeepChargeIntervalTicks}`, { defaultValue: `${settings.upkeepChargeIntervalTicks}` });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminDefenseSettings(player);
      return;
    }
    settings.maxTier3UpgradeTypes = clampNumber(parsePositiveInteger(String(res.formValues[0]), settings.maxTier3UpgradeTypes), 0, 3);
    settings.extraPlotCostScalePercent = clampNumber(parsePositiveInteger(String(res.formValues[1]), settings.extraPlotCostScalePercent), 0, 500);
    settings.upkeepPercentOfBalance = clampNumber(parsePositiveNumber(String(res.formValues[2]), settings.upkeepPercentOfBalance), 0, 100);
    settings.upkeepCapEnabled = Boolean(res.formValues[3]);
    settings.upkeepDailyCap = Math.max(0, parsePositiveInteger(String(res.formValues[4]), settings.upkeepDailyCap));
    settings.upkeepChargeIntervalTicks = Math.max(20, parsePositiveInteger(String(res.formValues[5]), settings.upkeepChargeIntervalTicks));
    saveDefenseSettings(settings);
    player.sendMessage("\xA7a\u2714 Defense upkeep and limits updated.");
    openAdminDefenseSettings(player);
  });
}
function openAdminRaidSettings(player) {
  if (!isAdmin(player)) {
    player.sendMessage("\xA7cNo permission");
    return;
  }
  const settings = loadRaidSettings();
  const form = new ActionFormData().title("\xA74Raid Settings").body(
    `\xA7fAdmins only. Configure all raid values from this panel.

\xA7fWindow: \xA7e${settings.breachDurationSeconds}s\xA7f | Cooldowns: \xA7e${settings.playerCooldownSeconds}s / ${settings.plotCooldownMinutes}m\xA7f
\xA7fNight Only: ${settings.nightOnly ? "\xA72On" : "\xA74Off"}\xA7f | Owner Online: ${settings.requireOwnerOnline ? "\xA72On" : "\xA74Off"}\xA7f
\xA7fEntry: \xA76${getEntryModeLabel(settings.entryMode)}\xA7f | Penalty: \xA7c${getFailPenaltyLabel(settings.failPenaltyMode)}\xA7f
\xA7fBroadcasts: ${settings.broadcastOnBreach ? "\xA72On" : "\xA74Off"}\xA7f | Max Raids: \xA7e${settings.maxRaidsPerPlayer || 0}`
  );
  form.button("\xA76Timing & Requirements");
  form.button("\xA7cSuccess & Difficulty");
  form.button("\xA72Economy & Repair");
  form.button("\xA7eCooldowns & Anti-Abuse");
  form.button("\xA73Access & Alerts");
  form.button("\xA75Advanced Options");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    switch (res.selection) {
      case 0:
        queueFormOpen(player, openAdminRaidTimingSettings);
        break;
      case 1:
        queueFormOpen(player, openAdminRaidSuccessSettings);
        break;
      case 2:
        queueFormOpen(player, openAdminRaidEconomySettings);
        break;
      case 3:
        queueFormOpen(player, openAdminRaidCooldownSettings);
        break;
      case 4:
        queueFormOpen(player, openAdminRaidAccessSettings);
        break;
      case 5:
        queueFormOpen(player, openAdminRaidAdvancedOptions);
        break;
      default:
        queueFormOpen(player, openAdminMenu);
        break;
    }
  });
}
function openAdminRaidTimingSettings(player) {
  const settings = loadRaidSettings();
  const form = new ModalFormData().title("\xA76Raid Timing & Requirements").textField("Raid window duration (30-180 seconds)", `${settings.breachDurationSeconds}`, { defaultValue: `${settings.breachDurationSeconds}` }).textField("Tier 1 lockpick time (5-30 seconds)", `${settings.pickTimesSeconds[0]}`, { defaultValue: `${settings.pickTimesSeconds[0]}` }).textField("Tier 2 lockpick time (5-30 seconds)", `${settings.pickTimesSeconds[1]}`, { defaultValue: `${settings.pickTimesSeconds[1]}` }).textField("Tier 3 lockpick time (5-30 seconds)", `${settings.pickTimesSeconds[2]}`, { defaultValue: `${settings.pickTimesSeconds[2]}` }).toggle("Night-only raids", { defaultValue: settings.nightOnly }).toggle("Owner must be online", { defaultValue: settings.requireOwnerOnline }).toggle("Movement cancels lockpicking", { defaultValue: settings.movementCancels });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminRaidSettings(player);
      return;
    }
    settings.breachDurationSeconds = clampNumber(parsePositiveInteger(String(res.formValues[0]), settings.breachDurationSeconds), 30, 180);
    settings.pickTimesSeconds = [
      clampNumber(parsePositiveInteger(String(res.formValues[1]), settings.pickTimesSeconds[0]), 5, 30),
      clampNumber(parsePositiveInteger(String(res.formValues[2]), settings.pickTimesSeconds[1]), 5, 30),
      clampNumber(parsePositiveInteger(String(res.formValues[3]), settings.pickTimesSeconds[2]), 5, 30)
    ];
    settings.nightOnly = Boolean(res.formValues[4]);
    settings.requireOwnerOnline = Boolean(res.formValues[5]);
    settings.movementCancels = Boolean(res.formValues[6]);
    saveRaidSettings(settings);
    player.sendMessage("\xA7a\u2714 Raid timing settings updated.");
    openAdminRaidSettings(player);
  });
}
function openAdminRaidSuccessSettings(player) {
  const settings = loadRaidSettings();
  const failPenaltyModes = ["break_item", "cooldown", "both"];
  const scalingModes = ["success", "time", "hybrid"];
  const form = new ModalFormData().title("\xA7cRaid Success & Difficulty").textField("Tier 1 success rate (%)", `${settings.baseSuccessRates[0]}`, { defaultValue: `${settings.baseSuccessRates[0]}` }).textField("Tier 2 success rate (%)", `${settings.baseSuccessRates[1]}`, { defaultValue: `${settings.baseSuccessRates[1]}` }).textField("Tier 3 success rate (%)", `${settings.baseSuccessRates[2]}`, { defaultValue: `${settings.baseSuccessRates[2]}` }).dropdown("Fail penalty", ["Break Item", "Cooldown", "Both"], { defaultValueIndex: failPenaltyModes.indexOf(settings.failPenaltyMode) }).dropdown("Tier scaling", ["Success", "Faster Time", "Hybrid"], { defaultValueIndex: scalingModes.indexOf(settings.tierScalingMode) }).textField("Extra success bonus per tier (%)", `${settings.tierSuccessBonus}`, { defaultValue: `${settings.tierSuccessBonus}` }).textField("Extra time reduction per tier (seconds)", `${settings.tierTimeReductionSeconds}`, { defaultValue: `${settings.tierTimeReductionSeconds}` });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminRaidSettings(player);
      return;
    }
    settings.baseSuccessRates = [
      clampNumber(parsePositiveInteger(String(res.formValues[0]), settings.baseSuccessRates[0]), 1, 100),
      clampNumber(parsePositiveInteger(String(res.formValues[1]), settings.baseSuccessRates[1]), 1, 100),
      clampNumber(parsePositiveInteger(String(res.formValues[2]), settings.baseSuccessRates[2]), 1, 100)
    ];
    settings.failPenaltyMode = failPenaltyModes[Number(res.formValues[3]) ?? failPenaltyModes.indexOf(settings.failPenaltyMode)] ?? settings.failPenaltyMode;
    settings.tierScalingMode = scalingModes[Number(res.formValues[4]) ?? scalingModes.indexOf(settings.tierScalingMode)] ?? settings.tierScalingMode;
    settings.tierSuccessBonus = clampNumber(parsePositiveInteger(String(res.formValues[5]), settings.tierSuccessBonus), 0, 100);
    settings.tierTimeReductionSeconds = clampNumber(parsePositiveInteger(String(res.formValues[6]), settings.tierTimeReductionSeconds), 0, 25);
    saveRaidSettings(settings);
    player.sendMessage("\xA7a\u2714 Raid difficulty settings updated.");
    openAdminRaidSettings(player);
  });
}
function openAdminRaidEconomySettings(player) {
  const settings = loadRaidSettings();
  const form = new ModalFormData().title("\xA72Raid Economy & Repair").textField("Tier 1 tool cost ($)", `${settings.toolCosts[0]}`, { defaultValue: `${settings.toolCosts[0]}` }).textField("Tier 2 tool cost ($)", `${settings.toolCosts[1]}`, { defaultValue: `${settings.toolCosts[1]}` }).textField("Tier 3 tool cost ($)", `${settings.toolCosts[2]}`, { defaultValue: `${settings.toolCosts[2]}` }).textField("Money cost scaling per tier (%)", `${settings.costScalePercent}`, { defaultValue: `${settings.costScalePercent}` }).toggle("Enable repairs instead of rebuy only", { defaultValue: settings.repairEnabled }).textField("Repair cost percent of tool value", `${settings.repairCostPercent}`, { defaultValue: `${settings.repairCostPercent}` }).toggle("Use CTokens for Tier 2", { defaultValue: settings.useCTokensForTier2 }).toggle("Use CTokens for Tier 3", { defaultValue: settings.useCTokensForTier3 }).textField("Tier 2 CToken cost", `${settings.ctokenCosts[1]}`, { defaultValue: `${settings.ctokenCosts[1]}` }).textField("Tier 3 CToken cost", `${settings.ctokenCosts[2]}`, { defaultValue: `${settings.ctokenCosts[2]}` });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminRaidSettings(player);
      return;
    }
    settings.toolCosts = [
      Math.max(0, parsePositiveInteger(String(res.formValues[0]), settings.toolCosts[0])),
      Math.max(0, parsePositiveInteger(String(res.formValues[1]), settings.toolCosts[1])),
      Math.max(0, parsePositiveInteger(String(res.formValues[2]), settings.toolCosts[2]))
    ];
    settings.costScalePercent = clampNumber(parsePositiveInteger(String(res.formValues[3]), settings.costScalePercent), 0, 500);
    settings.repairEnabled = Boolean(res.formValues[4]);
    settings.repairCostPercent = clampNumber(parsePositiveInteger(String(res.formValues[5]), settings.repairCostPercent), 1, 100);
    settings.useCTokensForTier2 = Boolean(res.formValues[6]);
    settings.useCTokensForTier3 = Boolean(res.formValues[7]);
    settings.ctokenCosts = [
      0,
      Math.max(0, parsePositiveInteger(String(res.formValues[8]), settings.ctokenCosts[1])),
      Math.max(0, parsePositiveInteger(String(res.formValues[9]), settings.ctokenCosts[2]))
    ];
    saveRaidSettings(settings);
    player.sendMessage("\xA7a\u2714 Raid economy settings updated.");
    openAdminRaidSettings(player);
  });
}
function openAdminRaidCooldownSettings(player) {
  const settings = loadRaidSettings();
  const form = new ModalFormData().title("\xA7eRaid Cooldowns & Anti-Abuse").textField("Player cooldown (15-60 seconds)", `${settings.playerCooldownSeconds}`, { defaultValue: `${settings.playerCooldownSeconds}` }).textField("Plot cooldown (5-30 minutes)", `${settings.plotCooldownMinutes}`, { defaultValue: `${settings.plotCooldownMinutes}` }).textField("Global cooldown between raids (0-300 seconds)", `${settings.globalCooldownSeconds}`, { defaultValue: `${settings.globalCooldownSeconds}` }).toggle("AFK detection option", { defaultValue: settings.afkDetection }).textField("AFK idle seconds before blocking raids", `${settings.afkIdleSeconds}`, { defaultValue: `${settings.afkIdleSeconds}` }).toggle("Re-raid protection", { defaultValue: settings.reRaidProtection }).textField("Max raids per player per world day (0 = unlimited)", `${settings.maxRaidsPerPlayer}`, { defaultValue: `${settings.maxRaidsPerPlayer}` });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminRaidSettings(player);
      return;
    }
    settings.playerCooldownSeconds = clampNumber(parsePositiveInteger(String(res.formValues[0]), settings.playerCooldownSeconds), 15, 60);
    settings.plotCooldownMinutes = clampNumber(parsePositiveInteger(String(res.formValues[1]), settings.plotCooldownMinutes), 5, 30);
    settings.globalCooldownSeconds = clampNumber(parsePositiveInteger(String(res.formValues[2]), settings.globalCooldownSeconds), 0, 300);
    settings.afkDetection = Boolean(res.formValues[3]);
    settings.afkIdleSeconds = clampNumber(parsePositiveInteger(String(res.formValues[4]), settings.afkIdleSeconds), 15, 600);
    settings.reRaidProtection = Boolean(res.formValues[5]);
    settings.maxRaidsPerPlayer = clampNumber(parsePositiveInteger(String(res.formValues[6]), settings.maxRaidsPerPlayer), 0, 100);
    saveRaidSettings(settings);
    player.sendMessage("\xA7a\u2714 Raid cooldown and anti-abuse settings updated.");
    openAdminRaidSettings(player);
  });
}
function openAdminRaidAccessSettings(player) {
  const settings = loadRaidSettings();
  const entryModes = ["all_players", "attacker_only"];
  const form = new ModalFormData().title("\xA73Raid Access & Alerts").dropdown("Entry rules", ["Allow all players", "Only attacker"], { defaultValueIndex: entryModes.indexOf(settings.entryMode) }).toggle("Allow container access during raids", { defaultValue: settings.allowContainerAccessDuringRaid }).toggle("Allow block breaking during raids", { defaultValue: settings.blockBreakingDuringRaid }).toggle("Keep core blocks protected", { defaultValue: settings.keepCoreBlocksProtected }).toggle("Server broadcast toggle", { defaultValue: settings.broadcastOnBreach }).textField("Broadcast message format ({plot} {attacker} {owner})", settings.broadcastTemplate, { defaultValue: settings.broadcastTemplate }).toggle("Owner alerts", { defaultValue: settings.ownerAlertEnabled }).textField("Owner alert format ({plot} {attacker} {owner})", settings.ownerAlertTemplate, { defaultValue: settings.ownerAlertTemplate });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminRaidSettings(player);
      return;
    }
    settings.entryMode = entryModes[Number(res.formValues[0]) ?? entryModes.indexOf(settings.entryMode)] ?? settings.entryMode;
    settings.allowContainerAccessDuringRaid = Boolean(res.formValues[1]);
    settings.blockBreakingDuringRaid = Boolean(res.formValues[2]);
    settings.keepCoreBlocksProtected = Boolean(res.formValues[3]);
    settings.broadcastOnBreach = Boolean(res.formValues[4]);
    settings.broadcastTemplate = String(res.formValues[5] ?? settings.broadcastTemplate).trim() || createDefaultRaidSettings().broadcastTemplate;
    settings.ownerAlertEnabled = Boolean(res.formValues[6]);
    settings.ownerAlertTemplate = String(res.formValues[7] ?? settings.ownerAlertTemplate).trim() || createDefaultRaidSettings().ownerAlertTemplate;
    saveRaidSettings(settings);
    player.sendMessage("\xA7a\u2714 Raid access and alert settings updated.");
    openAdminRaidSettings(player);
  });
}
function openAdminRaidAdvancedOptions(player) {
  const settings = loadRaidSettings();
  const tierLines = LOCKPICK_TIERS.map((tier) => {
    const success = getRaidTierSuccessPercent(settings, tier.tier);
    const time = getRaidTierPickTimeSeconds(settings, tier.tier);
    const cost = getRaidTierMoneyCost(settings, tier.tier);
    const ct = getRaidTierCTokenCost(settings, tier.tier);
    return `${getRaidTierDisplayName(tier.tier)}\xA7f -> \xA7e${success}%\xA7f, \xA7e${time}s\xA7f, \xA72$${formatCompactCurrency(cost)}${ct > 0 ? ` \xA7f+ \xA7b${ct} CT` : ""}`;
  }).join("\n");
  const form = new ActionFormData().title("\xA75Advanced Raid Options").body(
    `\xA7fDetailed success formulas and exact cooldown values.

\xA7fScaling mode: \xA7d${getTierScalingLabel(settings.tierScalingMode)}
\xA7fExtra success / tier: \xA7e${settings.tierSuccessBonus}%
\xA7fExtra time reduction / tier: \xA7e${settings.tierTimeReductionSeconds}s
\xA7fMoney scaling / tier: \xA72${settings.costScalePercent}%
\xA7fCToken scaling / tier: \xA7b${settings.ctokenScalePercent}%
\xA7fPlayer / Plot / Global cooldowns: \xA7e${settings.playerCooldownSeconds}s / ${settings.plotCooldownMinutes}m / ${settings.globalCooldownSeconds}s

${tierLines}`
  );
  form.button("\xA75Edit Advanced Values");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0 || res.selection === 1) {
      openAdminRaidSettings(player);
      return;
    }
    openAdminRaidAdvancedEdit(player);
  });
}
function openAdminRaidAdvancedEdit(player) {
  const settings = loadRaidSettings();
  const form = new ModalFormData().title("\xA75Edit Advanced Raid Values").textField("Success bonus per tier (%)", `${settings.tierSuccessBonus}`, { defaultValue: `${settings.tierSuccessBonus}` }).textField("Time reduction per tier (seconds)", `${settings.tierTimeReductionSeconds}`, { defaultValue: `${settings.tierTimeReductionSeconds}` }).textField("Money scaling per tier (%)", `${settings.costScalePercent}`, { defaultValue: `${settings.costScalePercent}` }).textField("CToken scaling per tier (%)", `${settings.ctokenScalePercent}`, { defaultValue: `${settings.ctokenScalePercent}` });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminRaidAdvancedOptions(player);
      return;
    }
    settings.tierSuccessBonus = clampNumber(parsePositiveInteger(String(res.formValues[0]), settings.tierSuccessBonus), 0, 100);
    settings.tierTimeReductionSeconds = clampNumber(parsePositiveInteger(String(res.formValues[1]), settings.tierTimeReductionSeconds), 0, 25);
    settings.costScalePercent = clampNumber(parsePositiveInteger(String(res.formValues[2]), settings.costScalePercent), 0, 500);
    settings.ctokenScalePercent = clampNumber(parsePositiveInteger(String(res.formValues[3]), settings.ctokenScalePercent), 0, 500);
    saveRaidSettings(settings);
    player.sendMessage("\xA7a\u2714 Advanced raid values updated.");
    openAdminRaidAdvancedOptions(player);
  });
}
function getPlotPresetByIndex(index) {
  return PLOT_CREATION_PRESETS[clampNumber(index, 0, PLOT_CREATION_PRESETS.length - 1)] ?? PLOT_CREATION_PRESETS[0];
}
function getPlotOrientationByIndex(index) {
  return PLOT_ORIENTATION_OPTIONS[clampNumber(index, 0, PLOT_ORIENTATION_OPTIONS.length - 1)] ?? PLOT_ORIENTATION_OPTIONS[0];
}
function resolvePlotCreationDimensions(presetIndex, customWidthValue, customDepthValue) {
  const preset = getPlotPresetByIndex(presetIndex);
  if (preset.width !== null && preset.depth !== null) {
    return { width: preset.width, depth: preset.depth, presetLabel: preset.label };
  }
  const width = parseInt(customWidthValue, 10);
  const depth = parseInt(customDepthValue, 10);
  if (!Number.isFinite(width) || width <= 0 || !Number.isFinite(depth) || depth <= 0) {
    return null;
  }
  return { width, depth, presetLabel: `Custom ${width}x${depth}` };
}
function getOrientedPlotCorners(originX, originZ, width, depth, orientationKey, row = 0, col = 0, gap = 0) {
  const orientation = PLOT_ORIENTATION_OPTIONS.find((option) => option.key === orientationKey) ?? PLOT_ORIENTATION_OPTIONS[0];
  const vectors = {
    north: { forwardX: 0, forwardZ: -1, rightX: 1, rightZ: 0 },
    east: { forwardX: 1, forwardZ: 0, rightX: 0, rightZ: 1 },
    south: { forwardX: 0, forwardZ: 1, rightX: -1, rightZ: 0 },
    west: { forwardX: -1, forwardZ: 0, rightX: 0, rightZ: -1 }
  }[orientation.key];
  const rowStep = row * (depth + gap);
  const colStep = col * (width + gap);
  const startX = originX + vectors.forwardX * rowStep + vectors.rightX * colStep;
  const startZ = originZ + vectors.forwardZ * rowStep + vectors.rightZ * colStep;
  const endX = startX + vectors.rightX * (width - 1) + vectors.forwardX * (depth - 1);
  const endZ = startZ + vectors.rightZ * (width - 1) + vectors.forwardZ * (depth - 1);
  return { x1: startX, z1: startZ, x2: endX, z2: endZ, orientationLabel: orientation.label };
}
function createPlotRecord(plotId, pos1, pos2, price) {
  return {
    id: plotId,
    x1: Math.floor(Number(pos1.x)),
    y1: Math.floor(Number(pos1.y)),
    z1: Math.floor(Number(pos1.z)),
    x2: Math.floor(Number(pos2.x)),
    y2: Math.floor(Number(pos2.y)),
    z2: Math.floor(Number(pos2.z)),
    price,
    ownerId: null,
    ownerName: null,
    locked: false,
    isPublic: true,
    members: [],
    memberSlotUpgrade: 0,
    hasProtectionUpgrade: false,
    hasContainerShieldUpgrade: false,
    accessLog: [],
    lastOwnerActivity: 0,
    autoResetDays: 0,
    breachedUntil: 0,
    breachedBy: null,
    breachedById: null,
    lastRaidedTick: 0,
    containerShieldUntil: 0,
    lockStrengthTier: 0,
    alarmUpgradeTier: 0,
    reinforcedContainerTier: 0
  };
}
function openAdminCreateStep1(player) {
  const pending = pendingCreations.get(player.id) ?? { pos1: null, pos2: null };
  const pos1Str = pending.pos1 ? `(${pending.pos1.x}, ${pending.pos1.y}, ${pending.pos1.z})` : "Not set";
  const pos2Str = pending.pos2 ? `(${pending.pos2.x}, ${pending.pos2.y}, ${pending.pos2.z})` : "Not set";
  const form = new ActionFormData().title("\xA72Create Plot \u2014 Step 1").body(
    `\xA78Set the two footprint corners of the new plot.
\xA78Plots now protect the full world height automatically.
\xA78You can also use a quick preset from your current location.

\xA7fPos 1: \xA76${pos1Str}
\xA7fPos 2: \xA76${pos2Str}${pending.presetLabel ? `
\xA7fPreset: \xA7b${pending.presetLabel}${pending.orientationLabel ? ` \xA77| \xA7fFacing: \xA7b${pending.orientationLabel}` : ""}` : ""}`
  );
  form.button("\xA72Set Pos 1 (current location)");
  form.button("\xA72Set Pos 2 (current location)");
  form.button("\xA7bQuick Preset From Here");
  form.button("\xA71Confirm & Set Price");
  form.button("\xA78Cancel");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    switch (res.selection) {
      case 0: {
        const loc = player.location;
        pending.pos1 = { x: Math.floor(loc.x), y: Math.floor(loc.y), z: Math.floor(loc.z) };
        delete pending.presetLabel;
        delete pending.orientationLabel;
        pendingCreations.set(player.id, pending);
        player.sendMessage(`\xA7aPos 1 set to \xA7e(${pending.pos1.x}, ${pending.pos1.y}, ${pending.pos1.z})`);
        openAdminCreateStep1(player);
        break;
      }
      case 1: {
        const loc = player.location;
        pending.pos2 = { x: Math.floor(loc.x), y: Math.floor(loc.y), z: Math.floor(loc.z) };
        delete pending.presetLabel;
        delete pending.orientationLabel;
        pendingCreations.set(player.id, pending);
        player.sendMessage(`\xA7aPos 2 set to \xA7e(${pending.pos2.x}, ${pending.pos2.y}, ${pending.pos2.z})`);
        openAdminCreateStep1(player);
        break;
      }
      case 2: {
        openAdminCreatePresetMenu(player);
        break;
      }
      case 3: {
        if (!pending.pos1 || !pending.pos2) {
          player.sendMessage("\xA7cYou must set both positions first!");
          openAdminCreateStep1(player);
          return;
        }
        openAdminCreateFinalize(player, pending);
        break;
      }
      default:
        pendingCreations.delete(player.id);
        openAdminMenu(player);
        break;
    }
  });
}
function openAdminCreatePresetMenu(player) {
  const form = new ModalFormData().title("\xA72Create Plot \u2014 Quick Preset").dropdown("Plot size preset", PLOT_CREATION_PRESETS.map((preset) => preset.label), { defaultValueIndex: 0 }).textField("Custom width", "Used only when preset is Custom", { defaultValue: "17" }).textField("Custom depth", "Used only when preset is Custom", { defaultValue: "14" }).dropdown("Orientation", PLOT_ORIENTATION_OPTIONS.map((option) => option.label), { defaultValueIndex: 0 });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminCreateStep1(player);
      return;
    }
    const dimensions = resolvePlotCreationDimensions(Number(res.formValues[0]) || 0, String(res.formValues[1] ?? ""), String(res.formValues[2] ?? ""));
    if (!dimensions) {
      player.sendMessage("\xA7cInvalid custom preset dimensions.");
      openAdminCreatePresetMenu(player);
      return;
    }
    const orientation = getPlotOrientationByIndex(Number(res.formValues[3]) || 0);
    const loc = player.location;
    const origin = {
      x: Math.floor(loc.x),
      y: Math.floor(loc.y),
      z: Math.floor(loc.z)
    };
    const corners = getOrientedPlotCorners(origin.x, origin.z, dimensions.width, dimensions.depth, orientation.key);
    const pending = {
      pos1: { x: corners.x1, y: origin.y, z: corners.z1 },
      pos2: { x: corners.x2, y: origin.y, z: corners.z2 },
      presetLabel: dimensions.presetLabel,
      orientationLabel: orientation.label
    };
    pendingCreations.set(player.id, pending);
    player.sendMessage(`\xA7aQuick preset ready: \xA7b${dimensions.presetLabel}\xA7a facing \xA7b${orientation.label}\xA7a from your current location.`);
    openAdminCreateFinalize(player, pending);
  });
}
function openAdminCreateFinalize(player, pending) {
  const form = new ModalFormData().title("\xA72Create Plot \u2014 Finalize").textField("Plot ID", "e.g. plot_001", { defaultValue: "" }).textField("Price", "e.g. 500", { defaultValue: "500" });
  form.show(player).then((res) => {
    try {
      if (res.canceled || !res.formValues) {
        openAdminMenu(player);
        return;
      }
      if (!pending || !pending.pos1 || !pending.pos2) {
        player.sendMessage("\xA7cCreate failed: both plot positions must be set again.");
        openAdminCreateStep1(player);
        return;
      }
      const plotId = String(res.formValues[0] ?? "").trim();
      const priceStr = String(res.formValues[1] ?? "").trim();
      const price = parseInt(priceStr, 10);
      if (!plotId) {
        player.sendMessage("\xA7cPlot ID cannot be empty.");
        openAdminCreateFinalize(player, pending);
        return;
      }
      if (!Number.isFinite(price) || price <= 0) {
        player.sendMessage("\xA7cInvalid price. Enter a positive whole number.");
        openAdminCreateFinalize(player, pending);
        return;
      }
      const plots = loadPlots();
      if (!Array.isArray(plots)) {
        player.sendMessage("\xA7cCreate failed: saved plot list could not be read.");
        return;
      }
      if (plots.some((p) => String(p.id).toLowerCase() === plotId.toLowerCase())) {
        player.sendMessage(`\xA7cA plot with ID \xA7e${plotId}\xA7c already exists.`);
        openAdminCreateFinalize(player, pending);
        return;
      }
      const newPlot = createPlotRecord(plotId, pending.pos1, pending.pos2, price);
      if (![newPlot.x1, newPlot.y1, newPlot.z1, newPlot.x2, newPlot.y2, newPlot.z2].every(Number.isFinite)) {
        player.sendMessage("\xA7cCreate failed: one or more coordinates are invalid. Set both positions again.");
        openAdminCreateStep1(player);
        return;
      }
      plots.push(newPlot);
      const saved = savePlots(plots);
      if (!saved) {
        player.sendMessage("\xA7cCreate failed: plot data could not save. Check the chat warning above.");
        return;
      }
      pendingCreations.delete(player.id);
      player.sendMessage(`\xA7a\u2714 Plot \xA7e${plotId}\xA7a created! Size: \xA7b${plotSize(newPlot)}\xA7a, Price: \xA7e$${price}${pending.orientationLabel ? `\xA7a, Facing: \xA7b${pending.orientationLabel}` : ""}`);
      openAdminMenu(player);
    } catch (e) {
      player.sendMessage("\xA7cCreate failed with script error: " + String(e));
    }
  }).catch((e) => {
    player.sendMessage("\xA7cCreate form failed: " + String(e));
  });
}
function openBulkCreateMenu(player) {
  const form = new ModalFormData().title("\xA72Bulk Create Plots").textField("ID Prefix", "e.g. Plot ", { defaultValue: "Plot " }).textField("Rows", "e.g. 4", { defaultValue: "4" }).textField("Plots per row", "e.g. 12", { defaultValue: "12" }).dropdown("Plot size preset", PLOT_CREATION_PRESETS.map((preset) => preset.label), { defaultValueIndex: 0 }).textField("Custom width", "Used only when preset is Custom", { defaultValue: "17" }).textField("Custom depth", "Used only when preset is Custom", { defaultValue: "14" }).dropdown("Orientation", PLOT_ORIENTATION_OPTIONS.map((option) => option.label), { defaultValueIndex: 0 }).textField("Gap between plots", "e.g. 2", { defaultValue: "2" }).textField("Price per plot", "e.g. 500", { defaultValue: "500" });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminMenu(player);
      return;
    }
    const rawPrefix = String(res.formValues[0] ?? "").trim();
    const prefix = rawPrefix.length > 0 ? `${rawPrefix}${rawPrefix.endsWith(" ") ? "" : " "}` : "Plot ";
    const rows = parseInt(String(res.formValues[1] ?? ""), 10);
    const cols = parseInt(String(res.formValues[2] ?? ""), 10);
    const dimensions = resolvePlotCreationDimensions(Number(res.formValues[3]) || 0, String(res.formValues[4] ?? ""), String(res.formValues[5] ?? ""));
    const orientation = getPlotOrientationByIndex(Number(res.formValues[6]) || 0);
    const gap = parseInt(String(res.formValues[7] ?? ""), 10);
    const price = parseInt(String(res.formValues[8] ?? ""), 10);
    if (isNaN(rows) || rows <= 0 || isNaN(cols) || cols <= 0) {
      player.sendMessage("\xA7cInvalid rows/columns.");
      openBulkCreateMenu(player);
      return;
    }
    if (!dimensions) {
      player.sendMessage("\xA7cInvalid plot dimensions.");
      openBulkCreateMenu(player);
      return;
    }
    if (isNaN(gap) || gap < 0) {
      player.sendMessage("\xA7cInvalid gap.");
      openBulkCreateMenu(player);
      return;
    }
    if (isNaN(price) || price <= 0) {
      player.sendMessage("\xA7cInvalid price.");
      openBulkCreateMenu(player);
      return;
    }
    if (rows * cols > 100) {
      player.sendMessage("\xA7cMax 100 plots at once.");
      openBulkCreateMenu(player);
      return;
    }
    const plots = loadPlots();
    const loc = player.location;
    const startX = Math.floor(loc.x);
    const startY = Math.floor(loc.y);
    const startZ = Math.floor(loc.z);
    let count = 0;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        count++;
        const plotId = `${prefix}${plots.length + 1}`.trim();
        const corners = getOrientedPlotCorners(startX, startZ, dimensions.width, dimensions.depth, orientation.key, r, c, gap);
        const newPlot = createPlotRecord(
          plotId,
          { x: corners.x1, y: startY, z: corners.z1 },
          { x: corners.x2, y: startY, z: corners.z2 },
          price
        );
        plots.push(newPlot);
      }
    }
    const saved = savePlots(plots);
    if (!saved) {
      player.sendMessage("\xA7cBulk create failed: plot data could not save. Check the chat warning above.");
      return;
    }
    player.sendMessage(`\xA7a\u2714 Created \xA7e${count}\xA7a plots using \xA7b${dimensions.presetLabel}\xA7a facing \xA7b${orientation.label}\xA7a in a \xA7e${rows}x${cols}\xA7a grid from your current location.`);
    openAdminMenu(player);
  });
}
function openAdminDeleteMenu(player) {
  const plots = loadPlots();
  if (plots.length === 0) {
    const form2 = new MessageFormData().title("\xA7cDelete Plot").body("\xA77No plots exist yet.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openAdminMenu(player));
    return;
  }
  const form = new ActionFormData().title("\xA7cDelete Plot").body("\xA77Select a plot to permanently delete:");
  for (const p of plots) {
    const owner = p.ownerId ? `\xA7c${p.ownerName}` : "\xA7aAvailable";
    form.button(`\xA7f${getPlotMenuLabel(p)} ${owner}
\xA77${plotSize(p)}`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === plots.length) {
      openAdminMenu(player);
      return;
    }
    openAdminDeleteConfirm(player, plots[res.selection]);
  });
}
function openAdminDeleteConfirm(player, plot) {
  const form = new MessageFormData().title("\xA7cConfirm Delete").body(
    `\xA7cDelete plot \xA7e${plot.id}\xA7c?
\xA7fOwner: \xA7e${plot.ownerName ?? "None"}
\xA7cThis is permanent!`
  ).button1("\xA7cDelete").button2("\xA78Cancel");
  form.show(player).then((res) => {
    if (res.canceled || res.selection !== 0) {
      openAdminDeleteMenu(player);
      return;
    }
    let plots = loadPlots();
    plots = plots.filter((p) => p.id !== plot.id);
    savePlots(plots);
    player.sendMessage(`\xA7a\u2714 Plot \xA7e${plot.id}\xA7a has been deleted.`);
    openAdminMenu(player);
  });
}
function openAdminEditMenu(player) {
  const plots = loadPlots();
  if (plots.length === 0) {
    const form2 = new MessageFormData().title("\xA76Edit Plot").body("\xA77No plots exist yet.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openAdminMenu(player));
    return;
  }
  const form = new ActionFormData().title("\xA76Edit Plot").body("\xA77Select a plot to edit:");
  for (const p of plots) {
    const owner = p.ownerId ? `\xA7c${p.ownerName}` : "\xA7aAvailable";
    form.button(`\xA7f${getPlotMenuLabel(p)} ${owner}
\xA77$${p.price} \u2014 ${plotSize(p)}`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === plots.length) {
      openAdminMenu(player);
      return;
    }
    openAdminEditPlot(player, plots[res.selection]);
  });
}
function openAdminEditPlot(player, plot) {
  const form = new ModalFormData().title(`\xA76Edit: ${plot.id}`).textField("Price", `e.g. ${plot.price}`, { defaultValue: `${plot.price}` }).textField("Auto-Reset Days (0=never)", "e.g. 7", { defaultValue: `${plot.autoResetDays}` });
  form.show(player).then((res) => {
    if (res.canceled || !res.formValues) {
      openAdminEditMenu(player);
      return;
    }
    const newPrice = parseInt(res.formValues[0], 10);
    const newAutoReset = parseInt(res.formValues[1], 10);
    if (isNaN(newPrice) || newPrice <= 0) {
      player.sendMessage("\xA7cInvalid price.");
      openAdminEditPlot(player, plot);
      return;
    }
    const plots = loadPlots();
    const target = plots.find((p) => p.id === plot.id);
    if (!target) {
      player.sendMessage("\xA7cPlot not found.");
      openAdminMenu(player);
      return;
    }
    target.price = newPrice;
    target.autoResetDays = isNaN(newAutoReset) || newAutoReset < 0 ? 0 : newAutoReset;
    savePlots(plots);
    player.sendMessage(`\xA7a\u2714 Plot \xA7e${plot.id}\xA7a updated. Price: \xA7e$${newPrice}\xA7a, Auto-Reset: \xA7e${target.autoResetDays}\xA7a days.`);
    openAdminMenu(player);
  });
}
function openAdminAssignOwner(player) {
  const plots = loadPlots();
  if (plots.length === 0) {
    const form2 = new MessageFormData().title("\xA7dAssign Owner").body("\xA77No plots exist.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openAdminMenu(player));
    return;
  }
  const form = new ActionFormData().title("\xA7dAssign Owner").body("\xA77Select a plot to assign an owner:");
  for (const p of plots) {
    const owner = p.ownerId ? `\xA7c${p.ownerName}` : "\xA7aAvailable";
    form.button(`\xA7f${getPlotMenuLabel(p)} ${owner}
\xA77${plotSize(p)}`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === plots.length) {
      openAdminMenu(player);
      return;
    }
    openAdminAssignOwnerSelect(player, plots[res.selection]);
  });
}
function openAdminAssignOwnerSelect(player, plot) {
  const onlinePlayers = world.getAllPlayers();
  if (onlinePlayers.length === 0) {
    player.sendMessage("\xA7cNo players online.");
    openAdminMenu(player);
    return;
  }
  const form = new ActionFormData().title(`\xA7dAssign Owner: ${plot.id}`).body("\xA77Select a player to assign as owner:");
  for (const p of onlinePlayers) {
    form.button(`\xA7f${p.name}`);
  }
  form.button("\xA7cRemove Owner");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === onlinePlayers.length + 1) {
      openAdminMenu(player);
      return;
    }
    const plots = loadPlots();
    const target = plots.find((p) => p.id === plot.id);
    if (!target) {
      player.sendMessage("\xA7cPlot not found.");
      return;
    }
    if (res.selection === onlinePlayers.length) {
      target.ownerId = null;
      target.ownerName = null;
      target.members = [];
      target.lockStrengthTier = 0;
      target.alarmUpgradeTier = 0;
      target.reinforcedContainerTier = 0;
      addAccessLog(target, player.name, "admin removed owner");
      savePlots(plots);
      player.sendMessage(`\xA7a\u2714 Owner removed from plot \xA7e${target.id}\xA7a.`);
    } else {
      const selectedPlayer = onlinePlayers[res.selection];
      if (!canPlayerReceiveOwnership(plots, selectedPlayer.id, target.id)) {
        player.sendMessage(`\xA7c${selectedPlayer.name} already owns a plot. Players can only own one plot at a time.`);
        openAdminAssignOwnerSelect(player, target);
        return;
      }
      target.ownerId = selectedPlayer.id;
      target.ownerName = selectedPlayer.name;
      target.lastOwnerActivity = system.currentTick;
      addAccessLog(target, player.name, `admin assigned ${selectedPlayer.name}`);
      savePlots(plots);
      player.sendMessage(`\xA7a\u2714 Plot \xA7e${target.id}\xA7a assigned to \xA7e${selectedPlayer.name}\xA7a.`);
      selectedPlayer.sendMessage(`\xA7a\u2714 You were assigned plot \xA7e${target.id}\xA7a by an admin.`);
    }
    openAdminMenu(player);
  });
}
function openAdminResetMenu(player) {
  const plots = loadPlots();
  const owned = plots.filter((p) => p.ownerId !== null);
  if (owned.length === 0) {
    const form2 = new MessageFormData().title("\xA77Reset Plot").body("\xA77No owned plots to reset.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openAdminMenu(player));
    return;
  }
  const form = new ActionFormData().title("\xA77Reset Plot").body("\xA77Select a plot to reset (clears owner, members, upgrades):");
  for (const p of owned) {
    form.button(`\xA7f${getPlotMenuLabel(p)} \xA7c${p.ownerName}
\xA77${plotSize(p)}`);
  }
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    if (res.selection === owned.length) {
      openAdminMenu(player);
      return;
    }
    openAdminResetConfirm(player, owned[res.selection]);
  });
}
function openAdminResetConfirm(player, plot) {
  const form = new MessageFormData().title("\xA77Confirm Reset").body(
    `\xA7fReset plot \xA7e${plot.id}\xA7f?
\xA7fOwner: \xA7e${plot.ownerName ?? "None"}
\xA7fMembers: \xA7e${plot.members.length}

\xA7cThis will clear all ownership, members, and upgrades!`
  ).button1("\xA7cReset").button2("\xA78Cancel");
  form.show(player).then((res) => {
    if (res.canceled || res.selection !== 0) {
      openAdminResetMenu(player);
      return;
    }
    const plots = loadPlots();
    const target = plots.find((p) => p.id === plot.id);
    if (!target) {
      player.sendMessage("\xA7cPlot not found.");
      return;
    }
    target.ownerId = null;
    target.ownerName = null;
    target.locked = false;
    target.members = [];
    target.hasProtectionUpgrade = false;
    target.hasContainerShieldUpgrade = false;
    target.memberSlotUpgrade = 0;
    target.lockStrengthTier = 0;
    target.alarmUpgradeTier = 0;
    target.reinforcedContainerTier = 0;
    target.isPublic = true;
    target.breachedUntil = 0;
    target.breachedBy = null;
    target.breachedById = null;
    target.containerShieldUntil = 0;
    addAccessLog(target, player.name, "admin reset");
    savePlots(plots);
    player.sendMessage(`\xA7a\u2714 Plot \xA7e${target.id}\xA7a has been reset.`);
    openAdminMenu(player);
  });
}
function openAdminViewPlots(player, page) {
  const plots = loadPlots();
  if (plots.length === 0) {
    const form2 = new MessageFormData().title("\xA7bView Plots").body("\xA77No plots exist yet.").button1("\xA78Back").button2("\xA78Back");
    form2.show(player).then(() => openAdminMenu(player));
    return;
  }
  const totalPages = Math.ceil(plots.length / PAGE_SIZE);
  const start = page * PAGE_SIZE;
  const pageItems = plots.slice(start, start + PAGE_SIZE);
  const form = new ActionFormData().title(`\xA7bAll Plots \xA77(${page + 1}/${totalPages})`).body(`\xA77Total: \xA7e${plots.length}\xA77 plots`);
  for (const p of pageItems) {
    const owner = p.ownerId ? `\xA7c${p.ownerName}` : "\xA7aFree";
    const lock = p.locked ? " \xA76[Locked]" : "";
    const pub = p.isPublic ? "" : " \xA77[Private]";
    form.button(`\xA7f${getPlotMenuLabel(p)} ${owner}${lock}${pub}
\xA77$${p.price} \u2014 ${plotSize(p)} \u2014 ${p.members.length} members`);
  }
  if (page > 0) form.button("\xA77\u25C0 Previous");
  if (page < totalPages - 1) form.button("\xA77Next \u25B6");
  form.button("\xA78\u21A9 Back");
  form.show(player).then((res) => {
    if (res.canceled || res.selection === void 0) return;
    let idx = res.selection;
    if (idx < pageItems.length) {
      const p = pageItems[idx];
      openAdminPlotDetailView(player, p, page);
      return;
    }
    idx -= pageItems.length;
    const hasPrev = page > 0 ? 1 : 0;
    if (page > 0 && idx === 0) openAdminViewPlots(player, page - 1);
    else if (page < totalPages - 1 && idx === hasPrev) openAdminViewPlots(player, page + 1);
    else openAdminMenu(player);
  });
}
function openAdminPlotDetailView(player, plot, returnPage) {
  const defenseSettings = loadDefenseSettings();
  const upkeepStates = loadDefenseUpkeepStates();
  const ownerDisplay = plot.ownerId ? plot.ownerName : "None";
  const statusDisplay = plot.locked ? "Locked" : "Unlocked";
  const publicDisplay = plot.isPublic ? "Public" : "Private";
  const breached = isPlotBreached(plot);
  const breachTime = breached ? Math.ceil((plot.breachedUntil - system.currentTick) / 20) : 0;
  let memberList = "";
  for (const m of plot.members) {
    memberList += `  \xA77${m.playerName} (${m.role})${m.expiresAt !== null ? " [temp]" : ""}
`;
  }
  let body = `\xA7fPlot: \xA76${getPlotMenuLabel(plot)}
\xA7fFootprint: \xA78(${plot.x1}, ${plot.z1}) to (${plot.x2}, ${plot.z2})
\xA7fProtected Y: \xA71${plotVerticalCoverageText()}
\xA7fSize: \xA71${plotSize(plot)}
\xA7fPrice: \xA72$${plot.price}
\xA7fOwner: \xA76${ownerDisplay}
\xA7fStatus: \xA76${statusDisplay}
\xA7fPublic: \xA76${publicDisplay}
\xA7fProtection Upgrade: ${plot.hasProtectionUpgrade ? "\xA72Yes" : "\xA74No"}
\xA7fContainer Shield: ${plot.hasContainerShieldUpgrade ? "\xA72Yes" : "\xA74No"}
\xA7fDefense Status: ${getDefenseStatusLabel(plot, upkeepStates)}
${getDefenseUpgradeSummary(plot, defenseSettings, upkeepStates)}
\xA7fMembers (${plot.members.length}/${getMaxMembers(plot)}):
${memberList || "  \xA78None\n"}\xA7fAuto-Reset: \xA76${plot.autoResetDays > 0 ? `${plot.autoResetDays} days` : "Disabled"}`;
  if (breached) {
    body += `
\xA7c\u2694 BREACHED by ${plot.breachedBy} \u2014 ${breachTime}s remaining`;
  }
  if (isPlotOnRaidCooldown(plot)) {
    body += `
\xA78Raid cooldown: ${Math.ceil(getPlotRaidCooldownRemaining(plot) / 60)}m`;
  }
  const form = new MessageFormData().title(`\xA76${getPlotMenuLabel(plot)}`).body(body).button1("\xA78Back").button2("\xA78Back");
  form.show(player).then(() => openAdminViewPlots(player, returnPage));
}
var PlotShopStarComponent = {
  onUse(event) {
    const source = event.source;
    if (!(source instanceof Player)) return;
    system.run(() => tryOpenMenu(source, openMainMenu));
  }
};
var PlotAdminToolComponent = {
  onUse(event) {
    const source = event.source;
    if (!(source instanceof Player)) return;
    system.run(() => {
      if (!isPlotshopAdmin(source)) {
        source.sendMessage("\xA7cYou need the guiadmin or plotadmin tag to use the Plot Admin Tool.");
        ensurePlayerTools(source);
        return;
      }
      tryOpenMenu(source, source.isSneaking ? openPlotshopAdminQuickConfig : openPlotAdminToolHome);
    });
  }
};
var PlotConfiguratorComponent = {
  onUse(event) {
    const source = event.source;
    if (!(source instanceof Player)) return;
    system.run(() => {
      if (!isPlotshopAdmin(source)) {
        source.sendMessage("\xA7cYou need the guiadmin or plotadmin tag to use the PlotShop Configurator.");
        return;
      }
      tryOpenMenu(source, openPlotshopAdminQuickConfig);
    });
  }
};
var LockpickComponent = {
  onUse(event) {
    const source = event.source;
    if (!(source instanceof Player)) return;
    system.run(() => attemptLockpick(source));
  }
};
system.beforeEvents.startup.subscribe(({ itemComponentRegistry }) => {
  itemComponentRegistry.registerCustomComponent(
    "com_plotshop_star_td3uf2sh:plotshop_star_component",
    PlotShopStarComponent
  );
  itemComponentRegistry.registerCustomComponent(
    "com_plotshop_star_td3uf2sh:plot_admin_tool_component",
    PlotAdminToolComponent
  );
  itemComponentRegistry.registerCustomComponent(
    "com_plotshop_star_td3uf2sh:plot_configurator_component",
    PlotConfiguratorComponent
  );
  itemComponentRegistry.registerCustomComponent(
    "com_plotshop_star_td3uf2sh:lockpick_component",
    LockpickComponent
  );
});
world.afterEvents.worldLoad.subscribe(() => {
  ensureMoneyObjective();
  standardizePlotsIfNeeded();
  system.run(() => {
    for (const player of world.getAllPlayers()) {
      ensurePlayerTools(player);
    }
  });
});
system.runInterval(() => {
  const plots = loadPlots().filter((plot) => plot.ownerId !== null);
  if (plots.length === 0) return;
  const renderedPlots = /* @__PURE__ */ new Set();
  for (const player of world.getAllPlayers()) {
    if (!arePersonalVisualsEnabled(player)) continue;
    const dimension = player.dimension;
    const dimensionId = dimension?.id ?? "unknown";
    for (const plot of plots) {
      const renderKey = `${dimensionId}:${plot.id}`;
      if (renderedPlots.has(renderKey)) continue;
      if (!isPlayerNearPlot(player, plot, PLOT_STATUS_VISUAL_RANGE)) continue;
      renderPlotStatusBarrier(dimension, plot);
      renderedPlots.add(renderKey);
    }
  }
}, PLOT_STATUS_VISUAL_INTERVAL);
system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    ensurePlayerTools(player);
  }
}, TOOL_CHECK_INTERVAL_TICKS);
system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    const last = combatTimestamps.get(player.id);
    if (last === void 0) continue;
    const elapsed = system.currentTick - last;
    if (elapsed >= COMBAT_DURATION_TICKS) {
      combatTimestamps.delete(player.id);
      player.sendMessage("\xA7a\u2714 Combat tag removed.");
    }
  }
}, 40);
system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    if (player.hasTag(PRESTIGE_FIRST_RESET_TAG)) continue;
    const prestigeLevel = getPrestigeLevel(player);
    if (prestigeLevel < PRESTIGE_FIRST_LEVEL) continue;
    player.addTag(PRESTIGE_FIRST_RESET_TAG);
    resetPlayerForFirstPrestige(player);
  }
}, PRESTIGE_CHECK_INTERVAL_TICKS);
system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    if (!player.hasTag(EXTERNAL_REBIRTH_TAG)) continue;
    player.removeTag(EXTERNAL_REBIRTH_TAG);
    const settings = loadEconomySettings();
    const data = loadEconomyData(player.id);
    if (data.rebirths >= ECONOMY_MAX_REBIRTHS) {
      player.sendMessage(`\xA7cExternal rebirth ignored because you are already at the max rebirth of \xA7d${ECONOMY_MAX_REBIRTHS}\xA7c.`);
      continue;
    }
    const result = runUnifiedRebirthReset(player, "external rebirth reset", true);
    player.sendMessage(`\xA7dExternal rebirth applied! \xA7fLevel: \xA7d${result.data.rebirths}\xA7f | Permanent Sell Bonus: \xA7d${formatMultiplier(getEconomyRebirthBonus(result.data, settings))}\xA7f | \xA76${result.clearedPlotCount} plot(s)\xA7f reset.`);
    playSoundForPlayer(player, settings.soundPurchase, { volume: 1, pitch: 1.35 });
  }
}, PRESTIGE_CHECK_INTERVAL_TICKS);
